# Architecture

```text
External sources
  -> connectors
  -> raw collections
  -> normalization services
  -> normalized collections
  -> snapshot services
  -> discrepancy records
  -> FastAPI dashboard endpoints
```

The system is MongoDB-only. It uses raw, normalized, snapshot, discrepancy, quality, source health, and audit collections.

No SQL, no PostgreSQL, no TimescaleDB, no ML, no prediction, and no trading signals.
