# Timestamp Alignment

Every price document preserves:

- `source_timestamp_utc`
- `ingested_at_utc`
- `canonical_timestamp_utc`
- `aligned_interval`
- `snapshot_batch_id`
- `freshness_seconds`
- `source_latency_seconds`
- `is_stale`
- `alignment_method`

Raw source timestamp is truth from the source. Ingestion timestamp is when the system received the data. Canonical timestamp is the comparison bucket.

Supported intervals:

- `5s`
- `1m`
- `5m`
- `1h`
- `1d`
- `1w`
- `1mo`
- `market_close`

Weekly fuel prices use `effective_date_start` and `effective_date_end` and are not stale while the effective period is active.
