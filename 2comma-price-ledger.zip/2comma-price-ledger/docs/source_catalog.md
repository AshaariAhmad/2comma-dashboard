# Source Catalog

Sources include:

- crypto exchange APIs
- benchmark APIs
- country retail price sites
- FX reference sources
- stock price APIs
- manual verified sources

Each source should define:

- `source_id`
- `source_name`
- `source_type`
- `access_method`
- `provides_source_timestamp`
- `expected_update_frequency`
- `allowed_staleness_seconds`
- `active`
