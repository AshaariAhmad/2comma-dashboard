# API Reference

Base URL:

```text
http://localhost:8000
```

Endpoints:

```text
GET  /health
POST /api/admin/init-db
POST /api/admin/seed-catalogs
POST /api/admin/seed-sample-data
GET  /api/snapshots/latest
GET  /api/crypto/{asset_id}/platforms
GET  /api/metals/{metal_id}/countries
GET  /api/energy/{asset_id}/benchmarks
GET  /api/countries/{country_code}/prices
GET  /api/equities/{ticker}/related-assets
GET  /api/fx/latest
GET  /api/source-health
GET  /api/data-quality
GET  /api/audit
GET  /api/discrepancies
GET  /api/snapshots/batches/{snapshot_batch_id}
```

All price responses include timestamp fields where available.
