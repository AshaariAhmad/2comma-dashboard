# NoSQL Schema

Main collections:

- `asset_catalog`
- `venue_catalog`
- `country_catalog`
- `source_catalog`
- `raw_price_events`
- `normalized_price_events`
- `aligned_price_snapshots`
- `snapshot_batches`
- `fx_rate_events`
- `source_health_logs`
- `data_quality_logs`
- `audit_logs`
- `discrepancy_records`

Domain collections:

- `crypto_raw_quotes`
- `crypto_normalized_quotes`
- `crypto_aligned_snapshots`
- `metals_raw_prices`
- `metals_normalized_prices`
- `metals_country_snapshots`
- `energy_raw_prices`
- `energy_normalized_prices`
- `energy_country_snapshots`
- `equity_raw_prices`
- `equity_normalized_prices`
- `equity_market_snapshots`
