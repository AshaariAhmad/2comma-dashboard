async function loadStockRelatedAssetPanel(ticker = "COIN") {
  const url = `/api/equities/${ticker}/related-assets`;
  const response = await fetch(url);
  const json = await response.json();

  if (json.status !== "ok") {
    console.error("Stock related asset panel error:", json);
    return;
  }

  const data = json.data;
  const equity = data.equity || data.equity_price || {};
  const related = data.related_asset || data.related_asset_price || {};

  const setText = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.textContent = value ?? "-";
  };

  setText("equityTicker", data.ticker);
  setText("equityClose", Number(equity.close || equity.adjusted_close || 0).toFixed(2));
  setText("equityTimestamp", equity.source_timestamp_utc);
  setText("relatedAssetId", data.related_asset_id || related.asset_id);
  setText("relatedAssetPrice", Number(related.price_usd || related.price_usd_normalized || related.price_usd_per_troy_ounce || 0).toFixed(2));
  setText("comparisonMode", data.summary?.comparison_type || data.comparison?.comparison_type || "timestamp_aligned");
  return data;
}
