async function loadSourceHealthPanel() {
  const url = "/api/source-health?limit=100";
  const response = await fetch(url);
  const json = await response.json();

  if (json.status !== "ok") {
    console.error("Source health error:", json);
    return;
  }

  const tbody = document.getElementById("sourceHealthTableBody");
  if (!tbody) return json.data;

  tbody.innerHTML = "";
  (json.data.sources || []).forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.source_id || "-"}</td>
      <td>${row.venue_id || "-"}</td>
      <td>${row.status || "-"}</td>
      <td>${row.latency_ms || "-"}</td>
      <td>${row.ingested_at_utc || row.checked_at_utc || "-"}</td>
      <td>${row.success ? "OK" : "FAIL"}</td>
    `;
    tbody.appendChild(tr);
  });
  return json.data;
}
