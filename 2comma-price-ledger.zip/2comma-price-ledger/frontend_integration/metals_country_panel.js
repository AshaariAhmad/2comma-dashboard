async function loadMetalsCountryPanel(metalId = "XAU") {
  const url = `/api/metals/${metalId}/countries`;
  const response = await fetch(url);
  const json = await response.json();

  if (json.status !== "ok" && json.status !== "partial") {
    console.error("Metals panel error:", json);
    return;
  }

  const data = json.data;
  const tbody = document.getElementById("metalsCountryTableBody");
  if (!tbody) return data;

  tbody.innerHTML = "";
  (data.countries || []).forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.country_name || row.country_code || "-"}</td>
      <td>${row.purity_original || "-"}</td>
      <td>${row.local_currency || ""} ${Number(row.price_local || 0).toFixed(2)}</td>
      <td>${Number(row.price_usd_per_troy_ounce || 0).toFixed(2)}</td>
      <td>${Number(row.premium_discount_pct || 0).toFixed(2)}%</td>
      <td>${row.source_timestamp_utc || "-"}</td>
      <td>${row.is_stale ? "STALE" : "OK"}</td>
      <td>${Number(row.quality_score || 0).toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
  return data;
}
