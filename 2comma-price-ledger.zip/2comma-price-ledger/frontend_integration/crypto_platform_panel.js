async function loadCryptoPlatformPanel(assetId = "BTC") {
  const url = `/api/crypto/${assetId}/platforms?aligned_interval=1m&include_stale=false`;
  const response = await fetch(url);
  const json = await response.json();

  if (json.status !== "ok" && json.status !== "partial") {
    console.error("Crypto panel error:", json);
    return;
  }

  const data = json.data;
  const tbody = document.getElementById("cryptoPlatformTableBody");
  if (!tbody) return data;

  tbody.innerHTML = "";
  (data.platforms || data.prices || []).forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.platform || row.venue_id || "-"}</td>
      <td>${row.symbol || row.raw_symbol || "-"}</td>
      <td>${Number(row.normalized_mid || row.display_price || 0).toFixed(2)}</td>
      <td>${row.source_timestamp_utc || "-"}</td>
      <td>${row.canonical_timestamp_utc || data.canonical_timestamp_utc || "-"}</td>
      <td>${row.is_stale ? "STALE" : "OK"}</td>
      <td>${Number(row.quality_score || 0).toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
  return data;
}
