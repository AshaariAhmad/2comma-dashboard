async function loadEnergyPricePanel(assetId = "BRENT_CRUDE") {
  const url = `/api/energy/${assetId}/benchmarks`;
  const response = await fetch(url);
  const json = await response.json();

  if (json.status !== "ok") {
    console.error("Energy panel error:", json);
    return;
  }

  const data = json.data;
  const tbody = document.getElementById("energyPriceTableBody");
  if (!tbody) return data;

  tbody.innerHTML = "";
  (data.benchmarks || []).forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.asset_name || row.asset_id || "-"}</td>
      <td>${Number(row.price_usd_normalized || 0).toFixed(2)}</td>
      <td>${row.normalized_unit || "-"}</td>
      <td>${row.source_timestamp_utc || "-"}</td>
      <td>${row.canonical_timestamp_utc || "-"}</td>
      <td>${row.is_stale ? "STALE" : "OK"}</td>
      <td>${Number(row.quality_score || 0).toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
  return data;
}
