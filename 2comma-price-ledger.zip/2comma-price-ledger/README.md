# 2 Comma Global Price Documentation Ledger

A MongoDB-only NoSQL backend for documenting and comparing prices across crypto platforms, countries, commodities, FX, equities, and retail prices.

This project is **not** a trading bot, not ML, not prediction, and not signal generation.

## What it does

- Stores raw source payloads without overwriting them.
- Creates normalized price documents.
- Preserves source timestamp and ingestion timestamp.
- Assigns canonical UTC timestamp buckets for comparison.
- Creates aligned snapshots and discrepancy records.
- Logs source health, data quality issues, transformations, and audit trails.
- Exposes FastAPI endpoints for your existing Bloomberg-style dashboard.

## Project structure

```text
2comma-price-ledger/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── schemas/
│   │   ├── services/
│   │   ├── connectors/
│   │   ├── routers/
│   │   ├── jobs/
│   │   └── seed/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend_integration/
├── docs/
├── docker-compose.yml
├── .env.example
└── README.md
```

## Windows setup with Docker Desktop

1. Install Docker Desktop for Windows.
2. Open PowerShell in this project folder.
3. Copy the env file:

```powershell
copy .env.example .env
```

4. Start MongoDB and FastAPI:

```powershell
docker compose up --build
```

5. Open API docs:

```text
http://localhost:8000/docs
```

6. Seed catalogs:

```powershell
curl -X POST http://localhost:8000/api/admin/seed-catalogs
```

7. Seed sample test data:

```powershell
curl -X POST http://localhost:8000/api/admin/seed-sample-data
```

8. Test endpoints:

```text
http://localhost:8000/health
http://localhost:8000/api/snapshots/latest
http://localhost:8000/api/crypto/BTC/platforms
http://localhost:8000/api/metals/XAU/countries
http://localhost:8000/api/energy/BRENT_CRUDE/benchmarks
http://localhost:8000/api/countries/MY/prices?category=fuel
http://localhost:8000/api/equities/COIN/related-assets
http://localhost:8000/api/fx/latest
http://localhost:8000/api/source-health
http://localhost:8000/api/data-quality
http://localhost:8000/api/audit
http://localhost:8000/api/discrepancies
```

## Run without Docker

Start MongoDB locally, then create `.env` with:

```env
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB=two_comma_price_ledger
```

Then run:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## How to connect to your existing frontend

Do not redesign your Bloomberg-style dashboard. Add table containers with IDs such as:

```html
<tbody id="cryptoPlatformTableBody"></tbody>
<tbody id="metalsCountryTableBody"></tbody>
<tbody id="energyPriceTableBody"></tbody>
<tbody id="sourceHealthTableBody"></tbody>
```

Then include the JS files from `frontend_integration/` and call:

```html
<script src="frontend_integration/crypto_platform_panel.js"></script>
<script>
  loadCryptoPlatformPanel("BTC");
</script>
```

If your frontend is served separately, update fetch URLs to use `http://localhost:8000/api/...`.

## Required timestamp fields

Every price document must include:

```text
source_timestamp_utc
ingested_at_utc
canonical_timestamp_utc
aligned_interval
snapshot_batch_id
freshness_seconds
source_latency_seconds
is_stale
alignment_method
```

## Endpoint summary

| Endpoint | Purpose |
|---|---|
| `GET /api/snapshots/latest` | Latest aligned snapshot |
| `GET /api/crypto/{asset_id}/platforms` | Crypto platform comparison |
| `GET /api/metals/{metal_id}/countries` | Metal country comparison |
| `GET /api/energy/{asset_id}/benchmarks` | Energy benchmark comparison |
| `GET /api/countries/{country_code}/prices` | Country retail prices |
| `GET /api/equities/{ticker}/related-assets` | Stock vs related asset |
| `GET /api/fx/latest` | Latest FX rates |
| `GET /api/source-health` | Source health |
| `GET /api/data-quality` | Data quality logs |
| `GET /api/audit` | Audit logs |
| `GET /api/discrepancies` | Discrepancy records |
| `GET /api/snapshots/batches/{snapshot_batch_id}` | Snapshot batch detail |

## Production notes

- Keep raw source payloads immutable.
- Recompute normalized records if rules change.
- Regenerate snapshots from normalized records.
- Keep audit logs append-only.
- Do not compare prices unless they share a canonical timestamp bucket.
