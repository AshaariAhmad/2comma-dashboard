from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/{ticker}/related-assets")
async def equity_related_assets(
    ticker: str,
    date: Optional[str] = None,
    related_asset_id: Optional[str] = None,
    exchange: Optional[str] = None,
    include_after_close_move: bool = True,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {"ticker": ticker.upper()}
    if related_asset_id:
        query["related_asset_id"] = related_asset_id.upper()
    if exchange:
        query["exchange"] = exchange.upper()
    doc = await db.equity_market_snapshots.find_one(query, sort=[("canonical_timestamp_utc", -1)])
    if not doc:
        raise HTTPException(status_code=404, detail="No equity related asset snapshot found.")
    return envelope(f"/api/equities/{ticker}/related-assets", serialize_mongo(doc))
