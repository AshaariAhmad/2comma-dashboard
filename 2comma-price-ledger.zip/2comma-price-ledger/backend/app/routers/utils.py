from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from bson import ObjectId
from fastapi.encoders import jsonable_encoder


def serialize_mongo(doc: Any) -> Any:
    if isinstance(doc, list):
        return [serialize_mongo(x) for x in doc]
    if isinstance(doc, dict):
        out: Dict[str, Any] = {}
        for k, v in doc.items():
            if k == "_id":
                out["id"] = str(v)
            else:
                out[k] = serialize_mongo(v)
        return out
    if isinstance(doc, ObjectId):
        return str(doc)
    if isinstance(doc, datetime):
        return doc.isoformat() + "Z"
    return doc


def envelope(endpoint: str, data: Dict[str, Any], status: str = "ok", request: Dict[str, Any] | None = None, warnings: list[str] | None = None):
    return jsonable_encoder({
        "status": status,
        "endpoint": endpoint,
        "request": request or {},
        "data": serialize_mongo(data),
        "warnings": warnings or [],
        "server_time_utc": datetime.utcnow().isoformat() + "Z",
    })
