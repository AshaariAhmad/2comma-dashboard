from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/latest")
async def latest_snapshot(
    comparison_group: Optional[str] = None,
    asset_id: Optional[str] = None,
    asset_type: Optional[str] = None,
    country_code: Optional[str] = None,
    aligned_interval: Optional[str] = None,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {}
    for key, value in {
        "comparison_group": comparison_group,
        "asset_id": asset_id,
        "asset_type": asset_type,
        "country_code": country_code,
        "aligned_interval": aligned_interval,
    }.items():
        if value:
            query[key] = value
    doc = await db.aligned_price_snapshots.find_one(query, sort=[("canonical_timestamp_utc", -1)])
    if not doc:
        raise HTTPException(status_code=404, detail="No aligned snapshot found.")
    return envelope("/api/snapshots/latest", serialize_mongo(doc), request=query)


@router.get("/batches/{snapshot_batch_id}")
@router.get("/{snapshot_batch_id}")
async def snapshot_batch_detail(
    snapshot_batch_id: str,
    include_prices: bool = True,
    include_audit: bool = False,
    include_discrepancies: bool = True,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    batch = await db.snapshot_batches.find_one({"snapshot_batch_id": snapshot_batch_id})
    if not batch:
        raise HTTPException(status_code=404, detail="Snapshot batch not found.")
    data = serialize_mongo(batch)
    if include_prices:
        snap = await db.aligned_price_snapshots.find_one({"snapshot_batch_id": snapshot_batch_id})
        data["snapshot"] = serialize_mongo(snap) if snap else None
    if include_discrepancies:
        data["discrepancies"] = serialize_mongo([x async for x in db.discrepancy_records.find({"snapshot_batch_id": snapshot_batch_id}).limit(100)])
    if include_audit:
        data["audit_logs"] = serialize_mongo([x async for x in db.audit_logs.find({"snapshot_batch_id": snapshot_batch_id}).sort("created_at_utc", -1).limit(100)])
    return envelope(f"/api/snapshot-batches/{snapshot_batch_id}", data)
