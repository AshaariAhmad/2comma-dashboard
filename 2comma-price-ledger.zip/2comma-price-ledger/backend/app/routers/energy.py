from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/{asset_id}/benchmarks")
async def energy_benchmarks(
    asset_id: str,
    date: Optional[str] = None,
    aligned_interval: str = "1d",
    include_related: bool = True,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {"aligned_interval": aligned_interval}
    rows = [serialize_mongo(x) async for x in db.energy_benchmark_prices.find(query).sort("canonical_timestamp_utc", -1).limit(25)]
    if not rows:
        raise HTTPException(status_code=404, detail="No energy benchmark prices found.")
    selected = [x for x in rows if x.get("asset_id") == asset_id.upper()]
    data = {
        "asset_id": asset_id.upper(),
        "comparison_group": "ENERGY_BENCHMARKS",
        "canonical_timestamp_utc": rows[0].get("canonical_timestamp_utc"),
        "aligned_interval": aligned_interval,
        "snapshot_batch_id": rows[0].get("snapshot_batch_id"),
        "benchmarks": rows if include_related else selected,
    }
    return envelope(f"/api/energy/{asset_id}/benchmarks", data)
