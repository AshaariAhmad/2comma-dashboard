from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/{asset_id}/platforms")
async def crypto_platforms(
    asset_id: str,
    aligned_interval: str = "1m",
    canonical_timestamp_utc: Optional[str] = None,
    quote_currency: str = "USD",
    market_type: str = "spot",
    include_stale: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {"base_asset": asset_id.upper(), "aligned_interval": aligned_interval}
    if canonical_timestamp_utc:
        query["canonical_timestamp_utc"] = canonical_timestamp_utc
    doc = await db.crypto_aligned_snapshots.find_one(query, sort=[("canonical_timestamp_utc", -1)])
    if not doc:
        # Fallback to generic aligned snapshots if domain snapshot not found.
        doc = await db.aligned_price_snapshots.find_one({"asset_id": asset_id.upper(), "aligned_interval": aligned_interval}, sort=[("canonical_timestamp_utc", -1)])
    if not doc:
        raise HTTPException(status_code=404, detail="No crypto platform snapshot found.")
    data = serialize_mongo(doc)
    data["asset_id"] = asset_id.upper()
    data["canonical_pair"] = f"{asset_id.upper()}/{quote_currency}"
    data["platforms"] = data.get("prices", [])
    return envelope(f"/api/crypto/{asset_id}/platforms", data, warnings=[])
