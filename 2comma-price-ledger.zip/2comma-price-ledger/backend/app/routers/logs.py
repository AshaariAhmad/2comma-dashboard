from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

source_health_router = APIRouter()
data_quality_router = APIRouter()
audit_router = APIRouter()
discrepancies_router = APIRouter()
admin_router = APIRouter()


@source_health_router.get("")
async def source_health(source_id: Optional[str] = None, source_type: Optional[str] = None, status: Optional[str] = None, limit: int = 100, db: AsyncIOMotorDatabase = Depends(get_db)):
    query = {}
    if source_id: query["source_id"] = source_id
    if source_type: query["source_type"] = source_type
    if status: query["status"] = status
    rows = [serialize_mongo(x) async for x in db.source_health_logs.find(query).sort("checked_at_utc", -1).limit(limit)]
    return envelope("/api/source-health", {"sources": rows, "summary": {"sources_total": len(rows)}})


@data_quality_router.get("")
async def data_quality(severity: Optional[str] = None, issue_type: Optional[str] = None, asset_id: Optional[str] = None, source_id: Optional[str] = None, snapshot_batch_id: Optional[str] = None, limit: int = 100, db: AsyncIOMotorDatabase = Depends(get_db)):
    query = {}
    for k, v in {"severity": severity, "issue_type": issue_type, "asset_id": asset_id, "source_id": source_id, "snapshot_batch_id": snapshot_batch_id}.items():
        if v: query[k] = v
    rows = [serialize_mongo(x) async for x in db.data_quality_logs.find(query).sort("created_at_utc", -1).limit(limit)]
    return envelope("/api/data-quality", {"logs": rows, "summary": {"logs_returned": len(rows)}})


@audit_router.get("")
async def audit(entity_id: Optional[str] = None, entity_type: Optional[str] = None, event_type: Optional[str] = None, snapshot_batch_id: Optional[str] = None, limit: int = 100, db: AsyncIOMotorDatabase = Depends(get_db)):
    query = {}
    for k, v in {"entity_id": entity_id, "entity_type": entity_type, "event_type": event_type, "snapshot_batch_id": snapshot_batch_id}.items():
        if v: query[k] = v
    rows = [serialize_mongo(x) async for x in db.audit_logs.find(query).sort("created_at_utc", -1).limit(limit)]
    return envelope("/api/audit", {"logs": rows, "summary": {"logs_returned": len(rows)}})


@discrepancies_router.get("")
async def discrepancies(asset_id: Optional[str] = None, comparison_type: Optional[str] = None, country_code: Optional[str] = None, snapshot_batch_id: Optional[str] = None, limit: int = 100, db: AsyncIOMotorDatabase = Depends(get_db)):
    query = {}
    for k, v in {"asset_id": asset_id, "comparison_type": comparison_type, "country_code": country_code, "snapshot_batch_id": snapshot_batch_id}.items():
        if v: query[k] = v
    rows = [serialize_mongo(x) async for x in db.discrepancy_records.find(query).sort("canonical_timestamp_utc", -1).limit(limit)]
    return envelope("/api/discrepancies", {"records": rows, "summary": {"records_returned": len(rows)}}, warnings=["Discrepancy records are documentation only, not trading signals."])
