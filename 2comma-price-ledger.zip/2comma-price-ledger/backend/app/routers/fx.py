from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/latest")
async def fx_latest(
    pairs: Optional[str] = None,
    rate_type: Optional[str] = None,
    aligned_interval: Optional[str] = None,
    include_stale: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {}
    if pairs:
        query["asset_id"] = {"$in": [x.strip().upper() for x in pairs.split(",") if x.strip()]}
    if rate_type:
        query["rate_type"] = rate_type
    if aligned_interval:
        query["aligned_interval"] = aligned_interval
    if not include_stale:
        query["is_stale"] = {"$ne": True}
    rows = [serialize_mongo(x) async for x in db.fx_rate_events.find(query).sort("canonical_timestamp_utc", -1).limit(100)]
    return envelope("/api/fx/latest", {"rates": rows, "summary": {"pairs_returned": len(rows)}})
