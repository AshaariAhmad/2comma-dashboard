from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/{country_code}/prices")
async def country_prices(
    country_code: str,
    category: Optional[str] = None,
    asset_id: Optional[str] = None,
    date: Optional[str] = None,
    include_stale: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    cc = country_code.upper()
    # Prefer energy country snapshots for fuel category.
    if category == "fuel" or asset_id in {"RON95_MY", "RON97_MY", "DIESEL_MY"}:
        doc = await db.energy_country_snapshots.find_one({"country_code": cc}, sort=[("canonical_timestamp_utc", -1)])
        if not doc:
            raise HTTPException(status_code=404, detail="No country fuel snapshot found.")
        data = serialize_mongo(doc)
        data["prices"] = data.get("energy_prices", [])
    else:
        query = {"country_code": cc}
        if asset_id:
            query["asset_id"] = asset_id
        rows = [serialize_mongo(x) async for x in db.normalized_price_events.find(query).sort("canonical_timestamp_utc", -1).limit(100)]
        data = {"country_code": cc, "category": category, "prices": rows}
    return envelope(f"/api/countries/{country_code}/prices", data)
