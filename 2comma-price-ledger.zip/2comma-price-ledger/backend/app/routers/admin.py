from __future__ import annotations

from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db, init_indexes
from app.routers.utils import envelope
from app.seed.seed_data import seed_all, seed_sample_prices

router = APIRouter()


@router.post("/init-db")
async def init_db(db: AsyncIOMotorDatabase = Depends(get_db)):
    await init_indexes(db)
    return envelope("/api/admin/init-db", {"message": "Indexes initialized."})


@router.post("/seed-catalogs")
async def seed_catalogs(db: AsyncIOMotorDatabase = Depends(get_db)):
    result = await seed_all(db)
    return envelope("/api/admin/seed-catalogs", result)


@router.post("/seed-sample-data")
async def seed_sample_data(db: AsyncIOMotorDatabase = Depends(get_db)):
    result = await seed_sample_prices(db)
    return envelope("/api/admin/seed-sample-data", result)
