from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.database import get_db
from app.routers.utils import envelope, serialize_mongo

router = APIRouter()


@router.get("/{metal_id}/countries")
async def metals_countries(
    metal_id: str,
    date: Optional[str] = None,
    country_code: Optional[str] = None,
    product_type: Optional[str] = None,
    include_stale: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    query = {"metal_id": metal_id.upper()}
    doc = await db.metals_country_snapshots.find_one(query, sort=[("canonical_timestamp_utc", -1)])
    if not doc:
        raise HTTPException(status_code=404, detail="No metals country snapshot found.")
    data = serialize_mongo(doc)
    data["countries"] = data.get("country_prices", [])
    if country_code:
        data["countries"] = [x for x in data["countries"] if x.get("country_code") == country_code.upper()]
    if product_type:
        data["countries"] = [x for x in data["countries"] if x.get("product_type") == product_type]
    return envelope(f"/api/metals/{metal_id}/countries", data)
