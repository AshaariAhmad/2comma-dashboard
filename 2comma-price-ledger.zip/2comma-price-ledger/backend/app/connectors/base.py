from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict


class BaseConnector(ABC):
    """Base connector interface. Production connectors should implement fetch()."""

    @abstractmethod
    async def fetch(self) -> Dict:
        raise NotImplementedError
