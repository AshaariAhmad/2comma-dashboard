from __future__ import annotations

from datetime import datetime
from random import random
from typing import Dict

from app.connectors.base import BaseConnector


class MockCryptoConnector(BaseConnector):
    """Mock connector for local testing only. Disable in production."""

    def __init__(self, platform: str, exchange_id: str, symbol: str = "BTC/USDT") -> None:
        self.platform = platform
        self.exchange_id = exchange_id
        self.symbol = symbol

    async def fetch(self) -> Dict:
        now = datetime.utcnow()
        last = 103000 + random() * 1000
        bid = last - 1.5
        ask = last + 1.5
        return {
            "platform": self.platform,
            "exchange_id": self.exchange_id,
            "symbol": self.symbol,
            "timestamp": now.isoformat() + "Z",
            "bid": bid,
            "ask": ask,
            "last": last,
            "volume_24h": 10000 + random() * 5000,
            "raw": {"mock": True},
        }
