from __future__ import annotations

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import get_settings
from app.database import get_db
from app.jobs.mock_ingestion_job import run_mock_crypto_ingestion

scheduler = AsyncIOScheduler(timezone="UTC")


def start_scheduler() -> None:
    settings = get_settings()
    if not settings.enable_scheduler:
        return
    if settings.enable_mock_ingestion:
        scheduler.add_job(
            run_mock_crypto_ingestion,
            trigger="interval",
            seconds=settings.mock_ingestion_seconds,
            id="mock_crypto_ingestion",
            replace_existing=True,
            kwargs={"db_getter": get_db},
        )
    scheduler.start()


def shutdown_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
