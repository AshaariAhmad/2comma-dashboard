from __future__ import annotations

from datetime import datetime

from app.connectors.mock_connector import MockCryptoConnector
from app.services.normalization_service import normalize_raw_price
from app.services.snapshot_service import generate_aligned_snapshot
from app.services.time_utils import ensure_utc

EXPECTED = ["CCXT_BINANCE", "CCXT_COINBASE", "CCXT_KRAKEN", "CCXT_OKX", "CCXT_BYBIT", "CCXT_BITSTAMP", "CCXT_BITFINEX", "CCXT_KUCOIN", "CCXT_GATEIO", "CCXT_CRYPTOCOM"]


async def run_mock_crypto_ingestion(db_getter):
    db = db_getter()
    platforms = [
        ("Binance", "binance", "BINANCE_SPOT", "CCXT_BINANCE", "BTC/USDT"),
        ("Coinbase", "coinbase", "COINBASE_SPOT", "CCXT_COINBASE", "BTC/USD"),
    ]
    normalized_docs = []
    for platform, exchange_id, venue_id, source_id, symbol in platforms:
        payload = await MockCryptoConnector(platform, exchange_id, symbol).fetch()
        base, quote = symbol.split("/")
        raw = {
            "asset_id": base,
            "asset_type": "crypto",
            "platform": platform,
            "exchange_id": exchange_id,
            "venue_id": venue_id,
            "source_id": source_id,
            "country_code": "GLOBAL",
            "market_type": "spot",
            "raw_symbol": symbol.replace("/", ""),
            "symbol": symbol,
            "base_asset": base,
            "quote_asset": quote,
            "quote_currency": quote,
            "price_type": "ticker",
            "bid": payload["bid"],
            "ask": payload["ask"],
            "last": payload["last"],
            "mid": (payload["bid"] + payload["ask"]) / 2,
            "volume": payload["volume_24h"],
            "volume_24h": payload["volume_24h"],
            "source_timestamp_utc": ensure_utc(payload["timestamp"]),
            "ingested_at_utc": datetime.utcnow(),
            "source_payload": payload,
            "quality_score": 0.97,
        }
        raw_result = await db.crypto_raw_quotes.insert_one(raw)
        raw["raw_payload_reference"] = {"collection": "crypto_raw_quotes", "document_id": str(raw_result.inserted_id)}
        norm = await normalize_raw_price(db, raw, interval="1m", batch_prefix="BTC", allowed_staleness_seconds=60, target_collection="crypto_normalized_quotes")
        normalized_docs.append(norm)

    if normalized_docs:
        sid = normalized_docs[0]["snapshot_batch_id"]
        snapshot = await generate_aligned_snapshot(db, snapshot_batch_id=sid, comparison_group="BTC_USD_10_EXCHANGES", asset_id="BTC", source_collection="crypto_normalized_quotes", target_collection="crypto_aligned_snapshots", expected_sources=EXPECTED)
        if snapshot:
            generic = dict(snapshot)
            await db.aligned_price_snapshots.update_one({"snapshot_batch_id": sid}, {"$set": generic}, upsert=True)
