from functools import lru_cache
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from .env or environment variables."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = Field(default="2 Comma Global Price Documentation Ledger", alias="APP_NAME")
    app_env: str = Field(default="local", alias="APP_ENV")
    app_host: str = Field(default="0.0.0.0", alias="APP_HOST")
    app_port: int = Field(default=8000, alias="APP_PORT")

    mongodb_uri: str = Field(default="mongodb://localhost:27017", alias="MONGODB_URI")
    mongodb_db: str = Field(default="two_comma_price_ledger", alias="MONGODB_DB")

    cors_origins: str = Field(default="*", alias="CORS_ORIGINS")

    enable_scheduler: bool = Field(default=True, alias="ENABLE_SCHEDULER")
    enable_mock_ingestion: bool = Field(default=False, alias="ENABLE_MOCK_INGESTION")
    mock_ingestion_seconds: int = Field(default=60, alias="MOCK_INGESTION_SECONDS")

    default_crypto_interval: str = Field(default="1m", alias="DEFAULT_CRYPTO_INTERVAL")
    default_allowed_staleness_seconds: int = Field(default=60, alias="DEFAULT_ALLOWED_STALENESS_SECONDS")
    default_canonical_quote_currency: str = Field(default="USD", alias="DEFAULT_CANONICAL_QUOTE_CURRENCY")

    source_timeout_seconds: int = Field(default=20, alias="SOURCE_TIMEOUT_SECONDS")
    max_retry_count: int = Field(default=3, alias="MAX_RETRY_COUNT")

    @property
    def cors_origin_list(self) -> List[str]:
        if self.cors_origins.strip() == "*":
            return ["*"]
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
