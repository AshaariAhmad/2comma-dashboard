from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import close_mongo_connection, connect_to_mongo
from app.jobs.scheduler import shutdown_scheduler, start_scheduler
from app.routers import crypto, metals, energy, countries, equities, fx, snapshots, admin
from app.routers.logs import audit_router, data_quality_router, discrepancies_router, source_health_router

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="MongoDB NoSQL price documentation ledger. No ML, no prediction, no trading signals.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup() -> None:
    await connect_to_mongo()
    start_scheduler()


@app.on_event("shutdown")
async def shutdown() -> None:
    shutdown_scheduler()
    await close_mongo_connection()


@app.get("/health")
async def health():
    return {"status": "ok", "app": settings.app_name, "env": settings.app_env}


app.include_router(snapshots.router, prefix="/api/snapshots", tags=["Snapshots"])
# Alias requested by the user: /api/snapshot-batches/{id}
app.include_router(snapshots.router, prefix="/api/snapshot-batches", tags=["Snapshot Batches"])
app.include_router(crypto.router, prefix="/api/crypto", tags=["Crypto"])
app.include_router(metals.router, prefix="/api/metals", tags=["Metals"])
app.include_router(energy.router, prefix="/api/energy", tags=["Energy"])
app.include_router(countries.router, prefix="/api/countries", tags=["Countries"])
app.include_router(equities.router, prefix="/api/equities", tags=["Equities"])
app.include_router(fx.router, prefix="/api/fx", tags=["FX"])
app.include_router(source_health_router, prefix="/api/source-health", tags=["Source Health"])
app.include_router(data_quality_router, prefix="/api/data-quality", tags=["Data Quality"])
app.include_router(audit_router, prefix="/api/audit", tags=["Audit"])
app.include_router(discrepancies_router, prefix="/api/discrepancies", tags=["Discrepancies"])
app.include_router(admin.router, prefix="/api/admin", tags=["Admin"])
