from __future__ import annotations

from typing import Optional

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pymongo import ASCENDING, DESCENDING

from app.config import get_settings

_client: Optional[AsyncIOMotorClient] = None
_db: Optional[AsyncIOMotorDatabase] = None


async def connect_to_mongo() -> None:
    """Create a global Motor client and initialize indexes."""
    global _client, _db
    settings = get_settings()
    _client = AsyncIOMotorClient(settings.mongodb_uri)
    _db = _client[settings.mongodb_db]
    await _db.command("ping")
    await init_indexes(_db)


async def close_mongo_connection() -> None:
    global _client, _db
    if _client is not None:
        _client.close()
    _client = None
    _db = None


def get_db() -> AsyncIOMotorDatabase:
    if _db is None:
        raise RuntimeError("MongoDB is not connected yet.")
    return _db


async def init_indexes(db: AsyncIOMotorDatabase) -> None:
    """Create production indexes. Safe to run repeatedly."""

    # Catalogs
    await db.asset_catalog.create_index([("asset_id", ASCENDING)], unique=True)
    await db.asset_catalog.create_index([("asset_type", ASCENDING), ("category", ASCENDING)])
    await db.venue_catalog.create_index([("venue_id", ASCENDING)], unique=True)
    await db.country_catalog.create_index([("country_code", ASCENDING)], unique=True)
    await db.source_catalog.create_index([("source_id", ASCENDING)], unique=True)

    # Generic price collections
    await db.raw_price_events.create_index([("asset_id", ASCENDING), ("source_id", ASCENDING), ("ingested_at_utc", DESCENDING)])
    await db.normalized_price_events.create_index([("asset_id", ASCENDING), ("canonical_timestamp_utc", DESCENDING), ("aligned_interval", ASCENDING)])
    await db.normalized_price_events.create_index([("snapshot_batch_id", ASCENDING)])
    await db.aligned_price_snapshots.create_index([("snapshot_batch_id", ASCENDING)], unique=True)
    await db.aligned_price_snapshots.create_index([("comparison_group", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])
    await db.snapshot_batches.create_index([("snapshot_batch_id", ASCENDING)], unique=True)

    # Domain snapshots / normalized collections
    for collection in [
        "crypto_normalized_quotes", "metals_normalized_prices", "energy_normalized_prices", "equity_normalized_prices", "fx_rate_events",
    ]:
        await db[collection].create_index([("snapshot_batch_id", ASCENDING)])
        await db[collection].create_index([("asset_id", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])

    await db.crypto_aligned_snapshots.create_index([("snapshot_batch_id", ASCENDING)], unique=True)
    await db.crypto_aligned_snapshots.create_index([("base_asset", ASCENDING), ("aligned_interval", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])
    await db.metals_country_snapshots.create_index([("snapshot_batch_id", ASCENDING)], unique=True)
    await db.metals_country_snapshots.create_index([("metal_id", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])
    await db.energy_country_snapshots.create_index([("snapshot_batch_id", ASCENDING)], unique=True)
    await db.energy_country_snapshots.create_index([("country_code", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])
    await db.equity_market_snapshots.create_index([("snapshot_batch_id", ASCENDING)], unique=True)
    await db.equity_market_snapshots.create_index([("ticker", ASCENDING), ("related_asset_id", ASCENDING), ("canonical_timestamp_utc", DESCENDING)])

    # Logs
    await db.source_health_logs.create_index([("source_id", ASCENDING), ("checked_at_utc", DESCENDING)])
    await db.source_health_logs.create_index([("status", ASCENDING), ("severity", ASCENDING), ("checked_at_utc", DESCENDING)])
    await db.data_quality_logs.create_index([("severity", ASCENDING), ("created_at_utc", DESCENDING)])
    await db.data_quality_logs.create_index([("issue_type", ASCENDING), ("created_at_utc", DESCENDING)])
    await db.audit_logs.create_index([("entity_type", ASCENDING), ("entity_id", ASCENDING), ("created_at_utc", DESCENDING)])
    await db.audit_logs.create_index([("snapshot_batch_id", ASCENDING), ("created_at_utc", DESCENDING)])
    await db.transformation_logs.create_index([("pipeline_run_id", ASCENDING), ("stage_order", ASCENDING)])
    await db.rejected_events.create_index([("reason_code", ASCENDING), ("created_at_utc", DESCENDING)])
    await db.manual_review_queue.create_index([("queue_status", ASCENDING), ("severity", ASCENDING), ("created_at_utc", DESCENDING)])

    # Fast dashboard cache with TTL.
    await db.dashboard_cache.create_index([("cache_key", ASCENDING)], unique=True)
    await db.dashboard_cache.create_index([("expires_at_utc", ASCENDING)], expireAfterSeconds=0)
