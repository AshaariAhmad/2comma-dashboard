from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field

from app.schemas.common import TimestampContract


class RawPriceEvent(BaseModel):
    asset_id: str
    asset_type: str
    venue_id: str
    source_id: str
    country_code: str = "GLOBAL"
    raw_symbol: str
    quote_currency: Optional[str] = None
    price_type: str = "last"
    bid: Optional[float] = None
    ask: Optional[float] = None
    last: Optional[float] = None
    mid: Optional[float] = None
    volume: Optional[float] = None
    source_timestamp_utc: Optional[datetime] = None
    ingested_at_utc: datetime = Field(default_factory=datetime.utcnow)
    raw_payload: Dict[str, Any] = Field(default_factory=dict)


class NormalizedPriceEvent(RawPriceEvent, TimestampContract):
    normalized_currency: str = "USD"
    normalized_unit: Optional[str] = None
    normalized_bid: Optional[float] = None
    normalized_ask: Optional[float] = None
    normalized_last: Optional[float] = None
    normalized_mid: Optional[float] = None
    quality_score: float = 1.0
    market_status: str = "open"
    raw_payload_reference: Optional[Dict[str, str]] = None
