from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class TimestampContract(BaseModel):
    source_timestamp_utc: Optional[datetime] = None
    ingested_at_utc: datetime
    canonical_timestamp_utc: Optional[datetime] = None
    aligned_interval: Optional[str] = None
    snapshot_batch_id: Optional[str] = None
    freshness_seconds: Optional[float] = None
    source_latency_seconds: Optional[float] = None
    is_stale: bool = False
    alignment_method: Optional[str] = None
    alignment_confidence: Optional[float] = None


class ApiEnvelope(BaseModel):
    status: str = "ok"
    endpoint: str
    request: Dict[str, Any] = Field(default_factory=dict)
    data: Dict[str, Any] = Field(default_factory=dict)
    warnings: List[str] = Field(default_factory=list)
    server_time_utc: datetime = Field(default_factory=datetime.utcnow)
