from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Tuple


def run_basic_quality_checks(doc: Dict) -> Tuple[bool, float, List[Dict]]:
    """Deterministic quality checks. Returns accepted, score, issue list."""
    issues: List[Dict] = []
    score = float(doc.get("quality_score", 1.0))

    bid = doc.get("bid")
    ask = doc.get("ask")
    vol = doc.get("volume") or doc.get("volume_24h")

    if bid is not None and ask is not None and bid > ask:
        issues.append({
            "severity": "error",
            "issue_type": "bid_higher_than_ask",
            "reason_code": "BID_HIGHER_THAN_ASK",
            "decision": "rejected",
            "explanation": "Bid price is higher than ask price. Record cannot be safely normalized.",
        })
        score = 0.0
        return False, score, issues

    if doc.get("source_timestamp_utc") is None:
        issues.append({
            "severity": "warning",
            "issue_type": "missing_source_timestamp",
            "reason_code": "MISSING_SOURCE_TIMESTAMP",
            "decision": "accepted_with_warning",
            "explanation": "Source timestamp missing. Ingestion timestamp fallback should be used.",
        })
        score = min(score, 0.72)

    if doc.get("is_stale") is True:
        issues.append({
            "severity": "warning",
            "issue_type": "stale_quote",
            "reason_code": "STALE_QUOTE",
            "decision": "marked_stale",
            "explanation": "Record is older than allowed staleness for its interval.",
        })
        score = min(score, 0.45)

    if vol == 0:
        issues.append({
            "severity": "warning",
            "issue_type": "zero_volume",
            "reason_code": "ZERO_VOLUME",
            "decision": "accepted_with_warning",
            "explanation": "Volume is zero where volume is expected. Record is kept but flagged.",
        })
        score = min(score, 0.75)

    return True, score, issues


async def write_quality_logs(db, doc: Dict, issues: List[Dict]) -> None:
    if not issues:
        return
    now = datetime.utcnow()
    rows = []
    for issue in issues:
        rows.append({
            "quality_log_id": f"DQ_{doc.get('asset_id','UNKNOWN')}_{doc.get('source_id','UNKNOWN')}_{now.strftime('%Y%m%d_%H%M%S_%f')}",
            "event_type": "data_quality_check",
            "asset_id": doc.get("asset_id"),
            "asset_type": doc.get("asset_type"),
            "venue_id": doc.get("venue_id"),
            "source_id": doc.get("source_id"),
            "country_code": doc.get("country_code"),
            "raw_symbol": doc.get("raw_symbol") or doc.get("symbol"),
            "source_timestamp_utc": doc.get("source_timestamp_utc"),
            "ingested_at_utc": doc.get("ingested_at_utc"),
            "canonical_timestamp_utc": doc.get("canonical_timestamp_utc"),
            "aligned_interval": doc.get("aligned_interval"),
            "snapshot_batch_id": doc.get("snapshot_batch_id"),
            "is_stale": doc.get("is_stale", False),
            "quality_score_after": doc.get("quality_score"),
            "created_at_utc": now,
            "status": "open",
            **issue,
        })
    await db.data_quality_logs.insert_many(rows)
