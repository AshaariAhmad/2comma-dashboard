from __future__ import annotations

from datetime import datetime
from typing import Dict

from app.services.quality_service import run_basic_quality_checks, write_quality_logs
from app.services.timestamp_alignment import align_timestamp
from app.services.audit_service import write_audit_log


def calculate_mid(bid, ask, last):
    if bid is not None and ask is not None:
        return (float(bid) + float(ask)) / 2
    if last is not None:
        return float(last)
    return None


async def normalize_raw_price(
    db,
    raw_doc: Dict,
    *,
    interval: str = "1m",
    batch_prefix: str | None = None,
    allowed_staleness_seconds: int | None = 60,
    target_collection: str = "normalized_price_events",
) -> Dict:
    """Normalize a raw document into a generic normalized price event."""
    ingested = raw_doc.get("ingested_at_utc") or datetime.utcnow()
    source_time = raw_doc.get("source_timestamp_utc")
    batch_prefix = batch_prefix or raw_doc.get("asset_id", "PRICE")

    normalized = dict(raw_doc)
    normalized["mid"] = normalized.get("mid") or calculate_mid(normalized.get("bid"), normalized.get("ask"), normalized.get("last"))
    normalized["normalized_currency"] = normalized.get("normalized_currency") or "USD"
    normalized["normalized_mid"] = normalized.get("normalized_mid") or normalized.get("mid")
    normalized["quality_score"] = normalized.get("quality_score", 1.0)

    normalized.update(align_timestamp(
        source_timestamp_utc=source_time,
        ingested_at_utc=ingested,
        interval=interval,
        batch_prefix=batch_prefix,
        allowed_staleness_seconds=allowed_staleness_seconds,
    ))

    accepted, score, issues = run_basic_quality_checks(normalized)
    normalized["quality_score"] = score
    await write_quality_logs(db, normalized, issues)

    if not accepted:
        await db.rejected_events.insert_one({
            "rejected_event_id": f"REJ_{batch_prefix}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')}",
            "rejection_stage": "quality_check",
            "severity": "error",
            "reason_code": issues[0]["reason_code"],
            "issue_type": issues[0]["issue_type"],
            "decision": "rejected",
            "asset_id": normalized.get("asset_id"),
            "asset_type": normalized.get("asset_type"),
            "source_id": normalized.get("source_id"),
            "venue_id": normalized.get("venue_id"),
            "country_code": normalized.get("country_code"),
            "raw_symbol": normalized.get("raw_symbol"),
            "source_timestamp_utc": normalized.get("source_timestamp_utc"),
            "ingested_at_utc": normalized.get("ingested_at_utc"),
            "canonical_timestamp_utc": normalized.get("canonical_timestamp_utc"),
            "aligned_interval": normalized.get("aligned_interval"),
            "snapshot_batch_id": normalized.get("snapshot_batch_id"),
            "is_stale": normalized.get("is_stale"),
            "quality_score": 0.0,
            "explanation": issues[0]["explanation"],
            "raw_payload_reference": normalized.get("raw_payload_reference"),
            "can_retry": False,
            "manual_review_required": True,
            "created_at_utc": datetime.utcnow(),
        })
        await write_audit_log(db, event_type="rejection", action="rejected", entity_type="raw_event", entity_id=str(raw_doc.get("_id", "unknown")), doc=normalized, explanation=issues[0]["explanation"], reason_codes=[issues[0]["reason_code"]])
        return normalized

    result = await db[target_collection].insert_one(normalized)
    normalized["_id"] = result.inserted_id
    await write_audit_log(db, event_type="normalization", action="created_normalized_price_event", entity_type="normalized_event", entity_id=str(result.inserted_id), doc=normalized, explanation="Raw price was normalized and timestamp aligned.")
    return normalized
