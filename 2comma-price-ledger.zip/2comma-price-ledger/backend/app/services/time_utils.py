from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional
from dateutil import parser as date_parser


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def ensure_utc(value: Optional[datetime | str | int | float]) -> Optional[datetime]:
    """Convert common timestamp values into naive UTC datetime for MongoDB consistency."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        # Accept seconds or milliseconds epoch.
        if value > 10_000_000_000:
            value = value / 1000
        return datetime.fromtimestamp(value, tz=timezone.utc).replace(tzinfo=None)
    if isinstance(value, str):
        dt = date_parser.parse(value)
    elif isinstance(value, datetime):
        dt = value
    else:
        raise TypeError(f"Unsupported timestamp type: {type(value)!r}")
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc).replace(tzinfo=None)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)
