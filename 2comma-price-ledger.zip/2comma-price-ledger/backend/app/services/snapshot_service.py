from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from app.services.audit_service import write_audit_log


def _clean_for_json(doc: Dict) -> Dict:
    out = dict(doc)
    out.pop("_id", None)
    return out


async def get_latest_snapshot(db, filters: Dict) -> Optional[Dict]:
    query = {k: v for k, v in filters.items() if v not in (None, "")}
    return await db.aligned_price_snapshots.find_one(query, sort=[("canonical_timestamp_utc", -1)])


async def create_snapshot_batch(db, *, snapshot_batch_id: str, comparison_group: str, asset_ids: List[str], canonical_timestamp_utc, aligned_interval: str, expected_sources: Optional[List[str]] = None) -> Dict:
    doc = {
        "snapshot_batch_id": snapshot_batch_id,
        "comparison_group": comparison_group,
        "asset_ids": asset_ids,
        "canonical_timestamp_utc": canonical_timestamp_utc,
        "aligned_interval": aligned_interval,
        "expected_sources": expected_sources or [],
        "available_sources": [],
        "missing_sources": expected_sources or [],
        "stale_sources": [],
        "status": "building",
        "created_at_utc": datetime.utcnow(),
    }
    await db.snapshot_batches.update_one({"snapshot_batch_id": snapshot_batch_id}, {"$setOnInsert": doc}, upsert=True)
    return doc


async def generate_aligned_snapshot(
    db,
    *,
    snapshot_batch_id: str,
    comparison_group: str,
    asset_id: str,
    source_collection: str = "normalized_price_events",
    target_collection: str = "aligned_price_snapshots",
    expected_sources: Optional[List[str]] = None,
) -> Optional[Dict]:
    cursor = db[source_collection].find({"snapshot_batch_id": snapshot_batch_id})
    records = [_clean_for_json(x) async for x in cursor]
    if not records:
        return None
    expected_sources = expected_sources or []
    available = sorted({r.get("source_id") for r in records if r.get("source_id")})
    stale = sorted({r.get("source_id") for r in records if r.get("is_stale") and r.get("source_id")})
    missing = sorted(set(expected_sources) - set(available)) if expected_sources else []
    prices = []
    valid_prices = []
    for r in records:
        price = r.get("normalized_mid") or r.get("price_usd_normalized") or r.get("price_usd_per_troy_ounce") or r.get("rate")
        prices.append({**r, "display_price": price})
        if price is not None and not r.get("is_stale"):
            valid_prices.append(float(price))
    summary = {
        "expected_sources": len(expected_sources),
        "available_sources": len(available),
        "missing_sources": missing,
        "stale_sources": stale,
        "min_price": min(valid_prices) if valid_prices else None,
        "max_price": max(valid_prices) if valid_prices else None,
        "difference_absolute": (max(valid_prices) - min(valid_prices)) if len(valid_prices) >= 2 else 0,
        "difference_pct": ((max(valid_prices) - min(valid_prices)) / min(valid_prices) * 100) if len(valid_prices) >= 2 and min(valid_prices) else 0,
    }
    base = records[0]
    doc = {
        "snapshot_batch_id": snapshot_batch_id,
        "comparison_group": comparison_group,
        "asset_id": asset_id,
        "asset_type": base.get("asset_type"),
        "canonical_timestamp_utc": base.get("canonical_timestamp_utc"),
        "aligned_interval": base.get("aligned_interval"),
        "interval_start_utc": base.get("interval_start_utc"),
        "interval_end_utc": base.get("interval_end_utc"),
        "prices": prices,
        "summary": summary,
        "created_at_utc": datetime.utcnow(),
    }
    await db[target_collection].update_one({"snapshot_batch_id": snapshot_batch_id}, {"$set": doc}, upsert=True)
    await db.snapshot_batches.update_one({"snapshot_batch_id": snapshot_batch_id}, {"$set": {"status": "completed", "available_sources": available, "missing_sources": missing, "stale_sources": stale, "quality_summary": summary}})
    await write_audit_log(db, event_type="snapshot", action="generated_aligned_snapshot", entity_type="snapshot", entity_id=snapshot_batch_id, doc=doc, explanation="Aligned snapshot generated from normalized records.")
    return doc
