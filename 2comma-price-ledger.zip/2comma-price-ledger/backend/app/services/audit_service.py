from __future__ import annotations

from datetime import datetime
from typing import Dict, Iterable, Optional


async def write_audit_log(
    db,
    *,
    event_type: str,
    action: str,
    entity_type: str,
    entity_id: str,
    doc: Optional[Dict] = None,
    explanation: str = "",
    rule_ids: Optional[Iterable[str]] = None,
    reason_codes: Optional[Iterable[str]] = None,
    before: Optional[Dict] = None,
    after: Optional[Dict] = None,
) -> None:
    now = datetime.utcnow()
    d = doc or {}
    await db.audit_logs.insert_one({
        "audit_id": f"AUDIT_{event_type.upper()}_{now.strftime('%Y%m%d_%H%M%S_%f')}",
        "event_type": event_type,
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "actor": "system",
        "asset_id": d.get("asset_id"),
        "source_id": d.get("source_id"),
        "venue_id": d.get("venue_id"),
        "country_code": d.get("country_code"),
        "source_timestamp_utc": d.get("source_timestamp_utc"),
        "ingested_at_utc": d.get("ingested_at_utc"),
        "canonical_timestamp_utc": d.get("canonical_timestamp_utc"),
        "aligned_interval": d.get("aligned_interval"),
        "snapshot_batch_id": d.get("snapshot_batch_id"),
        "is_stale": d.get("is_stale"),
        "quality_score": d.get("quality_score"),
        "before": before,
        "after": after,
        "rule_ids": list(rule_ids or []),
        "reason_codes": list(reason_codes or []),
        "explanation": explanation,
        "created_at_utc": now,
    })
