from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, Optional


def floor_datetime(dt: datetime, interval: str) -> tuple[datetime, datetime]:
    """Return interval start and end for supported canonical buckets."""
    if interval == "5s":
        sec = (dt.second // 5) * 5
        start = dt.replace(second=sec, microsecond=0)
        end = start + timedelta(seconds=5) - timedelta(microseconds=1)
    elif interval == "1m":
        start = dt.replace(second=0, microsecond=0)
        end = start + timedelta(minutes=1) - timedelta(microseconds=1)
    elif interval == "5m":
        minute = (dt.minute // 5) * 5
        start = dt.replace(minute=minute, second=0, microsecond=0)
        end = start + timedelta(minutes=5) - timedelta(microseconds=1)
    elif interval == "1h":
        start = dt.replace(minute=0, second=0, microsecond=0)
        end = start + timedelta(hours=1) - timedelta(microseconds=1)
    elif interval == "1d":
        start = dt.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1) - timedelta(microseconds=1)
    elif interval == "1w":
        # ISO week starts Monday. This is a generic weekly bucket.
        start = (dt - timedelta(days=dt.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7) - timedelta(microseconds=1)
    elif interval == "1mo":
        start = dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if start.month == 12:
            next_month = start.replace(year=start.year + 1, month=1)
        else:
            next_month = start.replace(month=start.month + 1)
        end = next_month - timedelta(microseconds=1)
    elif interval == "market_close":
        start = dt.replace(microsecond=0)
        end = start
    else:
        raise ValueError(f"Unsupported aligned_interval: {interval}")
    return start, end


def snapshot_batch_id(prefix: str, canonical_timestamp: datetime, interval: str) -> str:
    stamp = canonical_timestamp.strftime("%Y%m%d_%H%M%S")
    safe_interval = interval.upper().replace("/", "_")
    return f"SNAP_{prefix}_{stamp}_{safe_interval}"


def align_timestamp(
    *,
    source_timestamp_utc: Optional[datetime],
    ingested_at_utc: datetime,
    interval: str,
    batch_prefix: str,
    allowed_staleness_seconds: Optional[int] = 60,
    effective_date_start: Optional[datetime] = None,
    effective_date_end: Optional[datetime] = None,
) -> Dict[str, object]:
    """Create canonical timestamp fields while preserving original source time."""
    base_time = source_timestamp_utc or ingested_at_utc

    if effective_date_start and effective_date_end:
        interval_start = effective_date_start
        interval_end = effective_date_end
        canonical = effective_date_start
        is_active = effective_date_start <= ingested_at_utc <= effective_date_end
        freshness = 0 if is_active else abs((ingested_at_utc - effective_date_end).total_seconds())
        return {
            "canonical_timestamp_utc": canonical,
            "aligned_interval": interval,
            "interval_start_utc": interval_start,
            "interval_end_utc": interval_end,
            "snapshot_batch_id": snapshot_batch_id(batch_prefix, canonical, interval),
            "freshness_seconds": freshness,
            "source_latency_seconds": (ingested_at_utc - source_timestamp_utc).total_seconds() if source_timestamp_utc else None,
            "allowed_staleness_seconds": allowed_staleness_seconds,
            "is_stale": not is_active,
            "market_status": "effective_price_active" if is_active else "effective_price_expired",
            "alignment_method": "effective_date_range",
            "alignment_confidence": 0.98 if is_active else 0.40,
        }

    interval_start, interval_end = floor_datetime(base_time, interval)
    canonical = interval_start
    freshness = abs((canonical - source_timestamp_utc).total_seconds()) if source_timestamp_utc else 0
    latency = (ingested_at_utc - source_timestamp_utc).total_seconds() if source_timestamp_utc else None
    is_stale = False if allowed_staleness_seconds is None else freshness > allowed_staleness_seconds
    return {
        "canonical_timestamp_utc": canonical,
        "aligned_interval": interval,
        "interval_start_utc": interval_start,
        "interval_end_utc": interval_end,
        "snapshot_batch_id": snapshot_batch_id(batch_prefix, canonical, interval),
        "freshness_seconds": freshness,
        "source_latency_seconds": latency,
        "allowed_staleness_seconds": allowed_staleness_seconds,
        "is_stale": is_stale,
        "market_status": "open",
        "alignment_method": "same_bucket_latest" if source_timestamp_utc else "ingestion_time_fallback",
        "alignment_confidence": 0.98 if source_timestamp_utc else 0.65,
    }
