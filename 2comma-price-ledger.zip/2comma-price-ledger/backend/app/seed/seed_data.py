from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, List

from app.services.timestamp_alignment import align_timestamp


ASSETS = [
    {"asset_id": "BTC", "asset_name": "Bitcoin", "asset_type": "crypto", "category": "crypto", "subcategory": "layer_1_store_of_value", "base_unit": "BTC", "benchmark_unit": "USD_per_BTC", "common_quote_currencies": ["USD", "USDT", "USDC", "EUR", "MYR", "SGD"], "physical_or_digital": "digital", "country_specific": False, "requires_purity_adjustment": False, "requires_fx_conversion": True, "requires_tax_fee_adjustment": True, "allowed_price_types": ["bid", "ask", "last", "mid", "spot"], "preferred_benchmark_asset_id": "BTC_USD_GLOBAL_COMPOSITE", "notes": "Track across major crypto platforms."},
    {"asset_id": "ETH", "asset_name": "Ethereum", "asset_type": "crypto", "category": "crypto", "subcategory": "layer_1_smart_contract", "base_unit": "ETH", "benchmark_unit": "USD_per_ETH", "common_quote_currencies": ["USD", "USDT", "USDC", "EUR"], "physical_or_digital": "digital", "country_specific": False, "requires_purity_adjustment": False, "requires_fx_conversion": True, "requires_tax_fee_adjustment": True, "allowed_price_types": ["bid", "ask", "last", "mid", "spot"], "preferred_benchmark_asset_id": "ETH_USD_GLOBAL_COMPOSITE", "notes": "Track across major crypto platforms."},
    {"asset_id": "XAU", "asset_name": "Gold", "asset_type": "precious_metal", "category": "metals", "subcategory": "precious_metal", "base_unit": "troy_ounce", "benchmark_unit": "USD_per_troy_ounce", "common_quote_currencies": ["USD", "MYR", "SGD", "INR", "CNY"], "physical_or_digital": "physical", "country_specific": True, "requires_purity_adjustment": True, "requires_fx_conversion": True, "requires_tax_fee_adjustment": True, "allowed_price_types": ["spot", "benchmark", "retail", "bar", "coin", "jewellery"], "preferred_benchmark_asset_id": "XAU_GLOBAL_BENCHMARK", "notes": "Supports 24K, 22K, 18K, 999 and 916."},
    {"asset_id": "BRENT_CRUDE", "asset_name": "Brent Crude Oil", "asset_type": "energy", "category": "energy", "subcategory": "crude_oil", "base_unit": "barrel", "benchmark_unit": "USD_per_barrel", "common_quote_currencies": ["USD"], "physical_or_digital": "physical", "country_specific": False, "requires_purity_adjustment": False, "requires_fx_conversion": False, "requires_tax_fee_adjustment": True, "allowed_price_types": ["spot", "benchmark", "futures", "settlement"], "preferred_benchmark_asset_id": "BRENT_CRUDE", "notes": "International crude benchmark."},
    {"asset_id": "RON95_MY", "asset_name": "Malaysia RON95 Petrol", "asset_type": "energy", "category": "energy", "subcategory": "country_retail_fuel", "base_unit": "litre", "benchmark_unit": "MYR_per_litre", "common_quote_currencies": ["MYR", "USD"], "physical_or_digital": "physical", "country_specific": True, "requires_purity_adjustment": False, "requires_fx_conversion": True, "requires_tax_fee_adjustment": True, "allowed_price_types": ["government_administered", "retail", "effective_weekly"], "preferred_benchmark_asset_id": "BRENT_CRUDE", "notes": "Use effective-date logic."},
    {"asset_id": "COIN", "asset_name": "Coinbase Global Inc.", "asset_type": "equity", "category": "stocks_etfs", "subcategory": "crypto_related_equity", "base_unit": "share", "benchmark_unit": "USD_per_share", "common_quote_currencies": ["USD"], "physical_or_digital": "paper_financial", "country_specific": False, "requires_purity_adjustment": False, "requires_fx_conversion": True, "requires_tax_fee_adjustment": True, "allowed_price_types": ["open", "high", "low", "close", "adjusted_close", "bid", "ask", "last"], "preferred_benchmark_asset_id": "BTC", "notes": "Compare to BTC at market close."},
]

VENUES = [
    {"venue_id": "BINANCE_SPOT", "venue_name": "Binance Spot", "venue_type": "crypto_exchange", "country_code": "GLOBAL", "timezone": "UTC", "market_hours": "24_7", "active": True},
    {"venue_id": "COINBASE_SPOT", "venue_name": "Coinbase Spot", "venue_type": "crypto_exchange", "country_code": "US", "timezone": "UTC", "market_hours": "24_7", "active": True},
    {"venue_id": "MY_GOLD_RETAIL", "venue_name": "Malaysia Gold Retail Market", "venue_type": "country_retail_market", "country_code": "MY", "timezone": "Asia/Kuala_Lumpur", "active": True},
    {"venue_id": "BRENT_BENCHMARK_SOURCE", "venue_name": "Brent Benchmark Source", "venue_type": "energy_benchmark", "country_code": "GLOBAL", "timezone": "UTC", "active": True},
    {"venue_id": "NASDAQ", "venue_name": "NASDAQ", "venue_type": "stock_exchange", "country_code": "US", "timezone": "America/New_York", "active": True},
]

COUNTRIES = [
    {"country_code": "MY", "country_name": "Malaysia", "currency_code": "MYR", "timezone": "Asia/Kuala_Lumpur", "region": "Southeast Asia", "active": True},
    {"country_code": "SG", "country_name": "Singapore", "currency_code": "SGD", "timezone": "Asia/Singapore", "region": "Southeast Asia", "active": True},
    {"country_code": "US", "country_name": "United States", "currency_code": "USD", "timezone": "America/New_York", "region": "North America", "active": True},
    {"country_code": "GLOBAL", "country_name": "Global", "currency_code": "USD", "timezone": "UTC", "region": "Global", "active": True},
]

SOURCES = [
    {"source_id": "CCXT_BINANCE", "source_name": "Binance via CCXT", "source_type": "exchange_api", "access_method": "rest_api", "provides_source_timestamp": True, "expected_update_frequency": "5s", "allowed_staleness_seconds": 60, "active": True},
    {"source_id": "CCXT_COINBASE", "source_name": "Coinbase via CCXT", "source_type": "exchange_api", "access_method": "rest_api", "provides_source_timestamp": True, "expected_update_frequency": "5s", "allowed_staleness_seconds": 60, "active": True},
    {"source_id": "MY_GOLD_RETAIL_SOURCE", "source_name": "Malaysia Retail Gold Source", "source_type": "scraper", "access_method": "scraper", "provides_source_timestamp": True, "expected_update_frequency": "1d", "allowed_staleness_seconds": 86400, "active": True},
    {"source_id": "BRENT_BENCHMARK_API", "source_name": "Brent Benchmark API", "source_type": "benchmark_api", "access_method": "rest_api", "provides_source_timestamp": True, "expected_update_frequency": "1d", "allowed_staleness_seconds": 86400, "active": True},
]

async def upsert_many(db, collection_name: str, rows: List[Dict], key: str):
    for row in rows:
        row.setdefault("created_at_utc", datetime.utcnow())
        row["updated_at_utc"] = datetime.utcnow()
        await db[collection_name].update_one({key: row[key]}, {"$set": row}, upsert=True)


async def seed_all(db) -> Dict:
    await upsert_many(db, "asset_catalog", ASSETS, "asset_id")
    await upsert_many(db, "venue_catalog", VENUES, "venue_id")
    await upsert_many(db, "country_catalog", COUNTRIES, "country_code")
    await upsert_many(db, "source_catalog", SOURCES, "source_id")
    return {"asset_catalog": len(ASSETS), "venue_catalog": len(VENUES), "country_catalog": len(COUNTRIES), "source_catalog": len(SOURCES)}


async def seed_sample_prices(db) -> Dict:
    now = datetime.utcnow().replace(second=3, microsecond=0)
    ing = now + timedelta(seconds=2)
    # Crypto sample
    crypto_docs = []
    for platform, exchange_id, venue_id, source_id, symbol, mid in [
        ("Binance", "binance", "BINANCE_SPOT", "CCXT_BINANCE", "BTC/USDT", 103241.45),
        ("Coinbase", "coinbase", "COINBASE_SPOT", "CCXT_COINBASE", "BTC/USD", 103235.40),
    ]:
        base, quote = symbol.split("/")
        align = align_timestamp(source_timestamp_utc=now, ingested_at_utc=ing, interval="1m", batch_prefix="BTC", allowed_staleness_seconds=60)
        crypto_docs.append({
            "asset_id": "BTC", "asset_type": "crypto", "platform": platform, "exchange_id": exchange_id, "venue_id": venue_id, "source_id": source_id, "country_code": "GLOBAL", "market_type": "spot", "symbol": symbol, "raw_symbol": symbol.replace("/", ""), "base_asset": base, "quote_asset": quote, "quote_currency": quote, "bid": mid - 1.2, "ask": mid + 1.2, "last": mid, "mid": mid, "spread_bps": 0.23, "volume": 18432.91, "volume_24h": 18432.91, "normalized_currency": "USD", "normalized_mid": mid * (0.9998 if quote == "USDT" else 1.0), "source_timestamp_utc": now, "ingested_at_utc": ing, "orderbook_depth_available": True, "quality_score": 0.97, **align,
        })
    await db.crypto_normalized_quotes.insert_many(crypto_docs)
    sid = crypto_docs[0]["snapshot_batch_id"]
    snapshot = {"snapshot_batch_id": sid, "comparison_group": "BTC_USD_10_EXCHANGES", "base_asset": "BTC", "asset_id": "BTC", "asset_type": "crypto", "canonical_pair": "BTC/USD", "canonical_timestamp_utc": crypto_docs[0]["canonical_timestamp_utc"], "aligned_interval": "1m", "interval_start_utc": crypto_docs[0]["interval_start_utc"], "interval_end_utc": crypto_docs[0]["interval_end_utc"], "prices": crypto_docs, "summary": {"expected_platforms": 10, "available_platforms": 2, "missing_platforms": ["Kraken", "OKX", "Bybit", "Bitstamp", "Bitfinex", "KuCoin", "Gate.io", "Crypto.com"], "stale_platforms": [], "min_price_usd": min(x["normalized_mid"] for x in crypto_docs), "max_price_usd": max(x["normalized_mid"] for x in crypto_docs)}, "created_at_utc": datetime.utcnow()}
    await db.crypto_aligned_snapshots.update_one({"snapshot_batch_id": sid}, {"$set": snapshot}, upsert=True)
    await db.aligned_price_snapshots.update_one({"snapshot_batch_id": sid}, {"$set": snapshot}, upsert=True)
    await db.snapshot_batches.update_one({"snapshot_batch_id": sid}, {"$set": {"snapshot_batch_id": sid, "comparison_group": "BTC_USD_10_EXCHANGES", "asset_ids": ["BTC"], "asset_type": "crypto", "canonical_timestamp_utc": crypto_docs[0]["canonical_timestamp_utc"], "aligned_interval": "1m", "expected_sources": ["CCXT_BINANCE", "CCXT_COINBASE"], "available_sources": ["CCXT_BINANCE", "CCXT_COINBASE"], "missing_sources": [], "stale_sources": [], "status": "completed", "created_at_utc": datetime.utcnow()}}, upsert=True)

    # Metals sample
    gold_date = now.replace(hour=0, minute=0, second=0)
    metals_snapshot = {"snapshot_batch_id": f"SNAP_XAU_COUNTRY_{gold_date.strftime('%Y%m%d')}_1D", "comparison_group": "XAU_COUNTRY_PREMIUMS", "metal_id": "XAU", "metal_name": "Gold", "asset_id": "XAU", "asset_type": "precious_metal", "canonical_timestamp_utc": gold_date, "aligned_interval": "1d", "benchmark": {"benchmark_id": "XAU_GLOBAL_BENCHMARK_PM", "price_usd_per_troy_ounce": 3475.0, "source_timestamp_utc": gold_date + timedelta(hours=15), "ingested_at_utc": gold_date + timedelta(hours=15, minutes=5), "canonical_timestamp_utc": gold_date, "aligned_interval": "1d", "snapshot_batch_id": f"SNAP_XAU_COUNTRY_{gold_date.strftime('%Y%m%d')}_1D", "is_stale": False, "quality_score": 0.96}, "country_prices": [{"country_code": "MY", "country_name": "Malaysia", "source_name": "Malaysia Retail Gold Source", "source_type": "retail_dealer", "venue_name": "Malaysia Gold Retail Market", "product_type": "jewellery_gold", "purity_original": "916", "purity_factor": 0.916, "price_local": 490.0, "local_currency": "MYR", "price_usd": 103.81, "unit_original": "MYR_per_gram", "unit_normalized": "USD_per_troy_ounce", "price_usd_per_gram": 113.33, "price_usd_per_troy_ounce": 3525.11, "benchmark_price_usd_per_troy_ounce": 3475.0, "premium_discount_pct": 1.441, "tax_included": True, "dealer_premium_included": True, "source_timestamp_utc": gold_date + timedelta(hours=2), "ingested_at_utc": gold_date + timedelta(hours=2, minutes=5), "canonical_timestamp_utc": gold_date, "aligned_interval": "1d", "snapshot_batch_id": f"SNAP_XAU_COUNTRY_{gold_date.strftime('%Y%m%d')}_1D", "is_stale": False, "quality_score": 0.84}], "summary": {"countries_expected": 15, "countries_available": 1}, "created_at_utc": datetime.utcnow()}
    await db.metals_country_snapshots.update_one({"snapshot_batch_id": metals_snapshot["snapshot_batch_id"]}, {"$set": metals_snapshot}, upsert=True)

    # Energy sample
    energy_doc = {"asset_id": "BRENT_CRUDE", "asset_name": "Brent Crude Oil", "asset_type": "energy", "benchmark_type": "global_crude_benchmark", "country_code": "GLOBAL", "venue_or_source": "BRENT_BENCHMARK_SOURCE", "price_original": 82.1, "currency_original": "USD", "unit_original": "USD_per_barrel", "price_usd_normalized": 82.1, "normalized_unit": "USD_per_barrel", "price_usd_per_litre": 0.5164, "fx_rate_used": None, "conversion_factor": 158.987294928, "source_timestamp_utc": gold_date + timedelta(hours=21), "ingested_at_utc": gold_date + timedelta(hours=21, minutes=5), "canonical_timestamp_utc": gold_date, "aligned_interval": "1d", "snapshot_batch_id": f"SNAP_ENERGY_BENCHMARK_{gold_date.strftime('%Y%m%d')}_1D", "is_stale": False, "quality_score": 0.95}
    await db.energy_benchmark_prices.insert_one(energy_doc)
    fuel_snapshot = {"snapshot_batch_id": "SNAP_MY_FUEL_SAMPLE_1W", "comparison_group": "MY_FUEL_WEEKLY_PRICES", "country_code": "MY", "country_name": "Malaysia", "canonical_timestamp_utc": gold_date, "aligned_interval": "1w", "energy_prices": [{"asset_id": "RON95_MY", "asset_name": "Malaysia RON95 Petrol", "price_original": 2.05, "currency_original": "MYR", "unit_original": "MYR_per_litre", "price_usd_normalized": 0.4343, "normalized_unit": "USD_per_litre", "source_timestamp_utc": gold_date, "ingested_at_utc": gold_date, "canonical_timestamp_utc": gold_date, "aligned_interval": "1w", "snapshot_batch_id": "SNAP_MY_FUEL_SAMPLE_1W", "is_stale": False, "quality_score": 0.95}], "created_at_utc": datetime.utcnow()}
    await db.energy_country_snapshots.update_one({"snapshot_batch_id": fuel_snapshot["snapshot_batch_id"]}, {"$set": fuel_snapshot}, upsert=True)

    # FX sample
    await db.fx_rate_events.insert_one({"asset_id": "USD_MYR", "base_currency": "USD", "quote_currency": "MYR", "rate": 4.72, "rate_type": "reference_rate", "source_id": "BNM_API", "source_timestamp_utc": gold_date + timedelta(hours=4), "ingested_at_utc": gold_date + timedelta(hours=4, minutes=5), "canonical_timestamp_utc": gold_date, "aligned_interval": "1d", "snapshot_batch_id": f"SNAP_FX_{gold_date.strftime('%Y%m%d')}_1D", "is_stale": False, "quality_score": 0.95})

    # Equity sample
    equity_snapshot = {"snapshot_batch_id": "SNAP_COIN_BTC_SAMPLE_MARKET_CLOSE", "comparison_group": "COIN_VS_BTC", "ticker": "COIN", "exchange": "NASDAQ", "country_code": "US", "related_asset_id": "BTC", "related_asset_type": "crypto", "canonical_timestamp_utc": gold_date + timedelta(hours=20), "aligned_interval": "market_close", "equity_price": {"ticker": "COIN", "currency": "USD", "close": 255.2, "adjusted_close": 255.2, "volume": 12450000, "source_timestamp_utc": gold_date + timedelta(hours=20), "ingested_at_utc": gold_date + timedelta(hours=20, minutes=5), "canonical_timestamp_utc": gold_date + timedelta(hours=20), "aligned_interval": "market_close", "snapshot_batch_id": "SNAP_COIN_BTC_SAMPLE_MARKET_CLOSE", "market_status": "closed", "is_market_closed": True, "is_stale": False, "quality_score": 0.95}, "related_asset_price": {"asset_id": "BTC", "price_usd": 103250.4, "source_timestamp_utc": gold_date + timedelta(hours=20), "ingested_at_utc": gold_date + timedelta(hours=20), "canonical_timestamp_utc": gold_date + timedelta(hours=20), "aligned_interval": "market_close", "snapshot_batch_id": "SNAP_COIN_BTC_SAMPLE_MARKET_CLOSE", "market_status": "open", "is_stale": False, "quality_score": 0.97}, "summary": {"comparison_type": "stock_close_vs_crypto_same_timestamp", "same_timestamp_comparison": True}, "created_at_utc": datetime.utcnow()}
    await db.equity_market_snapshots.update_one({"snapshot_batch_id": equity_snapshot["snapshot_batch_id"]}, {"$set": equity_snapshot}, upsert=True)

    # Logs sample
    await db.source_health_logs.insert_one({"source_id": "CCXT_BINANCE", "source_name": "Binance via CCXT", "source_type": "exchange_api", "venue_id": "BINANCE_SPOT", "status": "ok", "severity": "info", "checked_at_utc": datetime.utcnow(), "latency_ms": 240, "success": True, "records_fetched": 1, "source_timestamp_utc": now, "ingested_at_utc": ing, "canonical_timestamp_utc": crypto_docs[0]["canonical_timestamp_utc"], "aligned_interval": "1m", "snapshot_batch_id": sid, "is_stale": False, "quality_score": 0.95})
    await db.audit_logs.insert_one({"audit_id": f"AUDIT_SAMPLE_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}", "event_type": "seed", "action": "seed_sample_data", "entity_type": "system", "entity_id": "sample", "actor": "system", "source_timestamp_utc": now, "ingested_at_utc": ing, "canonical_timestamp_utc": crypto_docs[0]["canonical_timestamp_utc"], "aligned_interval": "1m", "snapshot_batch_id": sid, "is_stale": False, "quality_score": 1.0, "explanation": "Inserted sample documents for local endpoint testing.", "created_at_utc": datetime.utcnow()})

    return {"sample_crypto_quotes": len(crypto_docs), "sample_snapshots": 4, "sample_fx_rates": 1, "message": "Sample data inserted. Use GET endpoints to test."}
