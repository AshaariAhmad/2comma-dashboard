﻿# Patch Notes

This package includes the production-readiness pass:

1. `backend/app/security.py`
   - Uses `bcrypt_sha256` before `bcrypt` so long admin/login passwords do not fail with bcrypt's 72-byte limit.
   - Keeps old bcrypt hashes verifiable.

2. `backend/app/services.py`
   - Keeps the original `yfinance` download path.
   - Adds a direct Yahoo Chart API fallback when `yfinance` returns an empty dataframe or raises JSON decode errors.
   - Refresh responses now include `source`, either `yfinance` or `yahoo_chart`.

3. `frontend/`
   - Replaces the raw JSON dashboard with an authenticated app shell.
   - Adds a post-login Home landing page, side navigation, market table, historical refresh table, portfolio summary, operations monitor, and audit trail.
   - Adds a Market Universe editor and per-market chart cards.
   - Adds default watchlist entries for `CPO=F` (FCPO / crude palm oil proxy), `CL=F` (WTI), and `GC=F` (gold).
   - Converts API health from a JSON dump into a System Monitor panel with status, latency, mode, trading guard, data source, endpoint, and last check time.

4. AI advisory layer
   - Adds OpenAI-compatible live AI endpoints using the Responses API by default:
     - `GET /api/v1/ai/status`
     - `POST /api/v1/ai/market-brief`
     - `POST /api/v1/ai/portfolio-review`
     - `POST /api/v1/ai/risk-review`
   - Adds admin AI settings endpoints:
     - `GET /api/v1/admin/ai/settings`
     - `PUT /api/v1/admin/ai/settings`
     - `POST /api/v1/admin/ai/test`
   - Adds dashboard controls for Market Analyst, Portfolio Coach, and Risk Reviewer agents.
   - Adds an admin-only place to save the ChatGPT/OpenAI API key, API base, model, API mode, and timeout.
   - AI output is advisory only. Deterministic risk checks and paper-only execution remain the authority.

## Rebuild After Pulling

```powershell
docker compose up -d --build
docker compose exec -T api python -m backend.app.scripts.create_admin
.\REFRESH_MARKET_DATA_WINDOWS.bat
```

## Enable Live AI

Set these in `.env`, or sign in as admin and save them from AI Configuration:

```text
OPENAI_API_KEY=your_api_key_here
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-5.1
OPENAI_API_MODE=responses
AI_REQUEST_TIMEOUT_SECONDS=60
```

Then rebuild or restart:

```powershell
docker compose up -d --build
```

Test:

```powershell
Invoke-RestMethod "http://localhost:8000/api/v1/ai/status" | ConvertTo-Json -Depth 5
```

## Verify Market Data

```powershell
docker compose exec -T api python -c "from backend.app.services import download_yfinance; df=download_yfinance('BTC-USD','6mo','1d'); print(df.shape); print(df.attrs); print(df.tail())"
```

Expected: rows greater than 0 and source `yfinance` or `yahoo_chart`.

## Verify Database Rows

```powershell
docker compose exec -T postgres psql -U twocomma -d twocomma -c "select source, count(*), min(timestamp), max(timestamp) from market_ohlcv group by source;"
```
