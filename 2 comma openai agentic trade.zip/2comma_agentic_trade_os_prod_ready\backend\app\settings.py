from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "2 Comma Agentic Trade OS"
    environment: str = "development"
    debug: bool = True
    api_prefix: str = "/api/v1"

    database_url: str
    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"

    jwt_secret_key: str = "change_me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 720

    admin_email: str = "admin@example.com"
    admin_password: str = "ChangeMe12345!"

    eia_api_key: str | None = None
    openai_api_key: str | None = None
    openai_api_base: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-5.1"
    openai_api_mode: str = "responses"
    ai_request_timeout_seconds: int = 60

    paper_initial_cash: float = 100000.0
    live_trading_enabled: bool = False
    cors_origins: str = "http://localhost:8080,http://localhost:8000"

    @property
    def cors_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
