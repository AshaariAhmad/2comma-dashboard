# 2 Comma Agentic Trade OS — Production-Ready Starter

This is a production-style backend for the 2 Comma Agentic Trade OS with **real API adapters** and **real PostgreSQL/TimescaleDB persistence**.

## Included

| Area | Included |
|---|---|
| FastAPI backend | Yes |
| PostgreSQL / TimescaleDB | Yes |
| SQLAlchemy models | Yes |
| Redis + Celery worker | Yes |
| Real yfinance OHLCV API adapter | Yes |
| Real Deribit public API adapter | Yes |
| EIA API v2 adapter | Yes, requires `EIA_API_KEY` |
| Deterministic risk engine | Yes |
| Paper trading engine | Yes |
| Portfolio snapshots | Yes |
| Audit logs | Yes |
| Live AI advisory layer | Yes, via server-side AI settings or `OPENAI_API_KEY` |
| Authenticated frontend | Yes |
| Live trading | Disabled by default |



## Windows desktop install

For Windows desktop testing, use the included installer scripts:

```text
INSTALL_WINDOWS.bat      First install and start everything
START_WINDOWS.bat        Start after installation
STOP_WINDOWS.bat         Stop containers but keep database data
STATUS_WINDOWS.bat       Show status and recent logs
REFRESH_MARKET_DATA_WINDOWS.bat  Pull real market data
RESET_DATABASE_WINDOWS.bat       Delete local database and start fresh
```

Full guide: `README_WINDOWS_DESKTOP_INSTALL.md`


## Safety rule

```text
AI can propose and explain.
AI cannot approve risk.
AI cannot execute live trades.
Risk approval is deterministic code.
Execution is paper only by default.
```

## Live AI advisory layer

Set `OPENAI_API_KEY` in `.env`, or sign in as admin and save the key from AI Configuration in the dashboard.

```text
OPENAI_API_KEY=your_api_key_here
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-5.1
OPENAI_API_MODE=responses
AI_REQUEST_TIMEOUT_SECONDS=60
```

Included agents:

```text
Market Analyst     Summarizes live market context and watchlist risks
Portfolio Coach    Reviews paper portfolio exposure and next checks
Risk Reviewer      Explains risk around signals and requested position size
```

The AI layer uses the OpenAI Responses API by default. API keys are never sent to browser-only code; the dashboard sends them to the backend admin endpoint and the backend stores them as encrypted system settings. The AI layer is advisory only. Risk approval stays deterministic, and live trading remains disabled.

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:

```text
API docs:  http://localhost:8000/docs
Frontend:  http://localhost:8080
Health:    http://localhost:8000/api/v1/health
```

## Create an admin user

```bash
docker compose exec api python -m backend.app.scripts.create_admin
```

Default admin credentials from `.env.example`:

```text
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=ChangeMe12345!
```

Change them before public deployment.

## Seed symbols

```bash
docker compose exec api python -m backend.app.scripts.seed_symbols
```

## Refresh real market data

```bash
curl -X POST "http://localhost:8000/api/v1/markets/refresh" \
  -H "Content-Type: application/json" \
  -d '{"symbols":["CPO=F","CL=F","GC=F","BZ=F","BTC-USD","ETH-USD","^KLSE","MYR=X","SGDMYR=X"],"period":"6mo","interval":"1d"}'
```

Default market universe:

```text
CPO=F      FCPO / crude palm oil proxy from Yahoo Finance
CL=F       WTI crude oil futures
GC=F       Gold futures
BZ=F       Brent crude oil futures
BTC-USD    Bitcoin
ETH-USD    Ethereum
^KLSE      FTSE Bursa Malaysia KLCI
MYR=X      USD/MYR
SGDMYR=X   SGD/MYR
```

The dashboard also has a Market Universe box where admins/users can paste Yahoo/yfinance symbols. yfinance does not provide one reliable "import every market in the world" universe; use curated symbols from the exchange/provider you trust, then paste or seed them.

## Main flow

1. Register/login.
2. Refresh market data.
3. Generate features.
4. Run simple EMA backtest.
5. Generate signal.
6. Run deterministic risk check.
7. Create paper order.
8. View portfolio and audit logs.

## Production hardening still required

This project is a strong production-ready starter, but before using with real users:

- Put it behind HTTPS.
- Change `JWT_SECRET_KEY` to a long random value before saving AI secrets.
- Use a managed secret manager.
- Use managed PostgreSQL/TimescaleDB backups.
- Add CI/CD.
- Add rate limits.
- Add monitoring and alerting.
- Review market data provider terms.
- Keep live trading disabled unless a separate supervised broker integration is built.
