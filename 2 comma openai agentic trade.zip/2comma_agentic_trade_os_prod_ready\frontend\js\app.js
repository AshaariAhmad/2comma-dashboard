const API = window.TWOCOMMA_API_BASE || `${window.location.protocol === "file:" ? "http:" : window.location.protocol}//${window.location.hostname || "localhost"}:8000/api/v1`;
const DEFAULT_SYMBOLS = ["CPO=F", "CL=F", "GC=F", "BZ=F", "BTC-USD", "ETH-USD", "^KLSE", "MYR=X", "SGDMYR=X"];
const MARKET_NAMES = {
  "CPO=F": "FCPO / Crude Palm Oil",
  "CL=F": "WTI Crude Oil",
  "GC=F": "Gold Futures",
  "BZ=F": "Brent Crude Oil",
  "BTC-USD": "Bitcoin",
  "ETH-USD": "Ethereum",
  "^KLSE": "FTSE Bursa Malaysia KLCI",
  "MYR=X": "USD/MYR",
  "SGDMYR=X": "SGD/MYR",
};
const VIEW_TITLES = {
  homeView: ["Home", "Command Center"],
  marketsView: ["Markets", "Market Data"],
  aiView: ["AI Agents", "Advisory Layer"],
  portfolioView: ["Portfolio", "Paper Portfolio"],
  opsView: ["Operations", "System Monitor"],
};

let token = localStorage.getItem("twocomma_token") || "";
let currentUser = null;
let timersStarted = false;
let symbols = loadStoredSymbols();

const state = {
  markets: [],
  historyRows: 0,
  lastRefresh: null,
  aiConfigured: false,
  activeView: "homeView",
};

const el = (id) => document.getElementById(id);

function uniqueSymbols(items) {
  const seen = new Set();
  return items
    .map((item) => String(item || "").trim())
    .filter(Boolean)
    .filter((item) => {
      const key = item.toUpperCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function loadStoredSymbols() {
  try {
    const stored = JSON.parse(localStorage.getItem("twocomma_symbols") || "[]");
    const parsed = uniqueSymbols(Array.isArray(stored) ? stored : []);
    return parsed.length ? parsed : DEFAULT_SYMBOLS;
  } catch {
    return DEFAULT_SYMBOLS;
  }
}

function syncSymbolsInput() {
  el("symbolsInput").value = symbols.join("\n");
  el("symbolMeta").textContent = `${symbols.length} Yahoo/yfinance symbols in the active universe`;
}

function parseSymbolsInput() {
  return uniqueSymbols(el("symbolsInput").value.split(/[\s,]+/));
}

function escapeHtml(value) {
  return String(value ?? "-").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;",
  }[char]));
}

function formatNumber(value, digits = 4) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return "-";
  return Number(value).toLocaleString(undefined, { maximumFractionDigits: digits });
}

function formatTime(value) {
  if (!value) return "-";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleString();
}

function setBusy(button, busy) {
  if (!button) return;
  button.disabled = busy;
}

function setBadge(id, tone, text) {
  const node = el(id);
  if (!node) return;
  node.textContent = text;
  node.className = `status-pill ${tone || ""}`.trim();
}

function setMessage(id, text, ok = true) {
  const node = el(id);
  if (!node) return;
  node.textContent = text;
  node.className = `message ${ok ? "ok" : "bad"}`;
}

async function request(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.auth && token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";
  const response = await fetch(API + path, { ...options, headers });
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { detail: text };
  }
  if (!response.ok) {
    throw new Error(payload.detail || text || `HTTP ${response.status}`);
  }
  return payload;
}

function updateClock() {
  el("clockLabel").textContent = formatTime(new Date());
}

function updateMetrics() {
  el("rowMetric").textContent = state.historyRows ? formatNumber(state.historyRows, 0) : "-";
  el("refreshMetric").textContent = state.lastRefresh ? formatTime(state.lastRefresh) : "-";
}

function setView(viewId) {
  state.activeView = viewId;
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === viewId));
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === viewId);
    button.setAttribute("aria-pressed", button.dataset.view === viewId ? "true" : "false");
  });
  const title = VIEW_TITLES[viewId] || VIEW_TITLES.homeView;
  el("workspaceKicker").textContent = title[0];
  el("workspaceTitle").textContent = title[1];
}

function showAuth(message = "") {
  currentUser = null;
  document.body.className = "auth-mode";
  el("authView").hidden = false;
  el("appShell").hidden = true;
  setMessage("authMessage", message, !message);
}

function showApp() {
  document.body.className = "app-mode";
  el("authView").hidden = true;
  el("appShell").hidden = false;
  el("sessionEmail").textContent = currentUser?.email || "Signed in";
  el("sessionRole").textContent = currentUser?.role || "user";
  setView("homeView");
  startTimers();
}

function clearSession(message = "Signed out") {
  token = "";
  currentUser = null;
  localStorage.removeItem("twocomma_token");
  showAuth(message);
}

function startTimers() {
  if (timersStarted) return;
  timersStarted = true;
  setInterval(updateClock, 1000);
  setInterval(loadHealth, 30000);
  setInterval(loadMarkets, 60000);
}

async function verifySession() {
  if (!token) {
    showAuth();
    return;
  }
  try {
    currentUser = await request("/users/me", { auth: true });
    showApp();
    await refreshAll();
  } catch {
    clearSession("Login required");
  }
}

async function login(event) {
  event.preventDefault();
  const button = el("loginBtn");
  setBusy(button, true);
  try {
    const payload = await request("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email: el("emailInput").value.trim(),
        password: el("passwordInput").value,
      }),
    });
    token = payload.access_token || "";
    localStorage.setItem("twocomma_token", token);
    currentUser = {
      user_id: payload.user_id,
      email: payload.email,
      role: payload.role || "user",
    };
    showApp();
    await refreshAll();
  } catch (error) {
    setMessage("authMessage", error.message, false);
  } finally {
    setBusy(button, false);
  }
}

function updateAIStatus(status) {
  state.aiConfigured = Boolean(status.configured);
  const tone = state.aiConfigured ? "ok" : "warn";
  setBadge("aiStatusBadge", tone, state.aiConfigured ? "AI live" : "AI setup needed");
  el("aiMeta").textContent = `${status.model || "AI model"} - ${status.api_mode || status.mode || "advisory_only"}`;
  el("readyAI").textContent = state.aiConfigured ? "Configured" : "Needs key";
  el("readyAI").className = state.aiConfigured ? "quality-ok" : "quality-warn";
  if (state.aiConfigured && el("aiOutput").textContent.includes("Set an OpenAI API key")) {
    el("aiOutput").textContent = "AI advisory layer is configured.";
  } else if (!state.aiConfigured) {
    el("aiOutput").textContent = status.message || "Set an OpenAI API key in AI Configuration.";
  }
}

async function loadAIStatus() {
  try {
    const status = await request("/ai/status");
    updateAIStatus(status);
  } catch (error) {
    state.aiConfigured = false;
    setBadge("aiStatusBadge", "bad", "AI unavailable");
    el("aiMeta").textContent = "AI endpoint unavailable";
    el("readyAI").textContent = "Unavailable";
    el("readyAI").className = "quality-bad";
    el("aiOutput").textContent = error.message;
  }
}

async function loadAdminAISettings() {
  const panel = el("aiSettingsPanel");
  if (!currentUser || currentUser.role !== "admin") {
    panel.hidden = true;
    return;
  }
  panel.hidden = false;
  try {
    const status = await request("/admin/ai/settings", { auth: true });
    el("aiBaseInput").value = status.api_base || "https://api.openai.com/v1";
    el("aiModelInput").value = status.model || "gpt-5.1";
    el("aiModeSelect").value = status.api_mode || "responses";
    el("aiTimeoutInput").value = status.request_timeout_seconds || 60;
    el("aiKeySource").textContent = status.key_source || "-";
    el("aiKeyHint").textContent = status.key_hint || "-";
    el("aiEndpoint").textContent = `${status.api_base || "-"} / ${status.api_mode || "responses"}`;
    el("aiSettingsMeta").textContent = status.configured ? "Configured" : "API key required";
    setBadge("aiSettingsBadge", status.configured ? "ok" : "warn", status.configured ? "Configured" : "Needs key");
    updateAIStatus(status);
  } catch (error) {
    el("aiSettingsMeta").textContent = error.message;
    setBadge("aiSettingsBadge", "bad", "Unavailable");
  }
}

async function saveAISettings(event) {
  event.preventDefault();
  const button = el("saveAISettingsBtn");
  setBusy(button, true);
  try {
    const apiKey = el("aiKeyInput").value.trim();
    const payload = {
      api_base: el("aiBaseInput").value.trim(),
      model: el("aiModelInput").value.trim(),
      api_mode: el("aiModeSelect").value,
      request_timeout_seconds: Number(el("aiTimeoutInput").value || 60),
      clear_api_key: el("aiClearKeyInput").checked,
    };
    if (apiKey) payload.api_key = apiKey;
    const status = await request("/admin/ai/settings", {
      method: "PUT",
      auth: true,
      body: JSON.stringify(payload),
    });
    el("aiKeyInput").value = "";
    el("aiClearKeyInput").checked = false;
    setMessage("aiSettingsMessage", "AI settings saved");
    updateAIStatus(status);
    await loadAdminAISettings();
  } catch (error) {
    setMessage("aiSettingsMessage", error.message, false);
  } finally {
    setBusy(button, false);
  }
}

async function testAISettings() {
  const button = el("testAISettingsBtn");
  setBusy(button, true);
  try {
    const result = await request("/admin/ai/test", {
      method: "POST",
      auth: true,
      body: JSON.stringify({ prompt: "Confirm the 2 Comma AI advisory layer is connected." }),
    });
    renderAIResult(result);
    setMessage("aiSettingsMessage", result.configured ? "AI connection tested" : "AI key required", Boolean(result.configured));
  } catch (error) {
    setMessage("aiSettingsMessage", error.message, false);
  } finally {
    setBusy(button, false);
  }
}

function renderAIResult(result) {
  updateAIStatus({
    configured: result.configured,
    model: result.model,
    api_mode: result.api_mode,
    mode: result.mode,
    message: result.content,
  });
  el("aiOutput").textContent = [
    result.content || "No AI response content returned.",
    "",
    result.safety ? `Safety: ${result.safety}` : "",
  ].filter(Boolean).join("\n");
}

async function runAIAgent(kind) {
  const focus = el("aiFocusInput").value.trim() || null;
  const buttonMap = {
    market: el("aiMarketBtn"),
    portfolio: el("aiPortfolioBtn"),
    risk: el("aiRiskBtn"),
  };
  const button = buttonMap[kind];
  setBusy(button, true);
  el("aiOutput").textContent = "Running AI advisory agent...";
  try {
    let result;
  if (kind === "market") {
      result = await request("/ai/market-brief", {
        method: "POST",
        body: JSON.stringify({ symbols, horizon: "24-72 hours", focus }),
      });
    } else if (kind === "portfolio") {
      result = await request("/ai/portfolio-review", {
        method: "POST",
        auth: true,
        body: JSON.stringify({ focus }),
      });
    } else {
      result = await request("/ai/risk-review", {
        method: "POST",
        auth: true,
        body: JSON.stringify({ focus }),
      });
    }
    renderAIResult(result);
  } catch (error) {
    el("aiOutput").textContent = error.message;
  } finally {
    setBusy(button, false);
  }
}

async function loadHealth() {
  const startedAt = performance.now();
  try {
    const health = await request("/health");
    const latency = Math.max(1, Math.round(performance.now() - startedAt));
    const isLiveDisabled = health.live_trading_enabled === false;
    const checkedAt = new Date();
    const source = health.preview_real_public_api ? "Public API preview" : "Docker backend";
    if (health.ai) updateAIStatus(health.ai);
    setBadge("apiStatus", "ok", "API ok");
    el("modeMetric").textContent = health.mode || "paper_only";
    el("liveMetric").textContent = health.live_trading_enabled ? "Enabled" : "Disabled";
    el("readinessMeta").textContent = `Updated ${formatTime(checkedAt)}`;
    el("readyTrading").textContent = isLiveDisabled ? "Protected" : "Live enabled";
    el("readyTrading").className = isLiveDisabled ? "quality-ok" : "quality-bad";
    el("healthMeta").textContent = `All checks passed at ${formatTime(checkedAt)}`;
    el("healthState").textContent = health.status || "ok";
    el("healthState").className = "quality-ok";
    el("healthLatency").textContent = `${latency} ms`;
    el("healthMode").textContent = health.mode || "paper_only";
    el("healthTrading").textContent = isLiveDisabled ? "Protected" : "Live enabled";
    el("healthTrading").className = isLiveDisabled ? "quality-ok" : "quality-bad";
    el("healthSource").textContent = source;
    el("healthEndpoint").textContent = `${API}/health`;
    el("healthUpdated").textContent = formatTime(health.updated_at || checkedAt);
  } catch (error) {
    setBadge("apiStatus", "bad", "API offline");
    el("readinessMeta").textContent = error.message;
    el("healthMeta").textContent = error.message;
    el("healthState").textContent = "Offline";
    el("healthState").className = "quality-bad";
    el("healthLatency").textContent = "-";
    el("healthMode").textContent = "-";
    el("healthTrading").textContent = "-";
    el("healthTrading").className = "";
    el("healthSource").textContent = error.message;
    el("healthEndpoint").textContent = `${API}/health`;
    el("healthUpdated").textContent = formatTime(new Date());
  }
}

function marketRowHtml(row) {
  const quality = row.quality_status || "unknown";
  const qualityClass = quality === "ok" ? "quality-ok" : "quality-bad";
  const marketName = MARKET_NAMES[row.symbol] || row.display_name || row.asset_class || "-";
  return `
    <tr>
      <td><strong>${escapeHtml(row.symbol)}</strong></td>
      <td>${escapeHtml(marketName)}</td>
      <td class="numeric">${formatNumber(row.close ?? row.regular_market_price)}</td>
      <td>${escapeHtml(row.source || "-")}</td>
      <td><span class="${qualityClass}">${escapeHtml(quality)}</span></td>
      <td>${formatTime(row.timestamp)}</td>
    </tr>
  `;
}

function renderMarketsInto(bodyId, rows) {
  const body = el(bodyId);
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="6" class="empty-cell">No market rows found</td></tr>`;
    return;
  }
  body.innerHTML = rows.map(marketRowHtml).join("");
}

function renderMarkets(rows) {
  renderMarketsInto("marketsBody", rows);
  renderMarketsInto("marketsBodyHome", rows.slice(0, 7));
  const label = `${rows.length} symbols loaded`;
  el("marketMeta").textContent = label;
  el("marketMetaHome").textContent = label;
  el("readyMarket").textContent = rows.length ? "Live rows" : "No rows";
  el("readyMarket").className = rows.length ? "quality-ok" : "quality-warn";
}

async function loadMarkets() {
  const button = el("refreshMarketsBtn");
  setBusy(button, true);
  try {
    const rows = await request(`/markets/latest?symbols=${encodeURIComponent(symbols.join(","))}`);
    state.markets = Array.isArray(rows) ? rows : [];
    renderMarkets(state.markets);
    await loadCharts();
  } catch (error) {
    el("marketMeta").textContent = error.message;
    el("marketMetaHome").textContent = error.message;
    el("readyMarket").textContent = "Unavailable";
    el("readyMarket").className = "quality-bad";
    el("marketsBody").innerHTML = `<tr><td colspan="6" class="empty-cell">${escapeHtml(error.message)}</td></tr>`;
    el("marketsBodyHome").innerHTML = `<tr><td colspan="6" class="empty-cell">${escapeHtml(error.message)}</td></tr>`;
  } finally {
    setBusy(button, false);
  }
}

function renderHistory(results) {
  const body = el("historyBody");
  if (!results.length) {
    body.innerHTML = `<tr><td colspan="4" class="empty-cell">Refresh returned no rows</td></tr>`;
    return;
  }
  body.innerHTML = results.map((row) => `
    <tr>
      <td><strong>${escapeHtml(row.symbol)}</strong></td>
      <td class="numeric">${formatNumber(row.rows || 0, 0)}</td>
      <td>${escapeHtml(row.source || "-")}</td>
      <td>${escapeHtml(row.error || "")}</td>
    </tr>
  `).join("");
}

async function refreshHistory() {
  const button = el("refreshHistoryBtn");
  setBusy(button, true);
  el("historyMeta").textContent = "Refreshing historical candles";
  try {
    const payload = await request("/markets/refresh", {
      method: "POST",
      body: JSON.stringify({ symbols, period: "6mo", interval: "1d" }),
    });
    const results = payload.results || [];
    state.historyRows = results.reduce((sum, row) => sum + Number(row.rows || 0), 0);
    state.lastRefresh = new Date();
    renderHistory(results);
    el("historyMeta").textContent = `${payload.status || "completed"} - ${formatNumber(state.historyRows, 0)} rows`;
    updateMetrics();
    await loadMarkets();
  } catch (error) {
    el("historyMeta").textContent = error.message;
    el("historyBody").innerHTML = `<tr><td colspan="4" class="empty-cell">${escapeHtml(error.message)}</td></tr>`;
  } finally {
    setBusy(button, false);
  }
}

function buildSparklinePath(values, width = 560, height = 150, pad = 12) {
  if (values.length < 2) return { line: "", area: "" };
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max === min ? 1 : max - min;
  const step = (width - pad * 2) / (values.length - 1);
  const points = values.map((value, index) => {
    const x = pad + index * step;
    const y = height - pad - ((value - min) / span) * (height - pad * 2);
    return [x, y];
  });
  const line = points.map(([x, y], index) => `${index ? "L" : "M"}${x.toFixed(2)} ${y.toFixed(2)}`).join(" ");
  const area = `${line} L${points[points.length - 1][0].toFixed(2)} ${height - pad} L${points[0][0].toFixed(2)} ${height - pad} Z`;
  return { line, area };
}

function renderChartCard(symbol, candles) {
  const closes = candles
    .filter((row) => row.close !== null && row.close !== undefined)
    .map((row) => Number(row.close))
    .filter((value) => Number.isFinite(value));
  if (closes.length < 2) {
    return `
      <article class="chart-card">
        <div class="chart-head">
          <div>
            <strong>${escapeHtml(symbol)}</strong>
            <span>${escapeHtml(MARKET_NAMES[symbol] || "Market")}</span>
          </div>
          <div class="chart-price">No chart data</div>
        </div>
        <div class="empty-card">Run historical refresh to store candles for this symbol</div>
      </article>
    `;
  }
  const first = closes[0];
  const last = closes[closes.length - 1];
  const changePct = first ? ((last / first) - 1) * 100 : 0;
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const { line, area } = buildSparklinePath(closes);
  return `
    <article class="chart-card">
      <div class="chart-head">
        <div>
          <strong>${escapeHtml(symbol)}</strong>
          <span>${escapeHtml(MARKET_NAMES[symbol] || "Market")}</span>
        </div>
        <div class="chart-price">
          <strong>${formatNumber(last)}</strong>
          <span class="${changePct >= 0 ? "quality-ok" : "quality-bad"}">${formatNumber(changePct, 2)}%</span>
        </div>
      </div>
      <svg class="market-chart" viewBox="0 0 560 150" role="img" aria-label="${escapeHtml(symbol)} close chart">
        <path class="area" d="${area}"></path>
        <path class="line" d="${line}"></path>
      </svg>
      <div class="chart-footer">
        <span>${candles.length} candles</span>
        <span>Low ${formatNumber(min)} / High ${formatNumber(max)}</span>
      </div>
    </article>
  `;
}

async function loadCharts() {
  const grid = el("chartGrid");
  const button = el("refreshChartsBtn");
  setBusy(button, true);
  grid.innerHTML = `<div class="empty-card">Loading charts</div>`;
  try {
    const cards = [];
    for (const symbol of symbols) {
      try {
        const candles = await request(`/markets/ohlcv?symbol=${encodeURIComponent(symbol)}&timeframe=1d&limit=140&range=6mo`);
        cards.push(renderChartCard(symbol, Array.isArray(candles) ? candles : []));
      } catch (error) {
        cards.push(`
          <article class="chart-card">
            <div class="chart-head">
              <div>
                <strong>${escapeHtml(symbol)}</strong>
                <span>${escapeHtml(MARKET_NAMES[symbol] || "Market")}</span>
              </div>
              <div class="chart-price quality-bad">Unavailable</div>
            </div>
            <div class="empty-card">${escapeHtml(error.message)}</div>
          </article>
        `);
      }
    }
    grid.innerHTML = cards.join("");
    el("chartMeta").textContent = `${symbols.length} charts from daily close history`;
  } finally {
    setBusy(button, false);
  }
}

function normalizePortfolio(portfolio) {
  return {
    cash: portfolio.cash_balance ?? portfolio.paper_cash ?? 0,
    equity: portfolio.equity_value ?? portfolio.equity ?? 0,
    openPositions: portfolio.open_positions_count ?? (Array.isArray(portfolio.open_positions) ? portfolio.open_positions.length : 0),
    pnl: portfolio.unrealized_pnl ?? portfolio.pnl ?? 0,
    exposure: portfolio.exposure_by_symbol || {},
  };
}

function renderPortfolio(portfolio) {
  const normalized = normalizePortfolio(portfolio);
  ["cashValue", "cashValueHome"].forEach((id) => el(id).textContent = formatNumber(normalized.cash, 2));
  ["equityValue", "equityValueHome"].forEach((id) => el(id).textContent = formatNumber(normalized.equity, 2));
  ["positionsValue", "positionsValueHome"].forEach((id) => el(id).textContent = formatNumber(normalized.openPositions, 0));
  ["pnlValue", "pnlValueHome"].forEach((id) => el(id).textContent = formatNumber(normalized.pnl, 2));
  const label = `Updated ${formatTime(new Date())}`;
  el("portfolioMeta").textContent = label;
  el("portfolioMetaHome").textContent = label;
  const rows = Object.entries(normalized.exposure);
  el("exposureBody").innerHTML = rows.length ? rows.map(([symbol, value]) => `
    <tr>
      <td><strong>${escapeHtml(symbol)}</strong></td>
      <td class="numeric">${formatNumber(value, 2)}</td>
    </tr>
  `).join("") : `<tr><td colspan="2" class="empty-cell">No exposure</td></tr>`;
}

async function loadPortfolio() {
  if (!token) return;
  const button = el("refreshPortfolioBtn");
  setBusy(button, true);
  try {
    const portfolio = await request("/portfolio/summary", { auth: true });
    renderPortfolio(portfolio);
  } catch (error) {
    el("portfolioMeta").textContent = error.message;
    el("portfolioMetaHome").textContent = error.message;
  } finally {
    setBusy(button, false);
  }
}

function renderAudit(rows) {
  const body = el("auditBody");
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="4" class="empty-cell">No audit events</td></tr>`;
    return;
  }
  body.innerHTML = rows.map((row) => `
    <tr>
      <td>${formatTime(row.timestamp)}</td>
      <td>${escapeHtml(row.event_type)}</td>
      <td>${escapeHtml(row.severity || "info")}</td>
      <td>${escapeHtml(row.message || "-")}</td>
    </tr>
  `).join("");
}

async function loadAudit() {
  if (!token) return;
  const button = el("refreshAuditBtn");
  setBusy(button, true);
  try {
    const rows = await request("/audit/me?limit=25", { auth: true });
    renderAudit(Array.isArray(rows) ? rows : []);
    el("auditMeta").textContent = `${Array.isArray(rows) ? rows.length : 0} events loaded`;
  } catch (error) {
    el("auditMeta").textContent = error.message;
    el("auditBody").innerHTML = `<tr><td colspan="4" class="empty-cell">${escapeHtml(error.message)}</td></tr>`;
  } finally {
    setBusy(button, false);
  }
}

async function applySymbols() {
  const next = parseSymbolsInput();
  if (!next.length) {
    el("symbolMeta").textContent = "Enter at least one Yahoo/yfinance symbol";
    return;
  }
  symbols = next;
  localStorage.setItem("twocomma_symbols", JSON.stringify(symbols));
  syncSymbolsInput();
  await loadMarkets();
  await loadCharts();
}

async function resetSymbols() {
  symbols = [...DEFAULT_SYMBOLS];
  localStorage.setItem("twocomma_symbols", JSON.stringify(symbols));
  syncSymbolsInput();
  await loadMarkets();
  await loadCharts();
}

async function refreshAll() {
  const button = el("refreshAllBtn");
  setBusy(button, true);
  updateClock();
  await loadHealth();
  await loadAIStatus();
  await loadMarkets();
  await loadPortfolio();
  await loadAudit();
  await loadAdminAISettings();
  updateMetrics();
  setBusy(button, false);
}

function bindEvents() {
  el("loginForm").addEventListener("submit", login);
  el("logoutBtn").addEventListener("click", () => clearSession("Signed out"));
  el("refreshAllBtn").addEventListener("click", refreshAll);
  el("refreshMarketsBtn").addEventListener("click", loadMarkets);
  el("refreshHistoryBtn").addEventListener("click", refreshHistory);
  el("refreshChartsBtn").addEventListener("click", loadCharts);
  el("applySymbolsBtn").addEventListener("click", applySymbols);
  el("resetSymbolsBtn").addEventListener("click", resetSymbols);
  el("refreshPortfolioBtn").addEventListener("click", loadPortfolio);
  el("refreshAuditBtn").addEventListener("click", loadAudit);
  el("aiMarketBtn").addEventListener("click", () => runAIAgent("market"));
  el("aiPortfolioBtn").addEventListener("click", () => runAIAgent("portfolio"));
  el("aiRiskBtn").addEventListener("click", () => runAIAgent("risk"));
  el("aiSettingsForm").addEventListener("submit", saveAISettings);
  el("testAISettingsBtn").addEventListener("click", testAISettings);
  document.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });
  document.querySelectorAll("[data-view-jump]").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.viewJump));
  });
}

function init() {
  bindEvents();
  syncSymbolsInput();
  updateClock();
  updateMetrics();
  verifySession();
}

init();
