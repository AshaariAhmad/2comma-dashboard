from __future__ import annotations
import base64
from datetime import datetime, timedelta, timezone
import hashlib
import json
import pandas as pd
import numpy as np
import httpx
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from backend.app.settings import get_settings
from backend.app.models import (
    AuditLog, BacktestRun, DeribitBookSummary, EIAObservation, MarketFeature,
    MarketOHLCV, MarketSymbol, PaperOrder, PaperPosition, PortfolioSnapshot,
    RiskCheck, Signal, SystemEvent, SystemSetting, User, UserRiskProfile
)

DEFAULT_SYMBOLS = [
    {"symbol":"CPO=F","display_name":"Crude Palm Oil Futures","asset_class":"commodity","exchange":"Yahoo/CME","base_currency":"CPO","quote_currency":"USD"},
    {"symbol":"GC=F","display_name":"Gold Futures","asset_class":"commodity","exchange":"COMEX","base_currency":"GOLD","quote_currency":"USD"},
    {"symbol":"BTC-USD","display_name":"Bitcoin USD","asset_class":"crypto","exchange":"Yahoo","base_currency":"BTC","quote_currency":"USD"},
    {"symbol":"ETH-USD","display_name":"Ethereum USD","asset_class":"crypto","exchange":"Yahoo","base_currency":"ETH","quote_currency":"USD"},
    {"symbol":"CL=F","display_name":"WTI Crude Oil Futures","asset_class":"commodity","exchange":"NYMEX","base_currency":"WTI","quote_currency":"USD"},
    {"symbol":"BZ=F","display_name":"Brent Crude Oil Futures","asset_class":"commodity","exchange":"ICE","base_currency":"BRENT","quote_currency":"USD"},
    {"symbol":"^KLSE","display_name":"FTSE Bursa Malaysia KLCI","asset_class":"index","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
    {"symbol":"MYR=X","display_name":"USD/MYR","asset_class":"fx","exchange":"Yahoo FX","base_currency":"USD","quote_currency":"MYR"},
    {"symbol":"SGDMYR=X","display_name":"SGD/MYR","asset_class":"fx","exchange":"Yahoo FX","base_currency":"SGD","quote_currency":"MYR"},
    {"symbol":"1155.KL","display_name":"Maybank","asset_class":"equity","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
    {"symbol":"1023.KL","display_name":"CIMB Group","asset_class":"equity","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
]


def audit(db: Session, event_type: str, message: str, user_id: str | None = None, severity: str = "info", ref_type: str | None = None, ref_id: str | None = None, event_data: dict | None = None):
    row = AuditLog(event_type=event_type, message=message, severity=severity, user_id=user_id, ref_type=ref_type, ref_id=ref_id, event_data=event_data or {})
    db.add(row)
    db.flush()
    return row


def system_event(db: Session, service_name: str, event_type: str, message: str, severity: str = "warning", details: dict | None = None):
    row = SystemEvent(service_name=service_name, event_type=event_type, message=message, severity=severity, details=details or {})
    db.add(row)
    db.flush()
    return row


def seed_symbols(db: Session) -> int:
    count = 0
    for item in DEFAULT_SYMBOLS:
        existing = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == item["symbol"]))
        if not existing:
            db.add(MarketSymbol(**item))
            count += 1
    audit(db, "symbols_seeded", f"Seeded {count} default symbols")
    db.commit()
    return count


def ensure_symbol(db: Session, symbol: str) -> MarketSymbol:
    existing = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if existing:
        return existing
    obj = MarketSymbol(symbol=symbol, display_name=symbol, asset_class="unknown", exchange="unknown")
    db.add(obj)
    db.flush()
    return obj


def _prepare_ohlcv_frame(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] for c in df.columns]
    df = df.reset_index()
    time_col = "Datetime" if "Datetime" in df.columns else "Date"
    df["timestamp"] = pd.to_datetime(df[time_col], utc=True)
    return df


def download_yahoo_chart(symbol: str, period: str, interval: str) -> pd.DataFrame:
    # Direct chart endpoint fallback for cases where yfinance returns an empty
    # dataframe because Yahoo's wrapper metadata/crumb request failed.
    url_symbol = symbol.replace("^", "%5E")
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{url_symbol}"
    headers = {"User-Agent": "Mozilla/5.0"}
    params = {"range": period, "interval": interval}
    with httpx.Client(timeout=30, headers=headers) as client:
        resp = client.get(url, params=params)
        resp.raise_for_status()
        payload = resp.json()
    if payload.get("chart", {}).get("error"):
        raise RuntimeError(str(payload["chart"]["error"]))
    result = (payload.get("chart", {}).get("result") or [None])[0]
    if not result or not result.get("timestamp"):
        return pd.DataFrame()
    quote = (result.get("indicators", {}).get("quote") or [{}])[0]
    adjclose = (result.get("indicators", {}).get("adjclose") or [{}])[0].get("adjclose")
    regular_price = result.get("meta", {}).get("regularMarketPrice")
    rows = []
    for i, ts in enumerate(result["timestamp"]):
        close = (quote.get("close") or [None] * len(result["timestamp"]))[i]
        if close is None and regular_price is not None and i == len(result["timestamp"]) - 1:
            close = regular_price
        open_ = (quote.get("open") or [None] * len(result["timestamp"]))[i]
        high = (quote.get("high") or [None] * len(result["timestamp"]))[i]
        low = (quote.get("low") or [None] * len(result["timestamp"]))[i]
        rows.append({
            "Date": pd.to_datetime(ts, unit="s", utc=True),
            "Open": open_ if open_ is not None else close,
            "High": high if high is not None else close,
            "Low": low if low is not None else close,
            "Close": close,
            "Volume": (quote.get("volume") or [None] * len(result["timestamp"]))[i],
            "Adj Close": adjclose[i] if adjclose and i < len(adjclose) else None,
        })
    df = _prepare_ohlcv_frame(pd.DataFrame(rows))
    df.attrs["source"] = "yahoo_chart"
    return df


def download_yfinance(symbol: str, period: str, interval: str):
    try:
        import yfinance as yf
        df = yf.download(symbol, period=period, interval=interval, auto_adjust=False, progress=False, threads=False)
        df = _prepare_ohlcv_frame(df)
        if not df.empty:
            df.attrs["source"] = "yfinance"
            return df
    except Exception:
        pass
    df = download_yahoo_chart(symbol, period, interval)
    if df.empty:
        raise RuntimeError(f"No market data returned for {symbol} from yfinance or Yahoo chart")
    return df


def refresh_market_data(db: Session, symbols: list[str], period: str = "6mo", interval: str = "1d") -> list[dict]:
    results = []
    for symbol in symbols:
        try:
            sym = ensure_symbol(db, symbol)
            df = download_yfinance(symbol, period, interval)
            source = df.attrs.get("source", "yfinance")
            rows = 0
            for _, r in df.iterrows():
                def val(name):
                    x = r.get(name)
                    return None if pd.isna(x) else float(x)
                stmt = insert(MarketOHLCV).values(
                    symbol_id=sym.symbol_id,
                    timestamp=r["timestamp"].to_pydatetime(),
                    timeframe=interval,
                    open=val("Open"),
                    high=val("High"),
                    low=val("Low"),
                    close=val("Close"),
                    volume=val("Volume"),
                    adjusted_close=val("Adj Close") if "Adj Close" in df.columns else None,
                    source=source,
                    quality_status="ok",
                    source_metadata={"period": period, "interval": interval},
                ).on_conflict_do_update(
                    constraint="uq_ohlcv_symbol_tf_ts",
                    set_={"open": val("Open"), "high": val("High"), "low": val("Low"), "close": val("Close"), "volume": val("Volume"), "adjusted_close": val("Adj Close") if "Adj Close" in df.columns else None, "source": source, "quality_status":"ok"}
                )
                db.execute(stmt)
                rows += 1
            audit(db, "market_data_refreshed", f"Refreshed {symbol}: {rows} rows", ref_type="symbol", ref_id=sym.symbol_id, event_data={"symbol": symbol, "rows": rows})
            db.commit()
            results.append({"symbol": symbol, "rows": rows, "source": source})
        except Exception as exc:
            db.rollback()
            system_event(db, "market_data", "refresh_failed", f"Failed to refresh {symbol}: {exc}", "error", {"symbol": symbol})
            db.commit()
            results.append({"symbol": symbol, "error": str(exc)})
    return results


def latest_prices(db: Session, symbols: list[str] | None = None) -> list[dict]:
    q = select(MarketSymbol)
    if symbols:
        q = q.where(MarketSymbol.symbol.in_(symbols))
    out = []
    for sym in db.scalars(q.order_by(MarketSymbol.symbol)).all():
        c = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
        if c:
            out.append({"symbol": sym.symbol, "display_name": sym.display_name, "asset_class": sym.asset_class, "timestamp": c.timestamp, "close": float(c.close) if c.close is not None else None, "source": c.source, "quality_status": c.quality_status})
    return out


def fetch_deribit_book_summary(db: Session, currency: str = "BTC", kind: str | None = None) -> dict:
    params = {"currency": currency.upper()}
    if kind:
        params["kind"] = kind
    with httpx.Client(timeout=30) as client:
        resp = client.get("https://www.deribit.com/api/v2/public/get_book_summary_by_currency", params=params)
        resp.raise_for_status()
        payload = resp.json()
    if "error" in payload:
        raise RuntimeError(str(payload["error"]))
    rows = payload.get("result", []) or []
    for item in rows:
        db.add(DeribitBookSummary(
            currency=currency.upper(),
            instrument_name=item.get("instrument_name", "unknown"),
            kind=kind,
            mark_price=item.get("mark_price"),
            open_interest=item.get("open_interest"),
            volume=item.get("volume"),
            raw=item
        ))
    audit(db, "deribit_book_summary_fetched", f"Fetched {len(rows)} Deribit rows for {currency}", event_data={"currency": currency, "kind": kind, "rows": len(rows)})
    db.commit()
    return {"currency": currency.upper(), "rows": len(rows), "data": rows[:200]}


def fetch_eia(db: Session, route: str, params: dict) -> dict:
    settings = get_settings()
    if not settings.eia_api_key:
        raise ValueError("EIA_API_KEY is not set in .env")
    q = dict(params)
    q["api_key"] = settings.eia_api_key
    with httpx.Client(timeout=60) as client:
        resp = client.get(f"https://api.eia.gov/v2/{route.strip('/')}/", params=q)
        resp.raise_for_status()
        payload = resp.json()
    data = payload.get("response", {}).get("data", []) or []
    saved = 0
    for item in data:
        val = item.get("value")
        try:
            val = float(val) if val not in (None, "") else None
        except Exception:
            val = None
        db.add(EIAObservation(
            series_id=str(item.get("series") or item.get("series_id") or route),
            period=str(item.get("period") or item.get("date") or "unknown"),
            value=val,
            units=item.get("units"),
            raw=item,
        ))
        saved += 1
    audit(db, "eia_data_fetched", f"Fetched {saved} EIA rows", event_data={"route": route, "rows": saved})
    db.commit()
    return {"route": route, "rows": saved}


def _secret_cipher() -> Fernet:
    secret = get_settings().jwt_secret_key.encode("utf-8")
    key = base64.urlsafe_b64encode(hashlib.sha256(secret).digest())
    return Fernet(key)


def _encrypt_secret(value: str) -> str:
    return _secret_cipher().encrypt(value.encode("utf-8")).decode("utf-8")


def _decrypt_secret(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _secret_cipher().decrypt(value.encode("utf-8")).decode("utf-8")
    except InvalidToken:
        return None


def _mask_secret(value: str | None) -> str | None:
    if not value:
        return None
    if len(value) <= 8:
        return "****"
    return f"{value[:3]}...{value[-4:]}"


def _setting_value(db: Session | None, key: str, secret: bool = False) -> str | None:
    if db is None:
        return None
    row = db.get(SystemSetting, key)
    if not row or row.setting_value in (None, ""):
        return None
    return _decrypt_secret(row.setting_value) if secret else row.setting_value


def _upsert_setting(db: Session, key: str, value: str, user_id: str | None, secret: bool = False):
    stored_value = _encrypt_secret(value) if secret else value
    row = db.get(SystemSetting, key)
    if row:
        row.setting_value = stored_value
        row.is_secret = secret
        row.updated_by = user_id
        row.updated_at = utcnow()
        return row
    row = SystemSetting(setting_key=key, setting_value=stored_value, is_secret=secret, updated_by=user_id)
    db.add(row)
    return row


def _effective_ai_config(db: Session | None = None) -> dict:
    settings = get_settings()
    db_key = _setting_value(db, "ai.openai_api_key", secret=True)
    api_key = db_key or settings.openai_api_key
    key_source = "database" if db_key else ("environment" if settings.openai_api_key else "missing")
    return {
        "api_key": api_key,
        "key_source": key_source,
        "provider": "openai_compatible",
        "api_base": _setting_value(db, "ai.openai_api_base") or settings.openai_api_base,
        "model": _setting_value(db, "ai.openai_model") or settings.openai_model,
        "api_mode": _setting_value(db, "ai.openai_api_mode") or settings.openai_api_mode,
        "request_timeout_seconds": int(_setting_value(db, "ai.request_timeout_seconds") or settings.ai_request_timeout_seconds),
        "mode": "advisory_only",
        "live_trading_enabled": False,
    }


def ai_status(db: Session | None = None) -> dict:
    config = _effective_ai_config(db)
    configured = bool(config["api_key"])
    return {
        "configured": configured,
        "provider": config["provider"],
        "model": config["model"],
        "api_base": config["api_base"],
        "api_mode": config["api_mode"],
        "key_source": config["key_source"],
        "key_hint": _mask_secret(config["api_key"]),
        "request_timeout_seconds": config["request_timeout_seconds"],
        "mode": config["mode"],
        "live_trading_enabled": False,
        "message": "AI advisory layer ready" if configured else "Set an OpenAI API key from Admin AI Settings or .env.",
    }


def admin_ai_settings(db: Session) -> dict:
    return ai_status(db)


def save_ai_settings(db: Session, user_id: str, req) -> dict:
    _upsert_setting(db, "ai.openai_api_base", req.api_base.strip().rstrip("/"), user_id)
    _upsert_setting(db, "ai.openai_model", req.model.strip(), user_id)
    _upsert_setting(db, "ai.openai_api_mode", req.api_mode, user_id)
    _upsert_setting(db, "ai.request_timeout_seconds", str(req.request_timeout_seconds), user_id)
    if req.clear_api_key:
        db.execute(delete(SystemSetting).where(SystemSetting.setting_key == "ai.openai_api_key"))
    elif req.api_key:
        _upsert_setting(db, "ai.openai_api_key", req.api_key.strip(), user_id, secret=True)
    audit(db, "ai_settings_updated", "Updated AI advisory settings", user_id=user_id)
    db.commit()
    return admin_ai_settings(db)


def _ai_not_configured(agent: str, config: dict | None = None) -> dict:
    config = config or _effective_ai_config()
    return {
        "configured": False,
        "agent": agent,
        "model": config["model"],
        "mode": "advisory_only",
        "content": "AI is not configured. Add an OpenAI API key in Admin AI Settings or set OPENAI_API_KEY in .env.",
        "safety": "No live trading execution is performed by the AI layer.",
    }


def _latest_market_context(db: Session, symbols: list[str] | None = None, candle_limit: int = 80) -> list[dict]:
    q = select(MarketSymbol)
    if symbols:
        q = q.where(MarketSymbol.symbol.in_(symbols))
    out = []
    for sym in db.scalars(q.order_by(MarketSymbol.symbol)).all():
        rows = db.scalars(
            select(MarketOHLCV)
            .where(MarketOHLCV.symbol_id == sym.symbol_id)
            .order_by(MarketOHLCV.timestamp.desc())
            .limit(candle_limit)
        ).all()
        ordered = list(reversed(rows))
        closes = [float(r.close) for r in ordered if r.close is not None]
        latest = ordered[-1] if ordered else None
        item = {
            "symbol": sym.symbol,
            "display_name": sym.display_name,
            "asset_class": sym.asset_class,
            "exchange": sym.exchange,
            "candles": len(ordered),
            "latest_timestamp": latest.timestamp.isoformat() if latest else None,
            "latest_close": float(latest.close) if latest and latest.close is not None else None,
            "source": latest.source if latest else None,
            "quality_status": latest.quality_status if latest else None,
        }
        if len(closes) >= 2 and closes[-2]:
            item["return_1d_pct"] = (closes[-1] / closes[-2] - 1) * 100
        if len(closes) >= 6 and closes[-6]:
            item["return_5d_pct"] = (closes[-1] / closes[-6] - 1) * 100
        if len(closes) >= 21 and closes[-21]:
            item["return_20d_pct"] = (closes[-1] / closes[-21] - 1) * 100
        out.append(item)
    return out


def _portfolio_context(db: Session, user_id: str) -> dict:
    summary = recalculate_portfolio(db, user_id)
    positions = db.scalars(select(PaperPosition).where(PaperPosition.user_id == user_id, PaperPosition.status == "open")).all()
    return {
        "summary": summary,
        "positions": [
            {
                "symbol_id": p.symbol_id,
                "side": p.position_side,
                "quantity": float(p.quantity),
                "avg_entry_price": float(p.avg_entry_price),
                "current_mark_price": float(p.current_mark_price),
                "unrealized_pnl": float(p.unrealized_pnl),
            }
            for p in positions
        ],
    }


def _extract_openai_text(payload: dict) -> str:
    if payload.get("output_text"):
        return payload["output_text"]
    parts = []
    for item in payload.get("output", []) or []:
        for content in item.get("content", []) or []:
            if content.get("type") in ("output_text", "text"):
                parts.append(content.get("text", ""))
    if parts:
        return "\n".join(part for part in parts if part)
    return payload.get("choices", [{}])[0].get("message", {}).get("content", "")


def _call_ai(db: Session, agent: str, system_prompt: str, user_payload: dict) -> dict:
    config = _effective_ai_config(db)
    if not config["api_key"]:
        return _ai_not_configured(agent, config)
    api_mode = config["api_mode"]
    if api_mode == "chat_completions":
        url = config["api_base"].rstrip("/") + "/chat/completions"
        body = {
            "model": config["model"],
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(user_payload, default=str, indent=2)},
            ],
        }
    else:
        url = config["api_base"].rstrip("/") + "/responses"
        body = {
            "model": config["model"],
            "instructions": system_prompt,
            "input": json.dumps(user_payload, default=str, indent=2),
        }
    headers = {
        "Authorization": f"Bearer {config['api_key']}",
        "Content-Type": "application/json",
    }
    with httpx.Client(timeout=config["request_timeout_seconds"]) as client:
        resp = client.post(url, headers=headers, json=body)
        resp.raise_for_status()
        payload = resp.json()
    return {
        "configured": True,
        "agent": agent,
        "model": config["model"],
        "api_mode": api_mode,
        "mode": "advisory_only",
        "content": _extract_openai_text(payload),
        "usage": payload.get("usage"),
        "safety": "AI output is advisory only. Risk approval and trading execution remain deterministic and paper-only.",
    }


def test_ai_connection(db: Session, prompt: str) -> dict:
    system = (
        "You are checking the 2 Comma Agentic Trade OS AI configuration. "
        "Reply in one short sentence. Do not provide financial advice."
    )
    return _call_ai(db, "connection_test", system, {"prompt": prompt, "check": "connection"})


def ai_market_brief(db: Session, symbols: list[str], horizon: str = "24-72 hours", focus: str | None = None) -> dict:
    market = _latest_market_context(db, symbols)
    system = (
        "You are the Market Analyst Agent for a paper-trading research system. "
        "Use only the supplied market context. Produce a concise monitoring brief with: "
        "1) key market moves, 2) data quality gaps, 3) watchlist risks, 4) next checks. "
        "Do not claim certainty, do not provide personalized financial advice, and do not suggest live execution."
    )
    return _call_ai(db, "market_analyst", system, {"horizon": horizon, "focus": focus, "market_context": market})


def ai_portfolio_review(db: Session, user_id: str, focus: str | None = None) -> dict:
    portfolio = _portfolio_context(db, user_id)
    market = _latest_market_context(db, None, candle_limit=30)
    system = (
        "You are the Portfolio Coach Agent for a paper-trading system. "
        "Review the supplied portfolio and market context. Highlight exposure, drawdown, concentration, missing data, "
        "and operational next steps. Keep it advisory and paper-trading only. Do not recommend live execution."
    )
    return _call_ai(db, "portfolio_coach", system, {"focus": focus, "portfolio_context": portfolio, "market_context": market})


def ai_risk_review(db: Session, user_id: str, signal_id: str | None = None, requested_position_size: float | None = None, focus: str | None = None) -> dict:
    portfolio = _portfolio_context(db, user_id)
    signal_context = None
    if signal_id:
        signal = db.get(Signal, signal_id)
        if signal:
            sym = db.get(MarketSymbol, signal.symbol_id)
            signal_context = {
                "signal_id": signal.signal_id,
                "symbol": sym.symbol if sym else signal.symbol_id,
                "direction": signal.direction,
                "confidence": float(signal.confidence or 0),
                "entry_reference_price": float(signal.entry_reference_price or 0),
                "stop_loss_price": float(signal.stop_loss_price) if signal.stop_loss_price else None,
                "status": signal.status,
                "timestamp": signal.timestamp.isoformat(),
            }
    risk_profile = active_risk_profile(db, user_id)
    system = (
        "You are the Risk Reviewer Agent for a paper-trading system. "
        "Explain risk using the supplied portfolio, risk profile, and optional signal. "
        "You may suggest checks or reductions, but deterministic code remains the final approval authority. "
        "Do not approve live trading or bypass risk rules."
    )
    return _call_ai(db, "risk_reviewer", system, {
        "focus": focus,
        "requested_position_size": requested_position_size,
        "signal_context": signal_context,
        "portfolio_context": portfolio,
        "risk_profile": {
            "max_position_pct": float(risk_profile.max_position_pct),
            "max_loss_per_trade_pct": float(risk_profile.max_loss_per_trade_pct),
            "max_daily_loss_pct": float(risk_profile.max_daily_loss_pct),
            "max_drawdown_pct": float(risk_profile.max_drawdown_pct),
            "max_open_trades": risk_profile.max_open_trades,
            "live_trading_allowed": bool(risk_profile.live_trading_allowed),
        },
    })


def generate_features(db: Session, symbol: str, timeframe: str = "1d") -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < 60:
        raise ValueError("Need at least 60 candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close), "volume": float(r.volume or 0)} for r in rows if r.close is not None])
    df["ret_1"] = df["close"].pct_change()
    df["ema_20"] = df["close"].ewm(span=20, adjust=False).mean()
    df["ema_50"] = df["close"].ewm(span=50, adjust=False).mean()
    df["vol_20"] = df["ret_1"].rolling(20).std()
    inserted = 0
    for _, r in df.dropna().iterrows():
        features = {k: float(r[k]) for k in ["ret_1", "ema_20", "ema_50", "vol_20"]}
        stmt = insert(MarketFeature).values(
            symbol_id=sym.symbol_id, timestamp=r["timestamp"], timeframe=timeframe,
            feature_set_name="core", feature_set_version="v1", features=features, quality_status="ok"
        ).on_conflict_do_update(constraint="uq_features_symbol_tf_ts_ver", set_={"features": features, "quality_status": "ok"})
        db.execute(stmt)
        inserted += 1
    audit(db, "features_generated", f"Generated {inserted} feature rows for {symbol}", ref_type="symbol", ref_id=sym.symbol_id)
    db.commit()
    return {"symbol": symbol, "rows": inserted, "feature_set": "core:v1"}


def run_ema_backtest(db: Session, symbol: str, timeframe: str = "1d", short: int = 20, long: int = 50, fee_bps: float = 5, slippage_bps: float = 5) -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < long + 20:
        raise ValueError("Not enough candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close)} for r in rows if r.close is not None])
    df["ret"] = df["close"].pct_change().fillna(0)
    df["ema_s"] = df["close"].ewm(span=short, adjust=False).mean()
    df["ema_l"] = df["close"].ewm(span=long, adjust=False).mean()
    df["signal"] = (df["ema_s"] > df["ema_l"]).astype(int)
    df["position"] = df["signal"].shift(1).fillna(0)
    turnover = df["position"].diff().abs().fillna(0)
    cost = turnover * ((fee_bps + slippage_bps) / 10000)
    df["strategy_ret"] = df["position"] * df["ret"] - cost
    df["equity"] = (1 + df["strategy_ret"]).cumprod()
    total_return = float((df["equity"].iloc[-1] - 1) * 100)
    drawdown = (df["equity"] / df["equity"].cummax() - 1) * 100
    max_dd = float(drawdown.min())
    trades = int((turnover > 0).sum())
    trade_rets = df.loc[turnover > 0, "strategy_ret"]
    win_rate = float((trade_rets > 0).mean() * 100) if len(trade_rets) else 0.0
    sharpe = None if df["strategy_ret"].std() == 0 else float(df["strategy_ret"].mean() / df["strategy_ret"].std() * np.sqrt(252))
    metrics = {"total_return_pct": total_return, "max_drawdown_pct": max_dd, "win_rate_pct": win_rate, "num_trades": trades, "sharpe_ratio": sharpe}
    run = BacktestRun(symbol_id=sym.symbol_id, timeframe=timeframe, status="completed", config={"short": short, "long": long, "fee_bps": fee_bps, "slippage_bps": slippage_bps}, metrics=metrics, completed_at=utcnow())
    db.add(run)
    db.flush()
    audit(db, "backtest_completed", f"Completed EMA backtest for {symbol}", ref_type="backtest", ref_id=run.backtest_run_id, event_data=metrics)
    db.commit()
    metrics["backtest_run_id"] = run.backtest_run_id
    return metrics


def generate_signal(db: Session, user_id: str, symbol: str, timeframe: str = "1d", short: int = 20, long: int = 50) -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < long + 5:
        raise ValueError("Not enough candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close)} for r in rows if r.close is not None])
    df["ema_s"] = df["close"].ewm(span=short, adjust=False).mean()
    df["ema_l"] = df["close"].ewm(span=long, adjust=False).mean()
    last = df.iloc[-1]
    direction = "long" if last["ema_s"] > last["ema_l"] else "flat"
    confidence = float(min(0.75, max(0.50, 0.5 + abs(last["ema_s"]/last["ema_l"]-1)*10)))
    signal = Signal(user_id=user_id, symbol_id=sym.symbol_id, timeframe=timeframe, direction=direction, confidence=confidence, entry_reference_price=float(last["close"]), stop_loss_price=float(last["close"] * 0.97) if direction == "long" else None, expires_at=utcnow() + timedelta(hours=24))
    db.add(signal)
    db.flush()
    audit(db, "signal_created", f"Generated signal for {symbol}: {direction}", user_id=user_id, ref_type="signal", ref_id=signal.signal_id, event_data={"symbol": symbol, "direction": direction, "confidence": confidence})
    db.commit()
    return {"signal_id": signal.signal_id, "symbol": symbol, "direction": direction, "confidence": confidence, "entry_reference_price": float(signal.entry_reference_price or 0), "status": signal.status}


def latest_snapshot(db: Session, user_id: str) -> PortfolioSnapshot:
    snap = db.scalar(select(PortfolioSnapshot).where(PortfolioSnapshot.user_id == user_id).order_by(PortfolioSnapshot.timestamp.desc()).limit(1))
    if snap:
        return snap
    settings = get_settings()
    snap = PortfolioSnapshot(user_id=user_id, cash_balance=settings.paper_initial_cash, equity_value=settings.paper_initial_cash, exposure_by_symbol={})
    db.add(snap)
    db.flush()
    db.commit()
    return snap


def active_risk_profile(db: Session, user_id: str) -> UserRiskProfile:
    profile = db.scalar(select(UserRiskProfile).where(UserRiskProfile.user_id == user_id, UserRiskProfile.is_active == True).order_by(UserRiskProfile.profile_version.desc()).limit(1))
    if not profile:
        profile = UserRiskProfile(user_id=user_id)
        db.add(profile)
        db.flush()
        db.commit()
    return profile


def run_risk_check(db: Session, user_id: str, signal_id: str, requested_position_size: float) -> dict:
    user = db.get(User, user_id)
    signal = db.get(Signal, signal_id)
    if not user or not signal:
        raise ValueError("Missing user or signal")
    profile = active_risk_profile(db, user_id)
    snap = latest_snapshot(db, user_id)
    reasons = []
    rules = {}
    latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == signal.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
    max_position = float(snap.equity_value) * float(profile.max_position_pct) / 100
    approved_size = min(requested_position_size, max_position)
    rules["paper_trading_enabled"] = bool(user.paper_trading_enabled)
    rules["live_trading_disabled"] = not bool(user.live_trading_enabled)
    rules["latest_price_available"] = latest is not None and latest.close is not None
    rules["signal_candidate"] = signal.status == "candidate"
    rules["max_position_ok"] = requested_position_size <= max_position
    if not user.paper_trading_enabled:
        reasons.append("paper_trading_disabled")
    if user.live_trading_enabled:
        reasons.append("live_trading_disabled_by_platform")
    if signal.status != "candidate":
        reasons.append("invalid_signal_status")
    if not latest:
        reasons.append("missing_latest_price")
    if float(snap.daily_pnl_pct) <= -float(profile.max_daily_loss_pct):
        reasons.append("max_daily_loss_exceeded")
    if float(snap.drawdown_pct) >= float(profile.max_drawdown_pct):
        reasons.append("max_drawdown_exceeded")
    open_count = len(db.scalars(select(PaperPosition).where(PaperPosition.user_id == user_id, PaperPosition.status == "open")).all())
    if open_count >= int(profile.max_open_trades):
        reasons.append("max_open_trades_exceeded")
    estimated_loss_pct = None
    if signal.stop_loss_price and signal.entry_reference_price:
        risk_per_unit = abs(float(signal.entry_reference_price) - float(signal.stop_loss_price)) / float(signal.entry_reference_price)
        estimated_loss_pct = requested_position_size * risk_per_unit / float(snap.equity_value) * 100
        if estimated_loss_pct > float(profile.max_loss_per_trade_pct):
            allowed_loss_value = float(snap.equity_value) * float(profile.max_loss_per_trade_pct) / 100
            approved_size = min(approved_size, allowed_loss_value / risk_per_unit)
    decision = "rejected" if reasons else ("reduced_size" if approved_size < requested_position_size else "approved_paper")
    rc = RiskCheck(signal_id=signal_id, user_id=user_id, risk_profile_id=profile.risk_profile_id, decision=decision, requested_position_size=requested_position_size, approved_position_size=approved_size if decision != "rejected" else 0, max_allowed_position_size=max_position, estimated_loss_pct=estimated_loss_pct, rejection_reasons={"reasons": reasons}, rules_evaluated=rules, portfolio_snapshot_id=snap.portfolio_snapshot_id)
    db.add(rc)
    signal.status = "risk_approved" if decision in ("approved_paper", "reduced_size") else "risk_rejected"
    db.flush()
    audit(db, f"risk_check_{decision}", f"Risk check decision: {decision}", user_id=user_id, ref_type="risk_check", ref_id=rc.risk_check_id, event_data={"reasons": reasons, "rules": rules})
    db.commit()
    return {"risk_check_id": rc.risk_check_id, "decision": decision, "approved_position_size": float(rc.approved_position_size or 0), "rejection_reasons": reasons, "rules_evaluated": rules}


def create_paper_order(db: Session, user_id: str, risk_check_id: str) -> dict:
    rc = db.get(RiskCheck, risk_check_id)
    if not rc or rc.user_id != user_id:
        raise ValueError("Risk check not found")
    if rc.decision not in ("approved_paper", "reduced_size"):
        raise ValueError("Risk check is not approved")
    signal = db.get(Signal, rc.signal_id)
    latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == signal.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
    if not latest or latest.close is None:
        raise ValueError("Missing latest price")
    price = float(latest.close)
    notional = float(rc.approved_position_size or 0)
    qty = notional / price
    side = "buy" if signal.direction == "long" else "sell"
    order = PaperOrder(user_id=user_id, signal_id=signal.signal_id, risk_check_id=rc.risk_check_id, symbol_id=signal.symbol_id, side=side, quantity=qty, filled_price=price)
    db.add(order)
    snap = latest_snapshot(db, user_id)
    snap.cash_balance = float(snap.cash_balance) - notional if side == "buy" else float(snap.cash_balance) + notional
    db.add(PaperPosition(user_id=user_id, symbol_id=signal.symbol_id, position_side="long" if side == "buy" else "short", quantity=qty, avg_entry_price=price, current_mark_price=price))
    signal.status = "executed_paper"
    db.flush()
    audit(db, "paper_order_filled", "Paper order simulated", user_id=user_id, ref_type="paper_order", ref_id=order.paper_order_id, event_data={"qty": qty, "price": price, "notional": notional})
    db.commit()
    recalculate_portfolio(db, user_id)
    return {"paper_order_id": order.paper_order_id, "side": side, "quantity": qty, "filled_price": price, "status": order.status}


def recalculate_portfolio(db: Session, user_id: str) -> dict:
    last = latest_snapshot(db, user_id)
    positions = db.scalars(select(PaperPosition).where(PaperPosition.user_id == user_id, PaperPosition.status == "open")).all()
    unrealized = 0.0
    exposure = {}
    gross = 0.0
    for p in positions:
        latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == p.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
        mark = float(latest.close) if latest and latest.close else float(p.avg_entry_price)
        p.current_mark_price = mark
        qty = float(p.quantity)
        entry = float(p.avg_entry_price)
        pnl = (mark - entry) * qty if p.position_side == "long" else (entry - mark) * qty
        p.unrealized_pnl = pnl
        unrealized += pnl
        sym = db.get(MarketSymbol, p.symbol_id)
        value = abs(mark * qty)
        gross += value
        exposure[sym.symbol if sym else p.symbol_id] = value
    equity = float(last.cash_balance) + unrealized
    snap = PortfolioSnapshot(user_id=user_id, cash_balance=float(last.cash_balance), equity_value=equity, unrealized_pnl=unrealized, realized_pnl=float(last.realized_pnl), gross_exposure_pct=(gross/equity*100 if equity else 0), open_positions_count=len(positions), exposure_by_symbol=exposure)
    db.add(snap)
    db.flush()
    audit(db, "portfolio_recalculated", "Portfolio recalculated", user_id=user_id, ref_type="portfolio", ref_id=snap.portfolio_snapshot_id)
    db.commit()
    return {"portfolio_snapshot_id": snap.portfolio_snapshot_id, "cash_balance": float(snap.cash_balance), "equity_value": float(snap.equity_value), "unrealized_pnl": float(snap.unrealized_pnl), "gross_exposure_pct": float(snap.gross_exposure_pct), "open_positions_count": snap.open_positions_count, "exposure_by_symbol": snap.exposure_by_symbol}


def utcnow():
    return datetime.now(timezone.utc)
