from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    username: str | None = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class MarketRefreshRequest(BaseModel):
    symbols: list[str]
    period: str = "6mo"
    interval: str = "1d"


class SymbolCreate(BaseModel):
    symbol: str
    display_name: str
    asset_class: str
    exchange: str | None = None
    base_currency: str | None = None
    quote_currency: str | None = None
    country: str | None = None


class FeatureRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"


class BacktestRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"
    short: int = 20
    long: int = 50
    fee_bps: float = 5
    slippage_bps: float = 5


class SignalRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"
    short: int = 20
    long: int = 50


class RiskRequest(BaseModel):
    signal_id: str
    requested_position_size: float = Field(gt=0)


class PaperOrderRequest(BaseModel):
    risk_check_id: str


class AIMarketBriefRequest(BaseModel):
    symbols: list[str] = Field(default_factory=lambda: ["CPO=F", "CL=F", "GC=F", "BZ=F", "BTC-USD", "ETH-USD", "^KLSE", "MYR=X", "SGDMYR=X"])
    horizon: str = "24-72 hours"
    focus: str | None = None


class AIPortfolioReviewRequest(BaseModel):
    focus: str | None = None


class AIRiskReviewRequest(BaseModel):
    signal_id: str | None = None
    requested_position_size: float | None = Field(default=None, gt=0)
    focus: str | None = None


class AISettingsRequest(BaseModel):
    api_key: str | None = Field(default=None, min_length=8)
    api_base: str = Field(default="https://api.openai.com/v1", min_length=8)
    model: str = Field(default="gpt-5.1", min_length=2)
    api_mode: str = Field(default="responses", pattern="^(responses|chat_completions)$")
    request_timeout_seconds: int = Field(default=60, ge=10, le=180)
    clear_api_key: bool = False


class AITestRequest(BaseModel):
    prompt: str = "Return one sentence confirming that the 2 Comma AI advisory layer is connected."
