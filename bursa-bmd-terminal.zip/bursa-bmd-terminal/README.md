# BMD Terminal — Bursa Malaysia Derivatives

> Bloomberg-style real-time terminal for Bursa Malaysia Derivatives (BMD) palm oil, crude oil & related commodity products.

![React](https://img.shields.io/badge/React-18.3-61DAFB?logo=react&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-6.0-646CFF?logo=vite&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)

---

## Overview

A single-page Bloomberg Terminal-inspired dashboard that displays **all Bursa Malaysia Derivatives products** related to palm oil, crude oil, and associated commodities. Market data is fetched **live** via the Anthropic API using Claude's web search capability — no third-party market data subscriptions required.

### Key Features

- **Live market data** — prices fetched via Anthropic API + web search (FCPO, WTI, Brent, palm olein, PKO, soybean oil, UCO, KLIBOR, USD/MYR)
- **14 BMD products** across 4 categories: Futures (7), Options (2), Rates/Bonds (4), FX (1)
- **Real-time MYT clock** with market open/closed indicator
- **Scrolling ticker** with price changes
- **5 tabs**: Futures, Options, Rates/Bonds, FX, Market Overview dashboard
- **Responsive** — works on desktop and mobile
- **Zero external UI dependencies** — pure React + inline styles

---

## Products Covered

### Commodity Futures
| Code | Product | Currency | Settlement |
|------|---------|----------|------------|
| FCPO | Crude Palm Oil Futures | MYR | Physical |
| FEPO | East Malaysia CPO Futures | MYR | Physical |
| FUPO | USD Crude Palm Oil Futures | USD | Cash |
| FPOL | USD RBD Palm Olein Futures | USD | Physical (FOB) |
| FPKO | Crude Palm Kernel Oil Futures | MYR | Cash |
| FSOY | DCE Soybean Oil Futures | USD | Cash |
| FUCO | USD Used Cooking Oil Futures | USD | Cash |

### Options
| Code | Product | Currency | Underlying |
|------|---------|----------|------------|
| OCPO | Options on CPO Futures | MYR | FCPO |
| OPOL | USD RBD Palm Olein Options | USD | FPOL |

### Financial / Interest Rate
| Code | Product | Currency | Underlying |
|------|---------|----------|------------|
| FKB3 | 3-Month KLIBOR Futures | MYR | 3M KLIBOR |
| FMG3 | 3-Yr MY Govt Securities Futures | MYR | 3Y MGS |
| FMG5 | 5-Yr MY Govt Securities Futures | MYR | 5Y MGS |
| FMGA | 10-Yr MY Govt Securities Futures | MYR | 10Y MGS |

### FX
| Code | Product | Currency | Underlying |
|------|---------|----------|------------|
| FCNH | Mini USD/CNH Futures | USD/CNH | USD/CNH |

---

## Architecture

```
bursa-bmd-terminal/
├── index.html              # Entry HTML
├── package.json            # Dependencies & scripts
├── vite.config.js          # Vite build config
├── .gitignore
├── .env.example            # API key template
├── public/
│   └── favicon.svg         # BMD favicon
├── src/
│   ├── main.jsx            # React mount point
│   └── BursaTerminal.jsx   # Main terminal component (all-in-one)
└── README.md
```

### Data Flow

```
User opens app
  → Component mounts
  → 8 search queries batched into 3 groups
  → Each query → Anthropic API /v1/messages (Claude Sonnet + web_search tool)
  → Responses parsed with regex patterns for price extraction
  → Prices merged with fallback data
  → UI renders with live prices
```

**Note:** The app calls the Anthropic API directly from the browser. For production, you should proxy these calls through your own backend to avoid exposing API keys.

---

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/your-org/bursa-bmd-terminal.git
cd bursa-bmd-terminal

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev

# 4. Open http://localhost:3000
```

### Production Build

```bash
npm run build     # outputs to dist/
npm run preview   # preview the build locally
```

---

## Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `VITE_ANTHROPIC_API_KEY` | For standalone deploy | Anthropic API key for live data. Not needed when running inside Claude artifacts. |

### API Usage

The app makes ~8 API calls per refresh (batched into 3 groups). Each call uses Claude Sonnet with the `web_search` tool. Estimated cost per refresh: **~$0.02–0.05**.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 |
| Build | Vite 6 |
| Styling | Inline CSS (zero dependencies) |
| Fonts | Google Fonts (Share Tech Mono, Orbitron) |
| Data | Anthropic API + Claude web search |
| Deployment | Any static host (Vercel, Netlify, S3, etc.) |

---

## Deployment

### Vercel (recommended)
```bash
npm i -g vercel
vercel
```

### Netlify
```bash
npm run build
# drag dist/ folder to Netlify dashboard
```

### Docker
```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
```

---

## Production Considerations

> **For your CTO's review:**

1. **API Key Security** — Currently the Anthropic API is called client-side. For production, wrap it in a backend proxy (e.g., `/api/market-data` endpoint) so the key isn't exposed in the browser.

2. **Rate Limiting** — Each refresh makes ~8 API calls. Consider caching responses server-side (TTL 5–15 min) to reduce cost and latency.

3. **Data Accuracy** — Prices are extracted from web search results via regex. For financial-grade accuracy, consider integrating a dedicated market data provider (e.g., Refinitiv, Bloomberg B-PIPE, or CME Market Data).

4. **Credit/Interest Rate Swaps** — Bursa Malaysia does not currently list CDS or IRS products. OTC palm oil swaps are available through CME Group under the BMD–CME partnership (codes: CPO, POO, CPV, POX, POG) but are not exchange-traded on BMD.

5. **Crude Oil** — Bursa Malaysia does not list petroleum crude oil derivatives. WTI and Brent are shown as reference benchmarks only (they trade on NYMEX and ICE respectively).

---

## License

MIT — see [LICENSE](LICENSE) for details.

---

## Disclaimer

This terminal is for **informational and educational purposes only**. It does not constitute financial advice. Market data is sourced via web search and may not reflect real-time exchange prices. Always verify with official BMD/CME sources before making trading decisions.
