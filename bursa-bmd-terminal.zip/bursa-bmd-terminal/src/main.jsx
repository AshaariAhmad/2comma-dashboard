import React from 'react';
import ReactDOM from 'react-dom/client';
import BursaTerminal from './BursaTerminal';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BursaTerminal />
  </React.StrictMode>
);
