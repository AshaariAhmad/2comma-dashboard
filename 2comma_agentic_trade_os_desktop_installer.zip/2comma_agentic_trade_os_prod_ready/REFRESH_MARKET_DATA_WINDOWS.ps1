$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Refreshing real market data through backend API..." -ForegroundColor Cyan
$body = @{
  symbols = @("BTC-USD", "ETH-USD", "CL=F", "BZ=F", "^KLSE", "MYR=X", "SGDMYR=X")
  period = "6mo"
  interval = "1d"
} | ConvertTo-Json -Depth 5
$result = Invoke-RestMethod -Uri "http://localhost:8000/api/v1/markets/refresh" -Method POST -ContentType "application/json" -Body $body -TimeoutSec 120
$result | ConvertTo-Json -Depth 10
Write-Host "Done. Open http://localhost:8080 or http://localhost:8000/docs" -ForegroundColor Green
