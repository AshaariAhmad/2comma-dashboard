$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Starting 2 Comma Agentic Trade OS..." -ForegroundColor Cyan
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example." -ForegroundColor Yellow
}
docker compose up -d
Write-Host "Waiting for API..." -ForegroundColor Cyan
for ($i = 1; $i -le 30; $i++) {
    try {
        $res = Invoke-RestMethod -Uri "http://localhost:8000/api/v1/health" -TimeoutSec 2
        if ($res.status -eq "ok") { break }
    } catch { Start-Sleep -Seconds 2 }
}
docker compose ps
Start-Process "http://localhost:8080"
Start-Process "http://localhost:8000/docs"
Write-Host "Dashboard: http://localhost:8080" -ForegroundColor Green
Write-Host "API docs : http://localhost:8000/docs" -ForegroundColor Green
