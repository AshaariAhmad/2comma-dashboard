$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Stopping 2 Comma Agentic Trade OS..." -ForegroundColor Cyan
docker compose down
Write-Host "Stopped. Database data is kept in Docker volumes." -ForegroundColor Green
Write-Host "Use RESET_DATABASE_WINDOWS.bat only if you want to delete the database volume." -ForegroundColor Yellow
