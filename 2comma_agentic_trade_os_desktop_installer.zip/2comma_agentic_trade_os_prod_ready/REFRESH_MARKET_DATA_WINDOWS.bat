@echo off
setlocal
cd /d "%~dp0"
title Refresh 2 Comma Market Data
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REFRESH_MARKET_DATA_WINDOWS.ps1"
pause
