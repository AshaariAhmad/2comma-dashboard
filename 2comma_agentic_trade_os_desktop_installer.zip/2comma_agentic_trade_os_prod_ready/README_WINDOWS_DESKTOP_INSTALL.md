# 2 Comma Agentic Trade OS — Windows Desktop Install Guide

This package lets you run the 2 Comma Agentic Trade OS locally on your desktop using Docker Desktop.

## What you need first

1. Windows 10/11.
2. Docker Desktop installed and running.
3. WSL2 backend enabled in Docker Desktop.
4. At least 6–8 GB free RAM recommended.
5. Internet connection for Docker images and public market-data APIs.

You do **not** need to install Python manually if you use Docker.

## Quick install

1. Unzip this folder.
2. Open Docker Desktop and wait until Docker is running.
3. Double-click:

```text
INSTALL_WINDOWS.bat
```

The installer will:

- Create `.env` from `.env.example` if missing.
- Generate a local JWT secret.
- Build Docker containers.
- Start PostgreSQL/TimescaleDB, Redis, API, worker, and frontend.
- Create/update the admin user.
- Seed default symbols.
- Open the dashboard and API docs.

## Open the app

```text
Dashboard: http://localhost:8080
API docs : http://localhost:8000/docs
Health   : http://localhost:8000/api/v1/health
```

## Default local admin

```text
Email   : admin@example.com
Password: ChangeMe12345!
```

For public or shared use, change these in `.env` before starting.

## Useful desktop buttons

| File | Purpose |
|---|---|
| `INSTALL_WINDOWS.bat` | First install and start everything |
| `START_WINDOWS.bat` | Start the app after installation |
| `STOP_WINDOWS.bat` | Stop the app but keep database data |
| `STATUS_WINDOWS.bat` | Show container status and recent API logs |
| `OPEN_DASHBOARD_WINDOWS.bat` | Open dashboard and API docs |
| `REFRESH_MARKET_DATA_WINDOWS.bat` | Fetch real market data through the backend |
| `RESET_DATABASE_WINDOWS.bat` | Delete local database volumes and start fresh |

## Normal usage flow

1. Start Docker Desktop.
2. Double-click `START_WINDOWS.bat`.
3. Open the dashboard at `http://localhost:8080`.
4. Use `REFRESH_MARKET_DATA_WINDOWS.bat` to pull real market data.
5. Use API docs at `http://localhost:8000/docs` to test endpoints.
6. Use `STOP_WINDOWS.bat` when finished.

## What runs locally

| Service | Local URL / Port |
|---|---|
| Frontend dashboard | `http://localhost:8080` |
| FastAPI backend | `http://localhost:8000` |
| API docs | `http://localhost:8000/docs` |
| PostgreSQL/TimescaleDB | `localhost:5432` |
| Redis | `localhost:6379` |

## Safety mode

This desktop version is paper trading only.

```text
AI can propose and explain.
AI cannot approve risk.
AI cannot execute live trades.
Risk approval is deterministic.
Live trading is disabled by default.
```

## Troubleshooting

### Docker is missing

Install Docker Desktop, then restart your PC if required.

### Docker is installed but not running

Open Docker Desktop first. Wait until it says Docker is running, then run `INSTALL_WINDOWS.bat` again.

### Port already in use

The app uses these ports:

```text
8000 = FastAPI
8080 = Frontend
5432 = PostgreSQL
6379 = Redis
```

If another app uses these ports, stop that app or edit `docker-compose.yml`.

### API not healthy

Run:

```text
STATUS_WINDOWS.bat
```

Check the recent API logs printed at the bottom.

### Need to start fresh

Run:

```text
RESET_DATABASE_WINDOWS.bat
```

This deletes local database and Redis volumes for this project.

## GitHub upload

After testing locally:

```bash
git init
git add .
git commit -m "Add desktop installer for 2 Comma Agentic Trade OS"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git push -u origin main
```

Do not commit your `.env` file.
