import uuid
from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, JSON, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def uuid_str() -> str:
    return str(uuid.uuid4())


def utcnow():
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    user_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    username: Mapped[str | None] = mapped_column(String(100))
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(30), default="user", index=True)
    account_status: Mapped[str] = mapped_column(String(30), default="active", index=True)
    paper_trading_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    live_trading_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class UserRiskProfile(Base):
    __tablename__ = "user_risk_profiles"
    risk_profile_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.user_id", ondelete="CASCADE"), index=True)
    profile_version: Mapped[int] = mapped_column(Integer, default=1)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    max_position_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=5)
    max_loss_per_trade_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=1)
    max_daily_loss_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=3)
    max_drawdown_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=15)
    max_open_trades: Mapped[int] = mapped_column(Integer, default=5)
    max_symbol_exposure_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=20)
    manual_approval_required: Mapped[bool] = mapped_column(Boolean, default=True)
    live_trading_allowed: Mapped[bool] = mapped_column(Boolean, default=False)


class MarketSymbol(Base):
    __tablename__ = "market_symbols"
    symbol_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    symbol: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(255))
    asset_class: Mapped[str] = mapped_column(String(50), index=True)
    exchange: Mapped[str | None] = mapped_column(String(100))
    base_currency: Mapped[str | None] = mapped_column(String(20))
    quote_currency: Mapped[str | None] = mapped_column(String(20))
    country: Mapped[str | None] = mapped_column(String(10))
    data_source_primary: Mapped[str] = mapped_column(String(100), default="yfinance")
    is_tradeable_paper: Mapped[bool] = mapped_column(Boolean, default=True)
    is_tradeable_live: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class MarketOHLCV(Base):
    __tablename__ = "market_ohlcv"
    __table_args__ = (
        UniqueConstraint("symbol_id", "timeframe", "timestamp", name="uq_ohlcv_symbol_tf_ts"),
        Index("ix_ohlcv_symbol_ts", "symbol_id", "timestamp"),
    )
    ohlcv_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id", ondelete="CASCADE"), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    timeframe: Mapped[str] = mapped_column(String(20), index=True)
    open: Mapped[float | None] = mapped_column(Numeric(28, 10))
    high: Mapped[float | None] = mapped_column(Numeric(28, 10))
    low: Mapped[float | None] = mapped_column(Numeric(28, 10))
    close: Mapped[float | None] = mapped_column(Numeric(28, 10))
    volume: Mapped[float | None] = mapped_column(Numeric(28, 10))
    adjusted_close: Mapped[float | None] = mapped_column(Numeric(28, 10))
    source: Mapped[str] = mapped_column(String(100), default="yfinance")
    quality_status: Mapped[str] = mapped_column(String(30), default="ok")
    source_metadata: Mapped[dict | None] = mapped_column(JSON)
    ingested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class MarketFeature(Base):
    __tablename__ = "market_features"
    __table_args__ = (UniqueConstraint("symbol_id", "timeframe", "timestamp", "feature_set_version", name="uq_features_symbol_tf_ts_ver"),)
    feature_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id", ondelete="CASCADE"), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    timeframe: Mapped[str] = mapped_column(String(20), index=True)
    feature_set_name: Mapped[str] = mapped_column(String(100), default="core")
    feature_set_version: Mapped[str] = mapped_column(String(50), default="v1")
    features: Mapped[dict] = mapped_column(JSON)
    quality_status: Mapped[str] = mapped_column(String(30), default="ok")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class DeribitBookSummary(Base):
    __tablename__ = "deribit_book_summaries"
    summary_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    currency: Mapped[str] = mapped_column(String(20), index=True)
    instrument_name: Mapped[str] = mapped_column(String(100), index=True)
    kind: Mapped[str | None] = mapped_column(String(30))
    mark_price: Mapped[float | None] = mapped_column(Numeric(28, 10))
    open_interest: Mapped[float | None] = mapped_column(Numeric(28, 10))
    volume: Mapped[float | None] = mapped_column(Numeric(28, 10))
    raw: Mapped[dict] = mapped_column(JSON)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


class EIAObservation(Base):
    __tablename__ = "eia_observations"
    observation_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    series_id: Mapped[str] = mapped_column(String(255), index=True)
    period: Mapped[str] = mapped_column(String(50), index=True)
    value: Mapped[float | None] = mapped_column(Numeric(28, 10))
    units: Mapped[str | None] = mapped_column(String(100))
    raw: Mapped[dict] = mapped_column(JSON)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class BacktestRun(Base):
    __tablename__ = "backtest_runs"
    backtest_run_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id"), index=True)
    timeframe: Mapped[str] = mapped_column(String(20), index=True)
    status: Mapped[str] = mapped_column(String(30), default="running")
    config: Mapped[dict | None] = mapped_column(JSON)
    metrics: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Signal(Base):
    __tablename__ = "signals"
    signal_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.user_id"), index=True)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id"), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    timeframe: Mapped[str] = mapped_column(String(20))
    direction: Mapped[str] = mapped_column(String(20))
    confidence: Mapped[float | None] = mapped_column(Numeric(18, 8))
    entry_reference_price: Mapped[float | None] = mapped_column(Numeric(28, 10))
    stop_loss_price: Mapped[float | None] = mapped_column(Numeric(28, 10))
    status: Mapped[str] = mapped_column(String(40), default="candidate", index=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class PortfolioSnapshot(Base):
    __tablename__ = "portfolio_snapshots"
    portfolio_snapshot_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.user_id"), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    cash_balance: Mapped[float] = mapped_column(Numeric(28, 10))
    equity_value: Mapped[float] = mapped_column(Numeric(28, 10))
    realized_pnl: Mapped[float] = mapped_column(Numeric(28, 10), default=0)
    unrealized_pnl: Mapped[float] = mapped_column(Numeric(28, 10), default=0)
    daily_pnl_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=0)
    drawdown_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=0)
    gross_exposure_pct: Mapped[float] = mapped_column(Numeric(18, 8), default=0)
    open_positions_count: Mapped[int] = mapped_column(Integer, default=0)
    exposure_by_symbol: Mapped[dict] = mapped_column(JSON, default=dict)


class RiskCheck(Base):
    __tablename__ = "risk_checks"
    risk_check_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    signal_id: Mapped[str] = mapped_column(ForeignKey("signals.signal_id"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.user_id"), index=True)
    risk_profile_id: Mapped[str] = mapped_column(ForeignKey("user_risk_profiles.risk_profile_id"))
    decision: Mapped[str] = mapped_column(String(50), index=True)
    requested_position_size: Mapped[float | None] = mapped_column(Numeric(28, 10))
    approved_position_size: Mapped[float | None] = mapped_column(Numeric(28, 10))
    max_allowed_position_size: Mapped[float | None] = mapped_column(Numeric(28, 10))
    estimated_loss_pct: Mapped[float | None] = mapped_column(Numeric(18, 8))
    rejection_reasons: Mapped[dict] = mapped_column(JSON, default=dict)
    rules_evaluated: Mapped[dict] = mapped_column(JSON, default=dict)
    portfolio_snapshot_id: Mapped[str | None] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PaperOrder(Base):
    __tablename__ = "paper_orders"
    paper_order_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.user_id"), index=True)
    signal_id: Mapped[str] = mapped_column(ForeignKey("signals.signal_id"), index=True)
    risk_check_id: Mapped[str] = mapped_column(ForeignKey("risk_checks.risk_check_id"), index=True)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id"), index=True)
    side: Mapped[str] = mapped_column(String(10))
    quantity: Mapped[float] = mapped_column(Numeric(28, 10))
    filled_price: Mapped[float] = mapped_column(Numeric(28, 10))
    status: Mapped[str] = mapped_column(String(40), default="simulated_filled")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PaperPosition(Base):
    __tablename__ = "paper_positions"
    paper_position_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.user_id"), index=True)
    symbol_id: Mapped[str] = mapped_column(ForeignKey("market_symbols.symbol_id"), index=True)
    position_side: Mapped[str] = mapped_column(String(10))
    quantity: Mapped[float] = mapped_column(Numeric(28, 10))
    avg_entry_price: Mapped[float] = mapped_column(Numeric(28, 10))
    current_mark_price: Mapped[float | None] = mapped_column(Numeric(28, 10))
    unrealized_pnl: Mapped[float] = mapped_column(Numeric(28, 10), default=0)
    realized_pnl: Mapped[float] = mapped_column(Numeric(28, 10), default=0)
    status: Mapped[str] = mapped_column(String(30), default="open", index=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    audit_log_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(30), default="info", index=True)
    user_id: Mapped[str | None] = mapped_column(String(36), index=True)
    ref_type: Mapped[str | None] = mapped_column(String(50))
    ref_id: Mapped[str | None] = mapped_column(String(36))
    message: Mapped[str] = mapped_column(Text)
    event_data: Mapped[dict | None] = mapped_column(JSON)


class SystemEvent(Base):
    __tablename__ = "system_events"
    system_event_id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    service_name: Mapped[str] = mapped_column(String(100), index=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(30), default="info")
    status: Mapped[str] = mapped_column(String(30), default="open")
    message: Mapped[str] = mapped_column(Text)
    details: Mapped[dict | None] = mapped_column(JSON)
