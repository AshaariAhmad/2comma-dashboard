from celery import Celery
from backend.app.settings import get_settings
from backend.app.database import SessionLocal
from backend.app.services import refresh_market_data, generate_features, run_ema_backtest, generate_signal, run_risk_check, create_paper_order

settings = get_settings()

celery_app = Celery("twocomma", broker=settings.celery_broker_url, backend=settings.celery_result_backend)


@celery_app.task
def refresh_market_data_task(symbols: list[str], period: str = "6mo", interval: str = "1d"):
    with SessionLocal() as db:
        return refresh_market_data(db, symbols, period, interval)


@celery_app.task
def generate_features_task(symbol: str, timeframe: str = "1d"):
    with SessionLocal() as db:
        return generate_features(db, symbol, timeframe)


@celery_app.task
def run_backtest_task(symbol: str, timeframe: str = "1d", short: int = 20, long: int = 50):
    with SessionLocal() as db:
        return run_ema_backtest(db, symbol, timeframe, short, long)


@celery_app.task
def generate_signal_task(user_id: str, symbol: str, timeframe: str = "1d"):
    with SessionLocal() as db:
        return generate_signal(db, user_id, symbol, timeframe)


@celery_app.task
def run_risk_check_task(user_id: str, signal_id: str, requested_position_size: float):
    with SessionLocal() as db:
        return run_risk_check(db, user_id, signal_id, requested_position_size)


@celery_app.task
def create_paper_order_task(user_id: str, risk_check_id: str):
    with SessionLocal() as db:
        return create_paper_order(db, user_id, risk_check_id)
