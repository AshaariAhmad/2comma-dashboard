from __future__ import annotations
from datetime import datetime, timedelta, timezone
import pandas as pd
import numpy as np
import httpx
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from backend.app.settings import get_settings
from backend.app.models import (
    AuditLog, BacktestRun, DeribitBookSummary, EIAObservation, MarketFeature,
    MarketOHLCV, MarketSymbol, PaperOrder, PaperPosition, PortfolioSnapshot,
    RiskCheck, Signal, SystemEvent, User, UserRiskProfile
)

DEFAULT_SYMBOLS = [
    {"symbol":"BTC-USD","display_name":"Bitcoin USD","asset_class":"crypto","exchange":"Yahoo","base_currency":"BTC","quote_currency":"USD"},
    {"symbol":"ETH-USD","display_name":"Ethereum USD","asset_class":"crypto","exchange":"Yahoo","base_currency":"ETH","quote_currency":"USD"},
    {"symbol":"CL=F","display_name":"WTI Crude Oil Futures","asset_class":"commodity","exchange":"NYMEX","base_currency":"WTI","quote_currency":"USD"},
    {"symbol":"BZ=F","display_name":"Brent Crude Oil Futures","asset_class":"commodity","exchange":"ICE","base_currency":"BRENT","quote_currency":"USD"},
    {"symbol":"^KLSE","display_name":"FTSE Bursa Malaysia KLCI","asset_class":"index","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
    {"symbol":"MYR=X","display_name":"USD/MYR","asset_class":"fx","exchange":"Yahoo FX","base_currency":"USD","quote_currency":"MYR"},
    {"symbol":"SGDMYR=X","display_name":"SGD/MYR","asset_class":"fx","exchange":"Yahoo FX","base_currency":"SGD","quote_currency":"MYR"},
    {"symbol":"1155.KL","display_name":"Maybank","asset_class":"equity","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
    {"symbol":"1023.KL","display_name":"CIMB Group","asset_class":"equity","exchange":"Bursa Malaysia","country":"MY","quote_currency":"MYR"},
]


def audit(db: Session, event_type: str, message: str, user_id: str | None = None, severity: str = "info", ref_type: str | None = None, ref_id: str | None = None, event_data: dict | None = None):
    row = AuditLog(event_type=event_type, message=message, severity=severity, user_id=user_id, ref_type=ref_type, ref_id=ref_id, event_data=event_data or {})
    db.add(row)
    db.flush()
    return row


def system_event(db: Session, service_name: str, event_type: str, message: str, severity: str = "warning", details: dict | None = None):
    row = SystemEvent(service_name=service_name, event_type=event_type, message=message, severity=severity, details=details or {})
    db.add(row)
    db.flush()
    return row


def seed_symbols(db: Session) -> int:
    count = 0
    for item in DEFAULT_SYMBOLS:
        existing = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == item["symbol"]))
        if not existing:
            db.add(MarketSymbol(**item))
            count += 1
    audit(db, "symbols_seeded", f"Seeded {count} default symbols")
    db.commit()
    return count


def ensure_symbol(db: Session, symbol: str) -> MarketSymbol:
    existing = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if existing:
        return existing
    obj = MarketSymbol(symbol=symbol, display_name=symbol, asset_class="unknown", exchange="unknown")
    db.add(obj)
    db.flush()
    return obj


def download_yfinance(symbol: str, period: str, interval: str):
    import yfinance as yf
    df = yf.download(symbol, period=period, interval=interval, auto_adjust=False, progress=False, threads=False)
    if df is None or df.empty:
        return pd.DataFrame()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] for c in df.columns]
    df = df.reset_index()
    time_col = "Datetime" if "Datetime" in df.columns else "Date"
    df["timestamp"] = pd.to_datetime(df[time_col], utc=True)
    return df


def refresh_market_data(db: Session, symbols: list[str], period: str = "6mo", interval: str = "1d") -> list[dict]:
    results = []
    for symbol in symbols:
        try:
            sym = ensure_symbol(db, symbol)
            df = download_yfinance(symbol, period, interval)
            rows = 0
            for _, r in df.iterrows():
                def val(name):
                    x = r.get(name)
                    return None if pd.isna(x) else float(x)
                stmt = insert(MarketOHLCV).values(
                    symbol_id=sym.symbol_id,
                    timestamp=r["timestamp"].to_pydatetime(),
                    timeframe=interval,
                    open=val("Open"),
                    high=val("High"),
                    low=val("Low"),
                    close=val("Close"),
                    volume=val("Volume"),
                    adjusted_close=val("Adj Close") if "Adj Close" in df.columns else None,
                    source="yfinance",
                    quality_status="ok",
                    source_metadata={"period": period, "interval": interval},
                ).on_conflict_do_update(
                    constraint="uq_ohlcv_symbol_tf_ts",
                    set_={"open": val("Open"), "high": val("High"), "low": val("Low"), "close": val("Close"), "volume": val("Volume"), "adjusted_close": val("Adj Close") if "Adj Close" in df.columns else None, "source":"yfinance", "quality_status":"ok"}
                )
                db.execute(stmt)
                rows += 1
            audit(db, "market_data_refreshed", f"Refreshed {symbol}: {rows} rows", ref_type="symbol", ref_id=sym.symbol_id, event_data={"symbol": symbol, "rows": rows})
            db.commit()
            results.append({"symbol": symbol, "rows": rows})
        except Exception as exc:
            db.rollback()
            system_event(db, "market_data", "refresh_failed", f"Failed to refresh {symbol}: {exc}", "error", {"symbol": symbol})
            db.commit()
            results.append({"symbol": symbol, "error": str(exc)})
    return results


def latest_prices(db: Session, symbols: list[str] | None = None) -> list[dict]:
    q = select(MarketSymbol)
    if symbols:
        q = q.where(MarketSymbol.symbol.in_(symbols))
    out = []
    for sym in db.scalars(q.order_by(MarketSymbol.symbol)).all():
        c = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
        if c:
            out.append({"symbol": sym.symbol, "display_name": sym.display_name, "asset_class": sym.asset_class, "timestamp": c.timestamp, "close": float(c.close) if c.close is not None else None, "source": c.source, "quality_status": c.quality_status})
    return out


def fetch_deribit_book_summary(db: Session, currency: str = "BTC", kind: str | None = None) -> dict:
    params = {"currency": currency.upper()}
    if kind:
        params["kind"] = kind
    with httpx.Client(timeout=30) as client:
        resp = client.get("https://www.deribit.com/api/v2/public/get_book_summary_by_currency", params=params)
        resp.raise_for_status()
        payload = resp.json()
    if "error" in payload:
        raise RuntimeError(str(payload["error"]))
    rows = payload.get("result", []) or []
    for item in rows:
        db.add(DeribitBookSummary(
            currency=currency.upper(),
            instrument_name=item.get("instrument_name", "unknown"),
            kind=kind,
            mark_price=item.get("mark_price"),
            open_interest=item.get("open_interest"),
            volume=item.get("volume"),
            raw=item
        ))
    audit(db, "deribit_book_summary_fetched", f"Fetched {len(rows)} Deribit rows for {currency}", event_data={"currency": currency, "kind": kind, "rows": len(rows)})
    db.commit()
    return {"currency": currency.upper(), "rows": len(rows), "data": rows[:200]}


def fetch_eia(db: Session, route: str, params: dict) -> dict:
    settings = get_settings()
    if not settings.eia_api_key:
        raise ValueError("EIA_API_KEY is not set in .env")
    q = dict(params)
    q["api_key"] = settings.eia_api_key
    with httpx.Client(timeout=60) as client:
        resp = client.get(f"https://api.eia.gov/v2/{route.strip('/')}/", params=q)
        resp.raise_for_status()
        payload = resp.json()
    data = payload.get("response", {}).get("data", []) or []
    saved = 0
    for item in data:
        val = item.get("value")
        try:
            val = float(val) if val not in (None, "") else None
        except Exception:
            val = None
        db.add(EIAObservation(
            series_id=str(item.get("series") or item.get("series_id") or route),
            period=str(item.get("period") or item.get("date") or "unknown"),
            value=val,
            units=item.get("units"),
            raw=item,
        ))
        saved += 1
    audit(db, "eia_data_fetched", f"Fetched {saved} EIA rows", event_data={"route": route, "rows": saved})
    db.commit()
    return {"route": route, "rows": saved}


def generate_features(db: Session, symbol: str, timeframe: str = "1d") -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < 60:
        raise ValueError("Need at least 60 candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close), "volume": float(r.volume or 0)} for r in rows if r.close is not None])
    df["ret_1"] = df["close"].pct_change()
    df["ema_20"] = df["close"].ewm(span=20, adjust=False).mean()
    df["ema_50"] = df["close"].ewm(span=50, adjust=False).mean()
    df["vol_20"] = df["ret_1"].rolling(20).std()
    inserted = 0
    for _, r in df.dropna().iterrows():
        features = {k: float(r[k]) for k in ["ret_1", "ema_20", "ema_50", "vol_20"]}
        stmt = insert(MarketFeature).values(
            symbol_id=sym.symbol_id, timestamp=r["timestamp"], timeframe=timeframe,
            feature_set_name="core", feature_set_version="v1", features=features, quality_status="ok"
        ).on_conflict_do_update(constraint="uq_features_symbol_tf_ts_ver", set_={"features": features, "quality_status": "ok"})
        db.execute(stmt)
        inserted += 1
    audit(db, "features_generated", f"Generated {inserted} feature rows for {symbol}", ref_type="symbol", ref_id=sym.symbol_id)
    db.commit()
    return {"symbol": symbol, "rows": inserted, "feature_set": "core:v1"}


def run_ema_backtest(db: Session, symbol: str, timeframe: str = "1d", short: int = 20, long: int = 50, fee_bps: float = 5, slippage_bps: float = 5) -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < long + 20:
        raise ValueError("Not enough candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close)} for r in rows if r.close is not None])
    df["ret"] = df["close"].pct_change().fillna(0)
    df["ema_s"] = df["close"].ewm(span=short, adjust=False).mean()
    df["ema_l"] = df["close"].ewm(span=long, adjust=False).mean()
    df["signal"] = (df["ema_s"] > df["ema_l"]).astype(int)
    df["position"] = df["signal"].shift(1).fillna(0)
    turnover = df["position"].diff().abs().fillna(0)
    cost = turnover * ((fee_bps + slippage_bps) / 10000)
    df["strategy_ret"] = df["position"] * df["ret"] - cost
    df["equity"] = (1 + df["strategy_ret"]).cumprod()
    total_return = float((df["equity"].iloc[-1] - 1) * 100)
    drawdown = (df["equity"] / df["equity"].cummax() - 1) * 100
    max_dd = float(drawdown.min())
    trades = int((turnover > 0).sum())
    trade_rets = df.loc[turnover > 0, "strategy_ret"]
    win_rate = float((trade_rets > 0).mean() * 100) if len(trade_rets) else 0.0
    sharpe = None if df["strategy_ret"].std() == 0 else float(df["strategy_ret"].mean() / df["strategy_ret"].std() * np.sqrt(252))
    metrics = {"total_return_pct": total_return, "max_drawdown_pct": max_dd, "win_rate_pct": win_rate, "num_trades": trades, "sharpe_ratio": sharpe}
    run = BacktestRun(symbol_id=sym.symbol_id, timeframe=timeframe, status="completed", config={"short": short, "long": long, "fee_bps": fee_bps, "slippage_bps": slippage_bps}, metrics=metrics, completed_at=utcnow())
    db.add(run)
    db.flush()
    audit(db, "backtest_completed", f"Completed EMA backtest for {symbol}", ref_type="backtest", ref_id=run.backtest_run_id, event_data=metrics)
    db.commit()
    metrics["backtest_run_id"] = run.backtest_run_id
    return metrics


def generate_signal(db: Session, user_id: str, symbol: str, timeframe: str = "1d", short: int = 20, long: int = 50) -> dict:
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        raise ValueError("Unknown symbol")
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp)).all()
    if len(rows) < long + 5:
        raise ValueError("Not enough candles")
    df = pd.DataFrame([{"timestamp": r.timestamp, "close": float(r.close)} for r in rows if r.close is not None])
    df["ema_s"] = df["close"].ewm(span=short, adjust=False).mean()
    df["ema_l"] = df["close"].ewm(span=long, adjust=False).mean()
    last = df.iloc[-1]
    direction = "long" if last["ema_s"] > last["ema_l"] else "flat"
    confidence = float(min(0.75, max(0.50, 0.5 + abs(last["ema_s"]/last["ema_l"]-1)*10)))
    signal = Signal(user_id=user_id, symbol_id=sym.symbol_id, timeframe=timeframe, direction=direction, confidence=confidence, entry_reference_price=float(last["close"]), stop_loss_price=float(last["close"] * 0.97) if direction == "long" else None, expires_at=utcnow() + timedelta(hours=24))
    db.add(signal)
    db.flush()
    audit(db, "signal_created", f"Generated signal for {symbol}: {direction}", user_id=user_id, ref_type="signal", ref_id=signal.signal_id, event_data={"symbol": symbol, "direction": direction, "confidence": confidence})
    db.commit()
    return {"signal_id": signal.signal_id, "symbol": symbol, "direction": direction, "confidence": confidence, "entry_reference_price": float(signal.entry_reference_price or 0), "status": signal.status}


def latest_snapshot(db: Session, user_id: str) -> PortfolioSnapshot:
    snap = db.scalar(select(PortfolioSnapshot).where(PortfolioSnapshot.user_id == user_id).order_by(PortfolioSnapshot.timestamp.desc()).limit(1))
    if snap:
        return snap
    settings = get_settings()
    snap = PortfolioSnapshot(user_id=user_id, cash_balance=settings.paper_initial_cash, equity_value=settings.paper_initial_cash, exposure_by_symbol={})
    db.add(snap)
    db.flush()
    db.commit()
    return snap


def active_risk_profile(db: Session, user_id: str) -> UserRiskProfile:
    profile = db.scalar(select(UserRiskProfile).where(UserRiskProfile.user_id == user_id, UserRiskProfile.is_active == True).order_by(UserRiskProfile.profile_version.desc()).limit(1))
    if not profile:
        profile = UserRiskProfile(user_id=user_id)
        db.add(profile)
        db.flush()
        db.commit()
    return profile


def run_risk_check(db: Session, user_id: str, signal_id: str, requested_position_size: float) -> dict:
    user = db.get(User, user_id)
    signal = db.get(Signal, signal_id)
    if not user or not signal:
        raise ValueError("Missing user or signal")
    profile = active_risk_profile(db, user_id)
    snap = latest_snapshot(db, user_id)
    reasons = []
    rules = {}
    latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == signal.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
    max_position = float(snap.equity_value) * float(profile.max_position_pct) / 100
    approved_size = min(requested_position_size, max_position)
    rules["paper_trading_enabled"] = bool(user.paper_trading_enabled)
    rules["live_trading_disabled"] = not bool(user.live_trading_enabled)
    rules["latest_price_available"] = latest is not None and latest.close is not None
    rules["signal_candidate"] = signal.status == "candidate"
    rules["max_position_ok"] = requested_position_size <= max_position
    if not user.paper_trading_enabled:
        reasons.append("paper_trading_disabled")
    if user.live_trading_enabled:
        reasons.append("live_trading_disabled_by_platform")
    if signal.status != "candidate":
        reasons.append("invalid_signal_status")
    if not latest:
        reasons.append("missing_latest_price")
    if float(snap.daily_pnl_pct) <= -float(profile.max_daily_loss_pct):
        reasons.append("max_daily_loss_exceeded")
    if float(snap.drawdown_pct) >= float(profile.max_drawdown_pct):
        reasons.append("max_drawdown_exceeded")
    open_count = len(db.scalars(select(PaperPosition).where(PaperPosition.user_id == user_id, PaperPosition.status == "open")).all())
    if open_count >= int(profile.max_open_trades):
        reasons.append("max_open_trades_exceeded")
    estimated_loss_pct = None
    if signal.stop_loss_price and signal.entry_reference_price:
        risk_per_unit = abs(float(signal.entry_reference_price) - float(signal.stop_loss_price)) / float(signal.entry_reference_price)
        estimated_loss_pct = requested_position_size * risk_per_unit / float(snap.equity_value) * 100
        if estimated_loss_pct > float(profile.max_loss_per_trade_pct):
            allowed_loss_value = float(snap.equity_value) * float(profile.max_loss_per_trade_pct) / 100
            approved_size = min(approved_size, allowed_loss_value / risk_per_unit)
    decision = "rejected" if reasons else ("reduced_size" if approved_size < requested_position_size else "approved_paper")
    rc = RiskCheck(signal_id=signal_id, user_id=user_id, risk_profile_id=profile.risk_profile_id, decision=decision, requested_position_size=requested_position_size, approved_position_size=approved_size if decision != "rejected" else 0, max_allowed_position_size=max_position, estimated_loss_pct=estimated_loss_pct, rejection_reasons={"reasons": reasons}, rules_evaluated=rules, portfolio_snapshot_id=snap.portfolio_snapshot_id)
    db.add(rc)
    signal.status = "risk_approved" if decision in ("approved_paper", "reduced_size") else "risk_rejected"
    db.flush()
    audit(db, f"risk_check_{decision}", f"Risk check decision: {decision}", user_id=user_id, ref_type="risk_check", ref_id=rc.risk_check_id, event_data={"reasons": reasons, "rules": rules})
    db.commit()
    return {"risk_check_id": rc.risk_check_id, "decision": decision, "approved_position_size": float(rc.approved_position_size or 0), "rejection_reasons": reasons, "rules_evaluated": rules}


def create_paper_order(db: Session, user_id: str, risk_check_id: str) -> dict:
    rc = db.get(RiskCheck, risk_check_id)
    if not rc or rc.user_id != user_id:
        raise ValueError("Risk check not found")
    if rc.decision not in ("approved_paper", "reduced_size"):
        raise ValueError("Risk check is not approved")
    signal = db.get(Signal, rc.signal_id)
    latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == signal.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
    if not latest or latest.close is None:
        raise ValueError("Missing latest price")
    price = float(latest.close)
    notional = float(rc.approved_position_size or 0)
    qty = notional / price
    side = "buy" if signal.direction == "long" else "sell"
    order = PaperOrder(user_id=user_id, signal_id=signal.signal_id, risk_check_id=rc.risk_check_id, symbol_id=signal.symbol_id, side=side, quantity=qty, filled_price=price)
    db.add(order)
    snap = latest_snapshot(db, user_id)
    snap.cash_balance = float(snap.cash_balance) - notional if side == "buy" else float(snap.cash_balance) + notional
    db.add(PaperPosition(user_id=user_id, symbol_id=signal.symbol_id, position_side="long" if side == "buy" else "short", quantity=qty, avg_entry_price=price, current_mark_price=price))
    signal.status = "executed_paper"
    db.flush()
    audit(db, "paper_order_filled", "Paper order simulated", user_id=user_id, ref_type="paper_order", ref_id=order.paper_order_id, event_data={"qty": qty, "price": price, "notional": notional})
    db.commit()
    recalculate_portfolio(db, user_id)
    return {"paper_order_id": order.paper_order_id, "side": side, "quantity": qty, "filled_price": price, "status": order.status}


def recalculate_portfolio(db: Session, user_id: str) -> dict:
    last = latest_snapshot(db, user_id)
    positions = db.scalars(select(PaperPosition).where(PaperPosition.user_id == user_id, PaperPosition.status == "open")).all()
    unrealized = 0.0
    exposure = {}
    gross = 0.0
    for p in positions:
        latest = db.scalar(select(MarketOHLCV).where(MarketOHLCV.symbol_id == p.symbol_id).order_by(MarketOHLCV.timestamp.desc()).limit(1))
        mark = float(latest.close) if latest and latest.close else float(p.avg_entry_price)
        p.current_mark_price = mark
        qty = float(p.quantity)
        entry = float(p.avg_entry_price)
        pnl = (mark - entry) * qty if p.position_side == "long" else (entry - mark) * qty
        p.unrealized_pnl = pnl
        unrealized += pnl
        sym = db.get(MarketSymbol, p.symbol_id)
        value = abs(mark * qty)
        gross += value
        exposure[sym.symbol if sym else p.symbol_id] = value
    equity = float(last.cash_balance) + unrealized
    snap = PortfolioSnapshot(user_id=user_id, cash_balance=float(last.cash_balance), equity_value=equity, unrealized_pnl=unrealized, realized_pnl=float(last.realized_pnl), gross_exposure_pct=(gross/equity*100 if equity else 0), open_positions_count=len(positions), exposure_by_symbol=exposure)
    db.add(snap)
    db.flush()
    audit(db, "portfolio_recalculated", "Portfolio recalculated", user_id=user_id, ref_type="portfolio", ref_id=snap.portfolio_snapshot_id)
    db.commit()
    return {"portfolio_snapshot_id": snap.portfolio_snapshot_id, "cash_balance": float(snap.cash_balance), "equity_value": float(snap.equity_value), "unrealized_pnl": float(snap.unrealized_pnl), "gross_exposure_pct": float(snap.gross_exposure_pct), "open_positions_count": snap.open_positions_count, "exposure_by_symbol": snap.exposure_by_symbol}


def utcnow():
    return datetime.now(timezone.utc)
