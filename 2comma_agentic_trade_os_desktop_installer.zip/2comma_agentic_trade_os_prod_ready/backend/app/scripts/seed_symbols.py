from backend.app.database import SessionLocal, initialize_database
from backend.app.services import seed_symbols

if __name__ == "__main__":
    initialize_database()
    with SessionLocal() as db:
        print(f"Seeded {seed_symbols(db)} symbols")
