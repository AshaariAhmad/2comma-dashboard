from sqlalchemy import select
from backend.app.database import SessionLocal, initialize_database
from backend.app.models import User, UserRiskProfile
from backend.app.security import hash_password
from backend.app.services import recalculate_portfolio
from backend.app.settings import get_settings

if __name__ == "__main__":
    initialize_database()
    settings = get_settings()
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == settings.admin_email.lower()))
        if not user:
            user = User(email=settings.admin_email.lower(), username="admin", password_hash=hash_password(settings.admin_password), role="admin")
            db.add(user)
            db.flush()
            db.add(UserRiskProfile(user_id=user.user_id))
            db.commit()
            recalculate_portfolio(db, user.user_id)
            print(f"Created admin: {settings.admin_email}")
        else:
            user.role = "admin"
            db.commit()
            print(f"Admin already exists and role updated: {settings.admin_email}")
