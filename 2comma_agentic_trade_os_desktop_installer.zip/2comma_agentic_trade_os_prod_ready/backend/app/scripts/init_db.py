from backend.app.database import initialize_database

if __name__ == "__main__":
    initialize_database()
    print("Database initialized.")
