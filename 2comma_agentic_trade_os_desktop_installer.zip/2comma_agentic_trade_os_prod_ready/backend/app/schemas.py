from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    username: str | None = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class MarketRefreshRequest(BaseModel):
    symbols: list[str]
    period: str = "6mo"
    interval: str = "1d"


class SymbolCreate(BaseModel):
    symbol: str
    display_name: str
    asset_class: str
    exchange: str | None = None
    base_currency: str | None = None
    quote_currency: str | None = None
    country: str | None = None


class FeatureRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"


class BacktestRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"
    short: int = 20
    long: int = 50
    fee_bps: float = 5
    slippage_bps: float = 5


class SignalRequest(BaseModel):
    symbol: str
    timeframe: str = "1d"
    short: int = 20
    long: int = 50


class RiskRequest(BaseModel):
    signal_id: str
    requested_position_size: float = Field(gt=0)


class PaperOrderRequest(BaseModel):
    risk_check_id: str
