from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from backend.app.settings import get_settings

settings = get_settings()
engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False, future=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def initialize_database():
    from backend.app.models import Base
    Base.metadata.create_all(bind=engine)
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS timescaledb"))
        # Hypertable creation is best-effort because local PostgreSQL without Timescale may not support it.
        for table, time_col in [
            ("market_ohlcv", "timestamp"),
            ("market_features", "timestamp"),
            ("portfolio_snapshots", "timestamp"),
            ("audit_logs", "timestamp"),
        ]:
            try:
                conn.execute(text(f"SELECT create_hypertable('{table}', '{time_col}', if_not_exists => TRUE)"))
            except Exception:
                pass
