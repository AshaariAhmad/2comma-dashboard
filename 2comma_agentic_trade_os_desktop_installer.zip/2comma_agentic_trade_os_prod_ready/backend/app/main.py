from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models import (
    AuditLog, BacktestRun, MarketOHLCV, MarketSymbol, PaperOrder, PaperPosition,
    RiskCheck, Signal, User, UserRiskProfile
)
from backend.app.schemas import (
    BacktestRequest, FeatureRequest, LoginRequest, MarketRefreshRequest,
    PaperOrderRequest, RegisterRequest, RiskRequest, SignalRequest, SymbolCreate
)
from backend.app.security import admin_user, create_token, current_user, hash_password, verify_password
from backend.app.services import (
    audit, create_paper_order, fetch_deribit_book_summary, fetch_eia, generate_features,
    generate_signal, latest_prices, recalculate_portfolio, refresh_market_data,
    run_ema_backtest, run_risk_check, seed_symbols
)
from backend.app.settings import get_settings

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", debug=settings.debug)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"app": settings.app_name, "mode": "paper_only", "docs": "/docs"}


@app.get(f"{settings.api_prefix}/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok", "mode": "paper_only", "live_trading_enabled": False}


@app.post(f"{settings.api_prefix}/auth/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    exists = db.scalar(select(User).where(User.email == req.email.lower()))
    if exists:
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(email=req.email.lower(), username=req.username, password_hash=hash_password(req.password))
    db.add(user)
    db.flush()
    db.add(UserRiskProfile(user_id=user.user_id))
    db.commit()
    recalculate_portfolio(db, user.user_id)
    token = create_token(user.user_id)
    return {"access_token": token, "token_type": "bearer", "user_id": user.user_id, "email": user.email, "role": user.role}


@app.post(f"{settings.api_prefix}/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == req.email.lower()))
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    audit(db, "user_login", "User logged in", user_id=user.user_id)
    db.commit()
    return {"access_token": create_token(user.user_id), "token_type": "bearer", "user_id": user.user_id, "email": user.email, "role": user.role}


@app.get(f"{settings.api_prefix}/users/me")
def me(user: User = Depends(current_user)):
    return {"user_id": user.user_id, "email": user.email, "username": user.username, "role": user.role, "paper_trading_enabled": user.paper_trading_enabled, "live_trading_enabled": user.live_trading_enabled}


@app.get(f"{settings.api_prefix}/markets/symbols")
def symbols(asset_class: str | None = None, db: Session = Depends(get_db)):
    q = select(MarketSymbol)
    if asset_class:
        q = q.where(MarketSymbol.asset_class == asset_class)
    rows = db.scalars(q.order_by(MarketSymbol.asset_class, MarketSymbol.symbol)).all()
    return [{"symbol_id": s.symbol_id, "symbol": s.symbol, "display_name": s.display_name, "asset_class": s.asset_class, "exchange": s.exchange} for s in rows]


@app.post(f"{settings.api_prefix}/markets/symbols")
def create_symbol(req: SymbolCreate, db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    sym = MarketSymbol(**req.model_dump())
    db.add(sym)
    audit(db, "symbol_created", f"Created symbol {sym.symbol}", user_id=admin.user_id)
    db.commit()
    return {"symbol_id": sym.symbol_id, "symbol": sym.symbol}


@app.post(f"{settings.api_prefix}/markets/seed")
def seed(db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    return {"seeded": seed_symbols(db)}


@app.post(f"{settings.api_prefix}/markets/refresh")
def refresh(req: MarketRefreshRequest, db: Session = Depends(get_db)):
    return {"status": "completed", "results": refresh_market_data(db, req.symbols, req.period, req.interval)}


@app.get(f"{settings.api_prefix}/markets/latest")
def latest(symbols: str | None = None, db: Session = Depends(get_db)):
    symbol_list = [x.strip() for x in symbols.split(",")] if symbols else None
    return latest_prices(db, symbol_list)


@app.get(f"{settings.api_prefix}/markets/ohlcv")
def ohlcv(symbol: str, timeframe: str = "1d", limit: int = 200, db: Session = Depends(get_db)):
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        return []
    rows = db.scalars(select(MarketOHLCV).where(MarketOHLCV.symbol_id == sym.symbol_id, MarketOHLCV.timeframe == timeframe).order_by(MarketOHLCV.timestamp.desc()).limit(limit)).all()
    return [{"timestamp": r.timestamp, "open": float(r.open) if r.open is not None else None, "high": float(r.high) if r.high is not None else None, "low": float(r.low) if r.low is not None else None, "close": float(r.close) if r.close is not None else None, "volume": float(r.volume or 0), "source": r.source} for r in reversed(rows)]


@app.get(f"{settings.api_prefix}/markets/deribit/book-summary/{{currency}}")
def deribit(currency: str, kind: str | None = None, db: Session = Depends(get_db)):
    return fetch_deribit_book_summary(db, currency, kind)


@app.post(f"{settings.api_prefix}/markets/eia/query")
def eia(route: str, params: dict, db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    return fetch_eia(db, route, params)


@app.post(f"{settings.api_prefix}/features/generate")
def features(req: FeatureRequest, db: Session = Depends(get_db)):
    return generate_features(db, req.symbol, req.timeframe)


@app.get(f"{settings.api_prefix}/features/latest")
def latest_feature(symbol: str, timeframe: str = "1d", db: Session = Depends(get_db)):
    sym = db.scalar(select(MarketSymbol).where(MarketSymbol.symbol == symbol))
    if not sym:
        return {}
    from backend.app.models import MarketFeature
    row = db.scalar(select(MarketFeature).where(MarketFeature.symbol_id == sym.symbol_id, MarketFeature.timeframe == timeframe).order_by(MarketFeature.timestamp.desc()).limit(1))
    return {"symbol": symbol, "timestamp": row.timestamp, "features": row.features, "quality_status": row.quality_status} if row else {}


@app.post(f"{settings.api_prefix}/backtests/run-ema")
def backtest(req: BacktestRequest, db: Session = Depends(get_db)):
    return run_ema_backtest(db, req.symbol, req.timeframe, req.short, req.long, req.fee_bps, req.slippage_bps)


@app.get(f"{settings.api_prefix}/backtests")
def backtests(limit: int = 50, db: Session = Depends(get_db)):
    rows = db.scalars(select(BacktestRun).order_by(BacktestRun.created_at.desc()).limit(limit)).all()
    return [{"backtest_run_id": r.backtest_run_id, "symbol_id": r.symbol_id, "timeframe": r.timeframe, "status": r.status, "metrics": r.metrics, "created_at": r.created_at} for r in rows]


@app.post(f"{settings.api_prefix}/signals/generate")
def signal(req: SignalRequest, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return generate_signal(db, user.user_id, req.symbol, req.timeframe, req.short, req.long)


@app.get(f"{settings.api_prefix}/signals")
def signals(limit: int = 50, db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(Signal).where(Signal.user_id == user.user_id).order_by(Signal.timestamp.desc()).limit(limit)).all()
    out = []
    for s in rows:
        sym = db.get(MarketSymbol, s.symbol_id)
        out.append({"signal_id": s.signal_id, "symbol": sym.symbol if sym else s.symbol_id, "direction": s.direction, "confidence": float(s.confidence or 0), "entry_reference_price": float(s.entry_reference_price or 0), "status": s.status, "timestamp": s.timestamp})
    return out


@app.post(f"{settings.api_prefix}/risk/check")
def risk_check(req: RiskRequest, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return run_risk_check(db, user.user_id, req.signal_id, req.requested_position_size)


@app.get(f"{settings.api_prefix}/risk/checks")
def risk_checks(limit: int = 50, db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(RiskCheck).where(RiskCheck.user_id == user.user_id).order_by(RiskCheck.created_at.desc()).limit(limit)).all()
    return [{"risk_check_id": r.risk_check_id, "signal_id": r.signal_id, "decision": r.decision, "approved_position_size": float(r.approved_position_size or 0), "rejection_reasons": r.rejection_reasons, "created_at": r.created_at} for r in rows]


@app.post(f"{settings.api_prefix}/paper/orders")
def paper_order(req: PaperOrderRequest, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return create_paper_order(db, user.user_id, req.risk_check_id)


@app.get(f"{settings.api_prefix}/paper/orders")
def paper_orders(limit: int = 50, db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(PaperOrder).where(PaperOrder.user_id == user.user_id).order_by(PaperOrder.created_at.desc()).limit(limit)).all()
    return [{"paper_order_id": o.paper_order_id, "side": o.side, "quantity": float(o.quantity), "filled_price": float(o.filled_price), "status": o.status, "created_at": o.created_at} for o in rows]


@app.get(f"{settings.api_prefix}/portfolio/summary")
def portfolio(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return recalculate_portfolio(db, user.user_id)


@app.get(f"{settings.api_prefix}/portfolio/positions")
def positions(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(PaperPosition).where(PaperPosition.user_id == user.user_id, PaperPosition.status == "open")).all()
    return [{"paper_position_id": p.paper_position_id, "symbol_id": p.symbol_id, "side": p.position_side, "quantity": float(p.quantity), "avg_entry_price": float(p.avg_entry_price), "unrealized_pnl": float(p.unrealized_pnl), "status": p.status} for p in rows]


@app.get(f"{settings.api_prefix}/audit/me")
def my_audit(limit: int = 100, db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(AuditLog).where(AuditLog.user_id == user.user_id).order_by(AuditLog.timestamp.desc()).limit(limit)).all()
    return [{"timestamp": r.timestamp, "event_type": r.event_type, "severity": r.severity, "message": r.message, "ref_type": r.ref_type, "ref_id": r.ref_id} for r in rows]


@app.get(f"{settings.api_prefix}/admin/audit")
def all_audit(limit: int = 200, db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    rows = db.scalars(select(AuditLog).order_by(AuditLog.timestamp.desc()).limit(limit)).all()
    return [{"timestamp": r.timestamp, "event_type": r.event_type, "severity": r.severity, "user_id": r.user_id, "message": r.message} for r in rows]
