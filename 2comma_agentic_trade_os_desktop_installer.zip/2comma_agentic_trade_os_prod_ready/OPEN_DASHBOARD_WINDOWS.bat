@echo off
start "" "http://localhost:8080"
start "" "http://localhost:8000/docs"
