# 2 Comma Agentic Trade OS — Production-Ready Starter

This is a production-style backend for the 2 Comma Agentic Trade OS with **real API adapters** and **real PostgreSQL/TimescaleDB persistence**.

## Included

| Area | Included |
|---|---|
| FastAPI backend | Yes |
| PostgreSQL / TimescaleDB | Yes |
| SQLAlchemy models | Yes |
| Redis + Celery worker | Yes |
| Real yfinance OHLCV API adapter | Yes |
| Real Deribit public API adapter | Yes |
| EIA API v2 adapter | Yes, requires `EIA_API_KEY` |
| Deterministic risk engine | Yes |
| Paper trading engine | Yes |
| Portfolio snapshots | Yes |
| Audit logs | Yes |
| Minimal frontend | Yes |
| Live trading | Disabled by default |



## Windows desktop install

For Windows desktop testing, use the included installer scripts:

```text
INSTALL_WINDOWS.bat      First install and start everything
START_WINDOWS.bat        Start after installation
STOP_WINDOWS.bat         Stop containers but keep database data
STATUS_WINDOWS.bat       Show status and recent logs
REFRESH_MARKET_DATA_WINDOWS.bat  Pull real market data
RESET_DATABASE_WINDOWS.bat       Delete local database and start fresh
```

Full guide: `README_WINDOWS_DESKTOP_INSTALL.md`


## Safety rule

```text
AI can propose and explain.
AI cannot approve risk.
AI cannot execute live trades.
Risk approval is deterministic code.
Execution is paper only by default.
```

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open:

```text
API docs:  http://localhost:8000/docs
Frontend:  http://localhost:8080
Health:    http://localhost:8000/api/v1/health
```

## Create an admin user

```bash
docker compose exec api python -m backend.app.scripts.create_admin
```

Default admin credentials from `.env.example`:

```text
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=ChangeMe12345!
```

Change them before public deployment.

## Seed symbols

```bash
docker compose exec api python -m backend.app.scripts.seed_symbols
```

## Refresh real market data

```bash
curl -X POST "http://localhost:8000/api/v1/markets/refresh" \
  -H "Content-Type: application/json" \
  -d '{"symbols":["BTC-USD","ETH-USD","CL=F","BZ=F","^KLSE","MYR=X","SGDMYR=X"],"period":"6mo","interval":"1d"}'
```

## Main flow

1. Register/login.
2. Refresh market data.
3. Generate features.
4. Run simple EMA backtest.
5. Generate signal.
6. Run deterministic risk check.
7. Create paper order.
8. View portfolio and audit logs.

## Production hardening still required

This project is a strong production-ready starter, but before using with real users:

- Put it behind HTTPS.
- Use a managed secret manager.
- Use managed PostgreSQL/TimescaleDB backups.
- Add CI/CD.
- Add rate limits.
- Add monitoring and alerting.
- Review market data provider terms.
- Keep live trading disabled unless a separate supervised broker integration is built.
