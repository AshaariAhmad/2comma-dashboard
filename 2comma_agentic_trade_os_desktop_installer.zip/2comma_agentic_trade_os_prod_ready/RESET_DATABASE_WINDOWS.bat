@echo off
setlocal
cd /d "%~dp0"
title Reset 2 Comma Agentic Trade OS Database
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RESET_DATABASE_WINDOWS.ps1"
pause
