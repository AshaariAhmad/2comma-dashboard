@echo off
setlocal
cd /d "%~dp0"
title Stop 2 Comma Agentic Trade OS
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0STOP_WINDOWS.ps1"
pause
