const API = "http://localhost:8000/api/v1";
let token = localStorage.getItem("twocomma_token") || "";

function saveToken(){
  token = document.getElementById("token").value.trim();
  localStorage.setItem("twocomma_token", token);
  loadPortfolio();
}
async function get(path, auth=false){
  const headers = auth && token ? {Authorization:`Bearer ${token}`} : {};
  const r = await fetch(API+path,{headers});
  if(!r.ok) throw new Error(await r.text());
  return r.json();
}
async function loadHealth(){
  try{
    const h = await get("/health");
    document.getElementById("health").textContent = JSON.stringify(h,null,2);
    document.getElementById("status").textContent = `PAPER ONLY | LIVE DISABLED | API ${h.status}`;
  }catch(e){document.getElementById("health").textContent=e.message}
}
async function loadMarkets(){
  try{
    const m = await get("/markets/latest?symbols=BTC-USD,ETH-USD,CL=F,BZ=F,^KLSE,MYR=X,SGDMYR=X");
    document.getElementById("markets").textContent = JSON.stringify(m,null,2);
  }catch(e){document.getElementById("markets").textContent=e.message}
}
async function loadPortfolio(){
  if(!token) return;
  try{
    const p = await get("/portfolio/summary", true);
    document.getElementById("portfolio").textContent = JSON.stringify(p,null,2);
  }catch(e){document.getElementById("portfolio").textContent=e.message}
}
document.getElementById("token").value = token;
loadHealth(); loadMarkets(); loadPortfolio();
setInterval(loadHealth,30000); setInterval(loadMarkets,60000); setInterval(loadPortfolio,60000);
