$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  2 Comma Agentic Trade OS - Windows Desktop Installer" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

function Require-Command($name, $installMessage) {
    if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
        Write-Host "Missing required command: $name" -ForegroundColor Red
        Write-Host $installMessage -ForegroundColor Yellow
        exit 1
    }
}

Require-Command "docker" "Install Docker Desktop first: https://www.docker.com/products/docker-desktop/"

try {
    docker info *> $null
} catch {
    Write-Host "Docker is installed but not running." -ForegroundColor Red
    Write-Host "Open Docker Desktop, wait until it says Docker is running, then run INSTALL_WINDOWS.bat again." -ForegroundColor Yellow
    exit 1
}

try {
    docker compose version *> $null
} catch {
    Write-Host "Docker Compose is not available." -ForegroundColor Red
    Write-Host "Update Docker Desktop, then run INSTALL_WINDOWS.bat again." -ForegroundColor Yellow
    exit 1
}

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    $secret = "twocomma_" + ([guid]::NewGuid().ToString("N")) + ([guid]::NewGuid().ToString("N"))
    (Get-Content ".env") -replace '^JWT_SECRET_KEY=.*', "JWT_SECRET_KEY=$secret" | Set-Content ".env"
    Write-Host "Created .env from .env.example and generated a local JWT secret." -ForegroundColor Green
} else {
    Write-Host ".env already exists. Keeping your existing settings." -ForegroundColor Yellow
}

New-Item -ItemType Directory -Force -Path "data" | Out-Null
New-Item -ItemType Directory -Force -Path "logs" | Out-Null

Write-Host ""
Write-Host "Building and starting Docker containers..." -ForegroundColor Cyan
docker compose up -d --build

Write-Host ""
Write-Host "Waiting for API health check..." -ForegroundColor Cyan
$healthy = $false
for ($i = 1; $i -le 60; $i++) {
    try {
        $res = Invoke-RestMethod -Uri "http://localhost:8000/api/v1/health" -TimeoutSec 2
        if ($res.status -eq "ok") {
            $healthy = $true
            break
        }
    } catch {
        Start-Sleep -Seconds 2
    }
}

if (-not $healthy) {
    Write-Host "API did not become healthy yet." -ForegroundColor Yellow
    Write-Host "Showing container status:" -ForegroundColor Yellow
    docker compose ps
    Write-Host ""
    Write-Host "Try START_WINDOWS.bat after Docker finishes building, or run STATUS_WINDOWS.bat for diagnostics." -ForegroundColor Yellow
    exit 1
}

Write-Host "API is healthy." -ForegroundColor Green

Write-Host ""
Write-Host "Creating/updating admin user..." -ForegroundColor Cyan
docker compose exec -T api python -m backend.app.scripts.create_admin

Write-Host ""
Write-Host "Seeding default market symbols..." -ForegroundColor Cyan
docker compose exec -T api python -m backend.app.scripts.seed_symbols

Write-Host ""
Write-Host "Opening dashboard and API docs..." -ForegroundColor Cyan
Start-Process "http://localhost:8080"
Start-Process "http://localhost:8000/docs"

Write-Host ""
Write-Host "Installation complete." -ForegroundColor Green
Write-Host "Dashboard: http://localhost:8080" -ForegroundColor Green
Write-Host "API docs : http://localhost:8000/docs" -ForegroundColor Green
Write-Host "Health   : http://localhost:8000/api/v1/health" -ForegroundColor Green
Write-Host ""
Write-Host "Default admin from .env.example:" -ForegroundColor Yellow
Write-Host "Email   : admin@example.com"
Write-Host "Password: ChangeMe12345!"
Write-Host "Change these in .env before using beyond local testing." -ForegroundColor Yellow
