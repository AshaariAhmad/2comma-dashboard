$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "WARNING: This will delete the local PostgreSQL and Redis Docker volumes for this project." -ForegroundColor Red
Write-Host "Your paper orders, users, portfolio, audit logs, and market data in the database will be removed." -ForegroundColor Yellow
$confirm = Read-Host "Type RESET to continue"
if ($confirm -ne "RESET") {
    Write-Host "Reset cancelled." -ForegroundColor Green
    exit 0
}
docker compose down -v
Write-Host "Volumes deleted. Rebuilding and starting fresh..." -ForegroundColor Cyan
docker compose up -d --build
Write-Host "Waiting for API..." -ForegroundColor Cyan
Start-Sleep -Seconds 15
docker compose exec -T api python -m backend.app.scripts.create_admin
docker compose exec -T api python -m backend.app.scripts.seed_symbols
Write-Host "Reset complete." -ForegroundColor Green
Start-Process "http://localhost:8080"
