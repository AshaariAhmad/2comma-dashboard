@echo off
setlocal
cd /d "%~dp0"
title Start 2 Comma Agentic Trade OS
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_WINDOWS.ps1"
pause
