@echo off
setlocal
cd /d "%~dp0"
title 2 Comma Agentic Trade OS Installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_WINDOWS.ps1"
pause
