$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
Write-Host "Docker containers:" -ForegroundColor Cyan
docker compose ps
Write-Host ""
Write-Host "API health:" -ForegroundColor Cyan
try {
    Invoke-RestMethod -Uri "http://localhost:8000/api/v1/health" -TimeoutSec 5 | ConvertTo-Json -Depth 5
} catch {
    Write-Host "API health check failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""
Write-Host "Recent API logs:" -ForegroundColor Cyan
docker compose logs --tail=80 api
