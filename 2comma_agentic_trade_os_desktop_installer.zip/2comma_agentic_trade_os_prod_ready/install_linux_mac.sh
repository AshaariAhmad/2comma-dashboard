#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "2 Comma Agentic Trade OS - Linux/Mac installer"
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is missing. Install Docker first."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker is installed but not running. Start Docker and rerun this script."
  exit 1
fi
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET="twocomma_$(python - <<'PY'
import secrets
print(secrets.token_hex(48))
PY
)"
  python - <<PY
from pathlib import Path
p = Path('.env')
s = p.read_text()
s = '\n'.join(('JWT_SECRET_KEY=' + '$SECRET') if line.startswith('JWT_SECRET_KEY=') else line for line in s.splitlines()) + '\n'
p.write_text(s)
PY
  echo "Created .env and generated a local JWT secret."
fi
mkdir -p data logs
docker compose up -d --build
echo "Waiting for API..."
for i in {1..60}; do
  if curl -fsS http://localhost:8000/api/v1/health >/dev/null 2>&1; then break; fi
  sleep 2
done
docker compose exec -T api python -m backend.app.scripts.create_admin
docker compose exec -T api python -m backend.app.scripts.seed_symbols
echo "Dashboard: http://localhost:8080"
echo "API docs : http://localhost:8000/docs"
