@echo off
setlocal
cd /d "%~dp0"
title Status 2 Comma Agentic Trade OS
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0STATUS_WINDOWS.ps1"
pause
