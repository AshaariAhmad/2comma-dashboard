# JL Collapse — Crude Oil Strategy (v3, unified dashboard)

> Real EIA data. Six leakage fixes. **One dashboard. One command.**

[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/streamlit-app-ff4b4b)](https://streamlit.io/)
[![Leakage tests](https://img.shields.io/badge/leakage_test-passing-green)](#diagnostics)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)

A Johnson–Lindenstrauss random-projection trading pipeline on **real EIA crude-oil data**, with leakage fully audited and every operation behind a single dashboard entry point.

---

## One command, six tabs

```bash
streamlit run dashboard.py
```

| Tab | Does |
|---|---|
| 🏠 **Home** | System status · latest run KPIs · Sharpe trend across runs |
| 🔬 **Diagnostics** | Run all 3 leakage / loader tests in ~15 s · live progress · pass/fail history |
| 📡 **EIA Data** | Inspect cached panel · refresh from EIA · browse columns · view catalogue |
| ▶ **Run Strategy** | Full 7-step pipeline + walk-forward backtest · single-button trigger |
| 📊 **History** | SQLite-backed log of every run · Sharpe trend chart · table view |
| 📚 **About** | Methodology · audit fixes · references |

No more juggling four scripts. No more remembering which test does what. One process, sidebar nav, persistent state.

---

## Quick start

```bash
git clone https://github.com/<you>/crude-oil-jl-pipeline.git
cd crude-oil-jl-pipeline
pip install -r requirements.txt

# Get a free EIA API key: https://www.eia.gov/opendata/register.php
export EIA_API_KEY=your_key_here

streamlit run dashboard.py
```

Open the URL Streamlit prints (typically <http://localhost:8501>). On first launch:

1. **🔬 Diagnostics** — press **▶ Run all diagnostics**. Confirms the engine is honest. ~15 s.
2. **📡 EIA Data** — press **↻ Refresh from EIA**. Pulls ~12 series, caches them. ~1–2 min.
3. **▶ Run Strategy** — press **▶ Run Full Pipeline**. The cache is reused; backtest runs in seconds.
4. **📊 History** — see your run added to the running record.

Everything persists to `runs.db` (SQLite, auto-created) and `eia_cache.parquet` (or `.pkl` if pyarrow isn't installed). Both are gitignored.

---

## What the dashboard wraps

The dashboard is a thin UI layer over four small modules:

```
dashboard.py        ← single entry point (Streamlit)
├── pipeline.py     — 7-step pipeline + JL collapse + walk-forward + EIA loader
├── diagnostics.py  — in-process versions of the 3 tests
└── history.py      — SQLite-backed run-log persistence
```

Each module is independently usable:

```python
# Just the pipeline
from pipeline import run_full_pipeline, BacktestConfig
out = run_full_pipeline(api_key="...", cfg=BacktestConfig())

# Just the diagnostics
from diagnostics import run_all_tests
results = run_all_tests(progress_cb=lambda *a: None)

# Just the history
from history import list_runs
runs_df = list_runs()
```

The standalone `app.py` (single-purpose runner) and `test_*.py` files are still in the repo as reference, but the dashboard is the primary entry point.

---

## Audit fixes (v1 → v2 → v3)

v1 of this engine passed an external leakage audit that flagged six issues. Every one is fixed and tested.

| Audit issue | v1 | v2/v3 |
|---|---|---|
| **A. Profit ranking peeks at test returns** | `pnl = sign(s) * ret` (no shift) | `rolling_profit_rank_no_leak` — `.shift(1)` on signal AND on rolling sum |
| **B. Winsorize uses full-sample quantiles** | `clean_panel()` global | `FoldCleaner` — fits per fold |
| **C. MAD z-score uses current bar** | `(s - rolling.median(s))` | `s.shift(1).rolling(...)` past-only window |
| **D. ATR stop reads current bar** | `atr.loc[t]` | `atr.shift(1)` |
| **E. Vol sizing reads current bar** | `ret.loc[:t]` | `ret.shift(1).rolling(50)` |
| **F. Trade direction at t = sign(signal at t)** | `sign(Z[t, ci])` | `sign(Z[t-1, ci])` |
| **G. Synthetic data baked in** | `generate_eia_panel` default | Removed — EIA only |

---

## Diagnostics

The Diagnostics tab runs three regression tests in-process:

```
                            Hit rate    Sharpe   Verdict
v1 (leaky control)          58.40%      +3.43    ❌ inflated alpha from leak
v2/v3 (audit fixes applied) 49.98%      +0.40    ✅ no edge on noise
```

- **Leakage** — pure-noise input, expect ≈ 50% hit rate / Sharpe ≈ 0
- **Negative control** — re-introduces v1 leak, must be caught
- **EIA loader** — mocked HTTP, verifies pagination/parsing/caching/end-to-end

Results are persisted to `runs.db` and surfaced in the sidebar as PASS/FAIL pills.

---

## Reading the numbers

After all six fixes, on real EIA data, expect:

| Metric | Realistic | Red flag |
|---|---|---|
| Annualized Sharpe | 0.4 – 1.5 | > 3 |
| Hit rate | 51 – 55% | > 60% |
| Profit factor | 1.0 – 1.5 | > 2.5 |

If anything tips into the red-flag range, run the Diagnostics tab — `test_leakage.py` is your trip-wire.

---

## Project layout

```
crude-oil-jl-pipeline/
├── dashboard.py                    # ★ Single entry point (Streamlit, 6 tabs)
├── pipeline.py                     # 7-step + JL + walk-forward + EIA loader
├── diagnostics.py                  # In-process test runners
├── history.py                      # SQLite-backed run history
├── app.py                          # Legacy single-purpose runner (still works)
├── test_leakage.py                 # CLI version of the leakage test
├── test_negative_control.py        # CLI version of the negative-control test
├── test_eia_loader.py              # CLI version of the loader test
├── crude_oil_jl_pipeline.ipynb     # Original annotated notebook (v1)
├── requirements.txt
├── README.md
├── LICENSE                         # MIT
├── .gitignore                      # Excludes runs.db, eia_cache.*, outputs
└── .streamlit/config.toml          # Dark amber theme
```

---

## Data sources

All series pulled from the [EIA v2 API](https://www.eia.gov/opendata/):

| Column | Frequency | EIA series ID |
|---|---|---|
| WTI · BRENT | daily | RWTC · RBRTE |
| HH (Henry Hub) | daily | RNGWHHD |
| CRUDE / GASOLINE / DISTILLATE / CUSHING / SPR stocks | weekly | WCESTUS1, WGTSTUS1, WDISTUS1, W_EPC0_SAX_YCUOK_MBBL, WCSSTUS1 |
| REF_UTIL · REF_RUNS | weekly | WPULEUS3 · WCRRIUS2 |
| GASOLINE_DEMAND · DISTILLATE_DEMAND | weekly | WGFUPUS2 · WDIUPUS2 |

To extend the catalogue: add `(column, route, series_id)` entries to `EIA_SERIES` in `pipeline.py`. Series browser: <https://www.eia.gov/opendata/browser/>

---

## License

MIT — see [LICENSE](LICENSE).

## References

- Johnson, W.B. and Lindenstrauss, J. (1984). *Extensions of Lipschitz mappings into a Hilbert space.*
- EIA Open Data v2 API · <https://www.eia.gov/opendata/>
