"""Test that the hardened EIA loader handles real-world failure modes correctly.

These tests exercise the error paths that only matter when hitting the live API:
- Bad API key → clear error message, no retry storm
- HTTP 429 rate limit → backoff and retry
- HTTP 5xx transient → backoff and retry
- Malformed JSON → useful error, not silent empty
- Missing series → fault-tolerant (other series still load)
- Network timeout → retry with backoff

Together with test_eia_loader.py (which exercises the happy path), this
catches the bugs you'd otherwise discover only by burning your API quota.
"""
import sys, time
sys.path.insert(0, ".")

from unittest.mock import patch, MagicMock
import requests

import pipeline as P


def make_response(status_code=200, json_body=None, text="", headers=None):
    r = MagicMock()
    r.status_code = status_code
    r.text = text or (str(json_body) if json_body else "")
    r.headers = headers or {}
    r.url = "https://api.eia.gov/v2/test"
    if json_body is not None:
        r.json.return_value = json_body
    else:
        r.json.side_effect = ValueError("no json")
    return r


def make_eia_ok(n_rows=10):
    import pandas as pd
    rows = [
        {"period": str(pd.Timestamp("2024-01-01").date() + pd.Timedelta(days=i)),
         "value": str(50.0 + i * 0.1)}
        for i in range(n_rows)
    ]
    return {"response": {"data": rows}}


# ─────────────────── Test: bad API key (HTTP 403) ───────────────────
def test_bad_api_key():
    print("TEST: bad API key → EIAError with clear message")
    def fake_get(url, params=None, timeout=None):
        return make_response(status_code=403, text="Forbidden")
    with patch("requests.get", side_effect=fake_get):
        try:
            P.fetch_eia_series("bad_key", "petroleum/pri/spt/data/", "RWTC")
            print("  ❌ FAIL — should have raised EIAError")
            return False
        except P.EIAError as e:
            if "rejected key" in str(e) or "403" in str(e):
                print(f"  ✅ PASS — raised: {str(e)[:80]}")
                return True
            print(f"  ❌ FAIL — wrong error: {e}")
            return False


# ─────────────────── Test: rate limit (429) → retry ───────────────────
def test_rate_limit_retry():
    print("TEST: HTTP 429 → backoff + retry, eventually succeeds")
    call_log = []
    def fake_get(url, params=None, timeout=None):
        call_log.append(time.time())
        if len(call_log) < 3:
            return make_response(status_code=429, headers={"Retry-After": "0.05"})
        return make_response(status_code=200, json_body=make_eia_ok())
    with patch("requests.get", side_effect=fake_get):
        try:
            s = P.fetch_eia_series("k", "r", "SID", max_retries=5, rate_limit_sleep=0.0)
            n_calls = len(call_log)
            if n_calls >= 3 and len(s) == 10:
                print(f"  ✅ PASS — retried {n_calls - 1}x, got {len(s)} rows")
                return True
            print(f"  ❌ FAIL — calls={n_calls}, rows={len(s)}")
            return False
        except Exception as e:
            print(f"  ❌ FAIL — unexpected exception: {e}")
            return False


# ─────────────────── Test: 5xx server error → retry ───────────────────
def test_server_error_retry():
    print("TEST: HTTP 503 → backoff + retry, eventually succeeds")
    call_log = []
    def fake_get(url, params=None, timeout=None):
        call_log.append(1)
        if len(call_log) < 2:
            return make_response(status_code=503, text="upstream down")
        return make_response(status_code=200, json_body=make_eia_ok(5))
    with patch("requests.get", side_effect=fake_get):
        s = P.fetch_eia_series("k", "r", "SID", max_retries=4, rate_limit_sleep=0.0)
        if len(call_log) >= 2 and len(s) == 5:
            print(f"  ✅ PASS — retried {len(call_log) - 1}x, got {len(s)} rows")
            return True
        print(f"  ❌ FAIL — calls={len(call_log)}, rows={len(s)}")
        return False


# ─────────────────── Test: retries exhausted → EIAError ───────────────────
def test_retries_exhausted():
    print("TEST: persistent 5xx → EIAError after max_retries")
    def fake_get(url, params=None, timeout=None):
        return make_response(status_code=503, text="upstream down")
    with patch("requests.get", side_effect=fake_get):
        try:
            P.fetch_eia_series("k", "r", "SID", max_retries=2, rate_limit_sleep=0.0)
            print("  ❌ FAIL — should have raised")
            return False
        except P.EIAError as e:
            if "retries" in str(e).lower() or "503" in str(e):
                print(f"  ✅ PASS — raised after retries: {str(e)[:80]}")
                return True
            print(f"  ❌ FAIL — wrong error: {e}")
            return False


# ─────────────────── Test: malformed JSON → EIAError ───────────────────
def test_malformed_json():
    print("TEST: non-JSON response → EIAError with helpful message")
    def fake_get(url, params=None, timeout=None):
        return make_response(status_code=200, json_body=None, text="<html>oops</html>")
    with patch("requests.get", side_effect=fake_get):
        try:
            P.fetch_eia_series("k", "r", "SID", max_retries=1, rate_limit_sleep=0.0)
            print("  ❌ FAIL — should have raised")
            return False
        except P.EIAError as e:
            if "non-JSON" in str(e) or "JSON" in str(e):
                print(f"  ✅ PASS — raised: {str(e)[:80]}")
                return True
            print(f"  ❌ FAIL — wrong error: {e}")
            return False


# ─────────────────── Test: EIA error payload → EIAError ───────────────────
def test_eia_error_payload():
    print("TEST: EIA error JSON → EIAError with API's own message")
    def fake_get(url, params=None, timeout=None):
        return make_response(
            status_code=200,
            json_body={"error": "Unknown series ID: GARBAGE"},
        )
    with patch("requests.get", side_effect=fake_get):
        try:
            P.fetch_eia_series("k", "r", "GARBAGE", max_retries=1, rate_limit_sleep=0.0)
            print("  ❌ FAIL — should have raised")
            return False
        except P.EIAError as e:
            if "Unknown series" in str(e):
                print(f"  ✅ PASS — propagated API message: {str(e)[:80]}")
                return True
            print(f"  ❌ FAIL — wrong error: {e}")
            return False


# ─────────────────── Test: panel loader is fault-tolerant ───────────────────
def test_panel_fault_tolerant():
    print("TEST: load_eia_panel continues when one series fails")
    import os
    cache = "/tmp/test_fault_tolerant_cache.parquet"
    for ext in (".parquet", ".pkl"):
        p = cache.replace(".parquet", ext)
        if os.path.exists(p): os.unlink(p)

    call_log = {"n": 0}
    def fake_get(url, params=None, timeout=None):
        sid = params.get("facets[series][]") if params else ""
        call_log["n"] += 1
        # Make CUSHING_STOCKS series fail with a clear EIA error
        if sid == "W_EPC0_SAX_YCUOK_MBBL":
            return make_response(status_code=200,
                                 json_body={"error": f"Series temporarily unavailable: {sid}"})
        return make_response(status_code=200, json_body=make_eia_ok(20))

    with patch("requests.get", side_effect=fake_get):
        df = P.load_eia_panel("valid_api_key_long_enough", cache_path=cache, refresh=True)

    # The bad series should be missing, but the rest should be there
    failed = df.attrs.get("failed_series", {})
    if "CUSHING_STOCKS" in failed and "WTI" in df.columns and len(df) > 0:
        print(f"  ✅ PASS — {df.shape[1]}/{len(P.EIA_SERIES)} series loaded, "
              f"failed: {list(failed.keys())}")
        ok = True
    else:
        print(f"  ❌ FAIL — failed={failed}, cols={list(df.columns)}")
        ok = False

    for ext in (".parquet", ".pkl"):
        p = cache.replace(".parquet", ext)
        if os.path.exists(p): os.unlink(p)
    return ok


# ─────────────────── Test: empty key rejected upfront ───────────────────
def test_empty_key():
    print("TEST: empty/short API key → EIAError before any HTTP call")
    call_log = {"n": 0}
    def fake_get(*a, **kw):
        call_log["n"] += 1
        return make_response()
    with patch("requests.get", side_effect=fake_get):
        try:
            P.load_eia_panel("", cache_path="/tmp/_x", refresh=True)
            print("  ❌ FAIL — should have raised")
            return False
        except P.EIAError as e:
            if call_log["n"] == 0 and ("Empty" in str(e) or "implausible" in str(e)):
                print(f"  ✅ PASS — rejected without HTTP call: {str(e)[:80]}")
                return True
            print(f"  ❌ FAIL — calls={call_log['n']}, err={e}")
            return False


# ─────────────────── Test: network exception → retry ───────────────────
def test_network_timeout_retry():
    print("TEST: network timeout → retry, succeed on second attempt")
    call_log = []
    def fake_get(url, params=None, timeout=None):
        call_log.append(1)
        if len(call_log) < 2:
            raise requests.exceptions.Timeout("simulated timeout")
        return make_response(status_code=200, json_body=make_eia_ok(3))
    with patch("requests.get", side_effect=fake_get):
        s = P.fetch_eia_series("k", "r", "SID", max_retries=3, rate_limit_sleep=0.0)
        if len(call_log) == 2 and len(s) == 3:
            print(f"  ✅ PASS — recovered from timeout, got {len(s)} rows")
            return True
        print(f"  ❌ FAIL — calls={len(call_log)}, rows={len(s)}")
        return False


# ─────────────────── Run all ───────────────────
if __name__ == "__main__":
    print("=" * 70)
    print("  REAL-API LOADER STRESS TESTS (mocked failure modes)")
    print("=" * 70)
    print()
    tests = [
        test_bad_api_key,
        test_rate_limit_retry,
        test_server_error_retry,
        test_retries_exhausted,
        test_malformed_json,
        test_eia_error_payload,
        test_panel_fault_tolerant,
        test_empty_key,
        test_network_timeout_retry,
    ]
    results = [t() for t in tests]
    n_pass = sum(results)
    print()
    print("=" * 70)
    print(f"  {n_pass}/{len(results)} PASSED")
    print("=" * 70)
    if n_pass < len(results):
        sys.exit(1)
