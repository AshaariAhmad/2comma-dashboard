"""Run-history persistence layer for the dashboard.

Stores every completed pipeline run in a tiny SQLite DB so the History tab
can show progress across sessions. No external deps — sqlite3 ships with Python.
"""
from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

import pandas as pd


DEFAULT_DB = "runs.db"


@contextmanager
def _connect(db_path: str = DEFAULT_DB):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(db_path: str = DEFAULT_DB) -> None:
    """Create the runs table if it doesn't exist."""
    with _connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS runs (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                ts              REAL    NOT NULL,
                duration_sec    REAL    NOT NULL,
                eia_rows        INTEGER NOT NULL,
                eia_start       TEXT,
                eia_end         TEXT,
                indicator_rows  INTEGER NOT NULL,
                cumulative_pct  REAL,
                profit_factor   REAL,
                hit_rate_pct    REAL,
                max_drawdown    REAL,
                sharpe          REAL,
                n_trades        INTEGER,
                n_folds         INTEGER,
                config_json     TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS test_runs (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                ts              REAL    NOT NULL,
                test_name       TEXT    NOT NULL,
                passed          INTEGER NOT NULL,
                duration_sec    REAL    NOT NULL,
                output          TEXT
            )
            """
        )


def record_run(out: dict, duration_sec: float, db_path: str = DEFAULT_DB) -> int:
    """Persist a single pipeline-run result. Returns the inserted row id."""
    init_db(db_path)
    m = out["metrics"]
    cfg = out["config"]
    cfg_dict = {k: getattr(cfg, k) for k in cfg.__dataclass_fields__}
    with _connect(db_path) as conn:
        cur = conn.execute(
            """
            INSERT INTO runs (
                ts, duration_sec, eia_rows, eia_start, eia_end,
                indicator_rows, cumulative_pct, profit_factor,
                hit_rate_pct, max_drawdown, sharpe, n_trades, n_folds,
                config_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                time.time(), float(duration_sec),
                int(out.get("eia_rows", 0)),
                str(out.get("eia_start", "")),
                str(out.get("eia_end", "")),
                int(len(out["indicators"])),
                float(m.get("cumulative_return_pct", 0.0)),
                float(m.get("profit_factor", 0.0)),
                float(m.get("hit_rate_pct", 0.0)),
                float(m.get("max_drawdown_pct", 0.0)),
                float(m.get("sharpe_annualized", 0.0)),
                int(m.get("n_trades", 0)),
                int(m.get("n_folds", 0)),
                json.dumps(cfg_dict),
            ),
        )
        return cur.lastrowid


def record_test(test_name: str, passed: bool, duration_sec: float,
                output: str = "", db_path: str = DEFAULT_DB) -> int:
    init_db(db_path)
    with _connect(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO test_runs (ts, test_name, passed, duration_sec, output) VALUES (?, ?, ?, ?, ?)",
            (time.time(), test_name, int(bool(passed)), float(duration_sec), output[:8000]),
        )
        return cur.lastrowid


def list_runs(db_path: str = DEFAULT_DB, limit: int = 100) -> pd.DataFrame:
    if not Path(db_path).exists():
        return pd.DataFrame()
    with _connect(db_path) as conn:
        df = pd.read_sql_query(
            "SELECT * FROM runs ORDER BY ts DESC LIMIT ?", conn, params=(limit,)
        )
    if len(df):
        df["ts"] = pd.to_datetime(df["ts"], unit="s")
    return df


def list_test_runs(db_path: str = DEFAULT_DB, limit: int = 100) -> pd.DataFrame:
    if not Path(db_path).exists():
        return pd.DataFrame()
    with _connect(db_path) as conn:
        df = pd.read_sql_query(
            "SELECT * FROM test_runs ORDER BY ts DESC LIMIT ?", conn, params=(limit,)
        )
    if len(df):
        df["ts"] = pd.to_datetime(df["ts"], unit="s")
    return df


def latest_test_status(db_path: str = DEFAULT_DB) -> dict:
    """Return {test_name: {passed, ts}} for each test's latest run."""
    if not Path(db_path).exists():
        return {}
    with _connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT t.test_name, t.passed, t.ts
              FROM test_runs t
              JOIN (
                  SELECT test_name, MAX(ts) AS max_ts
                    FROM test_runs GROUP BY test_name
              ) latest ON t.test_name = latest.test_name AND t.ts = latest.max_ts
            """
        ).fetchall()
    return {r["test_name"]: {"passed": bool(r["passed"]), "ts": r["ts"]} for r in rows}


def clear_runs(db_path: str = DEFAULT_DB) -> int:
    if not Path(db_path).exists(): return 0
    with _connect(db_path) as conn:
        n = conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
        conn.execute("DELETE FROM runs")
        return n
