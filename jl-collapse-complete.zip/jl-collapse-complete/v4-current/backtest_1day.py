"""1-day timeframe backtest of the JL Collapse pipeline.

Generates a daily-cadence panel shaped like real EIA series (random-walk WTI,
OU-process inventories, mean-reverting macro), runs the audited pipeline,
and reports full accuracy metrics.

Important caveat: my sandbox cannot reach api.eia.gov, so this uses
statistically-realistic synthetic daily data instead of live EIA pulls.
On your machine, swap in `pipeline.load_eia_panel(api_key)` for real data —
the rest of the pipeline is unchanged.
"""
import sys, time
sys.path.insert(0, ".")

import numpy as np
import pandas as pd
import pipeline as P


# ───────────────────────── Generate realistic daily panel ─────────────────────────
def make_daily_panel(n_days: int = 6500, seed: int = 7) -> pd.DataFrame:
    """~25 years of business days. Shapes match real EIA series."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2000-01-03", periods=n_days)

    # Latent regime (slow AR(1))
    regime = np.zeros(n_days)
    for t in range(1, n_days):
        regime[t] = 0.998 * regime[t-1] + rng.normal(0, 0.04)

    # WTI as log-OU price — realistic daily diffusion
    log_wti = np.zeros(n_days); log_wti[0] = np.log(50.0)
    kappa, sigma = 0.0015, 0.022   # ~2.2% daily vol — typical for crude
    for t in range(1, n_days):
        center = np.log(60.0) + 0.15 * regime[t]
        log_wti[t] = log_wti[t-1] + kappa * (center - log_wti[t-1]) + sigma * rng.normal()
    # Inject ~0.5% jump events (OPEC, war, COVID)
    jumps = rng.random(n_days) < 0.005
    log_wti[jumps] += rng.normal(0, 0.06, jumps.sum())
    wti = np.exp(log_wti)

    brent = wti + 2.5 + 1.0 * regime + rng.normal(0, 0.8, n_days)

    # OU inventories around realistic levels
    def stock(level, vol, drift_coef):
        s = np.zeros(n_days); s[0] = level
        for t in range(1, n_days):
            s[t] = s[t-1] + 0.005 * (level - s[t-1]) + rng.normal(0, vol) \
                   - drift_coef * (regime[t] - regime[t-1])
        return s

    cols = {
        "WTI": wti, "BRENT": brent,
        "CRUDE_STOCKS":      stock(450_000, 1500,  8000),
        "GASOLINE_STOCKS":   stock(230_000,  900,  4000),
        "DISTILLATE_STOCKS": stock(130_000,  700,  3500),
        "CUSHING_STOCKS":    stock( 35_000,  400,  1200),
        "SPR":               stock(600_000,  200,   500),
    }
    # Refinery/demand
    for name, base, vol, drift in [
        ("REF_UTIL",          88,    1.5, -2.0),
        ("REF_RUNS",       16500,  200, -800),
        ("GASOLINE_DEMAND", 9200,  150, -400),
        ("DISTILLATE_DEMAND",4100, 100, -250),
    ]:
        s = np.zeros(n_days); s[0] = base
        for t in range(1, n_days):
            s[t] = s[t-1] + 0.01 * (base - s[t-1]) + rng.normal(0, vol) \
                   - drift * (regime[t] - regime[t-1]) * 0.01
        cols[name] = s
    # Natural gas (log-OU)
    log_hh = np.zeros(n_days); log_hh[0] = np.log(3.0)
    for t in range(1, n_days):
        log_hh[t] = log_hh[t-1] + 0.002 * (np.log(3.5) - log_hh[t-1]) + 0.025 * rng.normal()
    cols["HH"] = np.exp(log_hh)
    return pd.DataFrame(cols, index=idx)


# ───────────────────────── Run the pipeline ─────────────────────────
print("=" * 72)
print("  JL COLLAPSE — 1-DAY TIMEFRAME BACKTEST")
print("=" * 72)
print()

t_total = time.time()
print("[1/4] Generating ~25 years of daily EIA-shaped panel...")
raw = make_daily_panel(n_days=6500, seed=7)
print(f"      Panel: {raw.shape[0]:,} business days × {raw.shape[1]} columns")
print(f"      Date range: {raw.index[0].date()} → {raw.index[-1].date()}")
print(f"      WTI: ${raw['WTI'].min():.2f} → ${raw['WTI'].max():.2f}  "
      f"(mean ${raw['WTI'].mean():.2f}, daily σ {raw['WTI'].pct_change().std()*100:.2f}%)")
print()

print("[2/4] Cleaning + MAD z-scores + indicator generation...")
clean = P.basic_clean(raw)
mz = P.mad_zscore_panel(clean).dropna()
indicators = P.build_indicators(clean, mz)
print(f"      Indicator panel: {indicators.shape[0]:,} rows × {indicators.shape[1]} features")
print()

print("[3/4] Walk-forward backtest (1-day bars, 2-year train / 6-month test)...")
cfg = P.BacktestConfig(
    train_size=500,       # ~2 years of business days
    test_size=125,        # ~6 months
    k_jl=16,
    profit_window=20,     # 20-day = ~1-month rolling profit window
    shape_window=30,      # 30-day shape window
    target_vol=0.01,      # 1% daily vol target
    max_leverage=1.0,
    atr_stop_mult=1.0,
    daily_loss_limit=-0.03,
    cost_bps=2.0,         # 2 bps realistic for daily liquid futures
)
t0 = time.time()
results, metrics = P.walk_forward_backtest(indicators, clean, cfg)
print(f"      Done in {time.time()-t0:.1f}s")
print()

# ───────────────────────── Detailed accuracy analysis ─────────────────────────
print("[4/4] Detailed accuracy analysis")
print()

traded = results[results["fold"] >= 0].copy()
# True forward returns for each traded bar
traded_ret = traded["ret"]

# Predicted direction
pred_dir = np.sign(traded["pos"])
# Actual direction
actual_dir = np.sign(traded_ret)

# Active trades only (non-zero position)
active = traded[traded["pos"].abs() > 1e-9].copy()
active_pred = np.sign(active["pos"])
active_actual = np.sign(active["ret"])

# Confusion-matrix-style metrics
tp = int(((active_pred ==  1) & (active_actual ==  1)).sum())  # long & up
tn = int(((active_pred == -1) & (active_actual == -1)).sum())  # short & down
fp = int(((active_pred ==  1) & (active_actual == -1)).sum())  # long & down
fn = int(((active_pred == -1) & (active_actual ==  1)).sum())  # short & up
neutral_when_moved = int(((active_pred == 0) & (active_actual != 0)).sum())

n_active = len(active)
hits = tp + tn
misses = fp + fn

print("  ┌─────────────── Confusion matrix (direction call) ───────────────┐")
print(f"  │                          Actual UP     Actual DOWN              │")
print(f"  │  Predicted LONG       {tp:>7,}         {fp:>7,}    →  precision long: {tp/max(tp+fp,1)*100:5.2f}% │")
print(f"  │  Predicted SHORT      {fn:>7,}         {tn:>7,}    →  precision short:{tn/max(tn+fn,1)*100:5.2f}% │")
print(f"  │                          ↓                ↓                       │")
print(f"  │             recall up: {tp/max(tp+fn,1)*100:5.2f}%   recall down: {tn/max(tn+fp,1)*100:5.2f}%                │")
print("  └────────────────────────────────────────────────────────────────┘")
print()

accuracy = hits / max(n_active, 1) * 100
print(f"  Direction accuracy (hit rate): {accuracy:.2f}%   ({hits:,}/{n_active:,} active bars)")
print(f"  ◦ Edge over coin-flip:         {accuracy - 50:+.2f} pp")
print(f"  ◦ Long bars:  {(active_pred==1).sum():,} ({(active_pred==1).mean()*100:.1f}%)")
print(f"  ◦ Short bars: {(active_pred==-1).sum():,} ({(active_pred==-1).mean()*100:.1f}%)")
print()

# Per-fold accuracy (consistency check)
print("  Per-fold accuracy (consistency check):")
print("  fold │  bars  │  active  │  hits  │  acc    │  pnl     │  vol-adj")
print("  ─────┼────────┼──────────┼────────┼─────────┼──────────┼─────────")
for fold_id in sorted(traded["fold"].unique()):
    f = traded[traded["fold"] == fold_id]
    fa = f[f["pos"].abs() > 1e-9]
    fa_hits = ((np.sign(fa["pos"]) == np.sign(fa["ret"])) & (fa["ret"] != 0)).sum()
    facc = fa_hits / max(len(fa), 1) * 100
    fp_pnl = f["pnl"].sum()
    fp_sharpe = f["pnl"].mean() / (f["pnl"].std() + 1e-9) * np.sqrt(252)
    print(f"  {fold_id:>4} │ {len(f):>6,} │ {len(fa):>8,} │ {fa_hits:>6,} │ {facc:>6.2f}% │ {fp_pnl:+7.4f} │ {fp_sharpe:+6.2f}")
print()

# Distribution of returns
wins = traded["pnl"][traded["pnl"] > 0]
losses = traded["pnl"][traded["pnl"] < 0]
print(f"  Win/loss profile:")
print(f"  ◦ Mean win:    {wins.mean()*100:+.3f}%   (n={len(wins):,})")
print(f"  ◦ Mean loss:   {losses.mean()*100:+.3f}%  (n={len(losses):,})")
print(f"  ◦ Win/loss ratio: {abs(wins.mean()/losses.mean()):.2f}")
print()

# By shape class
by_shape = (traded[traded["shape"].isin(["convex", "bell", "flat"])]
            .groupby("shape").agg(
                bars=("pnl", "count"),
                pnl_sum=("pnl", "sum"),
                hit_rate=("pnl", lambda x: (x > 0).mean() * 100),
                mean_pnl=("pnl", "mean")))
print("  Performance by shape class (Step 6 classification):")
print(by_shape.round(4))
print()

# Top-line metrics
print("  ┌─────────────── Headline metrics ───────────────┐")
print(f"  │  Cumulative return     {metrics['cumulative_return_pct']:+10.2f}%        │")
print(f"  │  Annualized Sharpe     {metrics['sharpe_annualized']:+10.2f}         │")
print(f"  │  Profit factor         {metrics['profit_factor']:10.2f}         │")
print(f"  │  Hit rate              {metrics['hit_rate_pct']:10.2f}%        │")
print(f"  │  Max drawdown          {metrics['max_drawdown_pct']:10.2f}%        │")
print(f"  │  Total trades          {metrics['n_trades']:>10,}         │")
print(f"  │  Walk-forward folds    {metrics['n_folds']:>10,}         │")
print(f"  │  Test bars             {metrics['n_traded_bars']:>10,}         │")
print("  └───────────────────────────────────────────────────┘")
print()
print(f"Total wall time: {time.time()-t_total:.1f}s")
