"""Smoke-test the EIA loader using a mocked requests.get.

The actual EIA API is not reachable from CI environments without a key,
but the loader's pagination, parsing, alignment, and caching logic can be
fully verified offline by stubbing the requests layer.
"""
import sys, os, json
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, "/home/claude/repo2")
import pipeline as P


def make_fake_eia_response(series_id, n_rows=300, freq="daily"):
    """Construct a response shaped like real EIA v2 JSON."""
    import pandas as pd
    if freq == "daily":
        idx = pd.bdate_range("2020-01-01", periods=n_rows)
    else:
        idx = pd.date_range("2020-01-03", periods=n_rows, freq="W-FRI")
    rows = [{"period": str(d.date()), "value": str(50.0 + i * 0.05)}
            for i, d in enumerate(idx)]
    return {"response": {"data": rows}}


def fake_requests_get(url, params=None, timeout=None):
    """Return a single page; pagination terminates because len < page."""
    sid = params.get("facets[series][]")
    freq = params.get("frequency", "daily")
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = make_fake_eia_response(sid, n_rows=300, freq=freq)
    resp.raise_for_status = MagicMock()
    return resp


# ─── Test 1: fetch_eia_series pagination + parsing ───
print("=" * 60)
print("TEST 1: fetch_eia_series")
print("=" * 60)
with patch("requests.get", side_effect=fake_requests_get):
    s = P.fetch_eia_series("FAKE_KEY", "petroleum/pri/spt/data/", "RWTC", "daily")
print(f"  Fetched {len(s)} rows, first value: {s.iloc[0]:.2f}")
assert len(s) == 300, f"expected 300, got {len(s)}"
assert s.is_monotonic_increasing or s.index.is_monotonic_increasing
print("  ✅ PASS — fetch_eia_series parses and indexes correctly")
print()

# ─── Test 2: load_eia_panel assembles all series ───
print("=" * 60)
print("TEST 2: load_eia_panel assembly")
print("=" * 60)
cache_path = "/tmp/test_eia_cache.parquet"
if os.path.exists(cache_path): os.unlink(cache_path)
with patch("requests.get", side_effect=fake_requests_get):
    df = P.load_eia_panel("FAKE_KEY", cache_path=cache_path, refresh=True)
print(f"  Panel shape: {df.shape}")
print(f"  Columns: {list(df.columns)}")
print(f"  Index range: {df.index[0].date()} → {df.index[-1].date()}")
assert set(df.columns) == set(P.EIA_SERIES.keys()), "missing columns"
assert len(df) > 0
print("  ✅ PASS — all configured series present")
print()

# ─── Test 3: cache hit on second call ───
print("=" * 60)
print("TEST 3: cache reuse")
print("=" * 60)
call_count = {"n": 0}
def counting_get(*args, **kwargs):
    call_count["n"] += 1
    return fake_requests_get(*args, **kwargs)
with patch("requests.get", side_effect=counting_get):
    df2 = P.load_eia_panel("FAKE_KEY", cache_path=cache_path, refresh=False)
assert call_count["n"] == 0, "cache should have prevented network calls"
assert df2.shape == df.shape
print(f"  Network calls on cached read: {call_count['n']}")
print("  ✅ PASS — cache reuse works")
print()

# ─── Test 4: full pipeline with mocked EIA ───
print("=" * 60)
print("TEST 4: end-to-end run on mocked EIA")
print("=" * 60)
events = []
def cb(stage, n, total, msg):
    events.append((stage, msg))

# Use cached data
out = P.run_full_pipeline(
    api_key="FAKE_KEY", cache_path=cache_path,
    cfg=P.BacktestConfig(train_size=150, test_size=40),
    progress_cb=cb,
)
print(f"  Stages fired: {sorted(set(s for s, _ in events))}")
print(f"  Indicator rows: {len(out['indicators'])}")
print(f"  Trades: {out['metrics']['n_trades']}")
print(f"  Hit rate: {out['metrics']['hit_rate_pct']:.2f}%")
assert out["metrics"]["n_folds"] >= 1
assert "raw" in out and "results" in out
print("  ✅ PASS — full pipeline runs end-to-end on mocked EIA data")
print()

# Clean up
if os.path.exists(cache_path): os.unlink(cache_path)

print("=" * 60)
print("ALL EIA LOADER TESTS PASSED")
print("=" * 60)
