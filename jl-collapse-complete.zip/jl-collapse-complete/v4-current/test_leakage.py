"""Validate the leakage fixes by feeding pure-noise features.

If the pipeline is truly leakage-free, a strategy built on i.i.d. random
features should produce ~50% hit rate, Sharpe near 0, and cumulative pnl
indistinguishable from random walk over many seeds.
"""
import sys
sys.path.insert(0, "/home/claude/repo2")

import numpy as np
import pandas as pd
from pipeline import (
    rolling_profit_rank_no_leak,
    rolling_modified_zscore_no_leak,
    JLCollapse,
    walk_forward_backtest,
    BacktestConfig,
    build_indicators,
    basic_clean,
    mad_zscore_panel,
)


def make_random_market(n=8000, n_features=20, seed=0):
    """Build a fake panel where WTI is a random walk and 'features' are pure noise.

    A leakage-free strategy SHOULD NOT find alpha here.
    """
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2010-01-01", periods=n)
    log_wti = np.cumsum(rng.normal(0, 0.012, n)) + np.log(70.0)
    wti = np.exp(log_wti)

    cols = {"WTI": wti, "BRENT": wti + 2 + rng.normal(0, 0.5, n)}
    for k in ("CRUDE_STOCKS", "GASOLINE_STOCKS", "DISTILLATE_STOCKS",
              "CUSHING_STOCKS", "SPR", "REF_UTIL", "REF_RUNS",
              "GASOLINE_DEMAND", "DISTILLATE_DEMAND", "HH"):
        cols[k] = np.cumsum(rng.normal(0, 1, n)) + 100  # pure random walk junk
    return pd.DataFrame(cols, index=idx)


def run_one(seed):
    raw = make_random_market(n=8000, seed=seed)
    clean = basic_clean(raw)
    mz = mad_zscore_panel(clean).dropna()
    indicators = build_indicators(clean, mz)
    cfg = BacktestConfig(train_size=1500, test_size=500)
    _, m = walk_forward_backtest(indicators, clean, cfg)
    return m


print("=" * 60)
print("LEAKAGE TEST — pure-noise features, random-walk price")
print("=" * 60)
print("Expectation: hit rate ≈ 50%, sharpe ≈ 0, no consistent alpha.")
print()

results = []
for seed in range(8):
    m = run_one(seed)
    results.append(m)
    print(f"  seed {seed}:  cum={m['cumulative_return_pct']:+8.2f}%  "
          f"hit={m['hit_rate_pct']:5.2f}%  sharpe={m['sharpe_annualized']:+6.2f}  "
          f"trades={m['n_trades']}")

cum  = [m["cumulative_return_pct"] for m in results]
hit  = [m["hit_rate_pct"] for m in results]
shp  = [m["sharpe_annualized"] for m in results]

print()
print(f"Mean hit rate:  {np.mean(hit):.2f}%   (expect ≈ 50%)")
print(f"Mean Sharpe:    {np.mean(shp):+.2f}    (expect ≈ 0)")
print(f"Mean cum ret:   {np.mean(cum):+.2f}%   (expect ≈ 0)")
print(f"Std cum ret:    {np.std(cum):.2f}%")
print()
if abs(np.mean(hit) - 50.0) < 3.0 and abs(np.mean(shp)) < 0.5:
    print("✅ PASS — strategy shows no edge on pure noise. Leakage fixes are working.")
else:
    print("❌ FAIL — strategy still finds 'alpha' in pure noise. Leakage remains.")
