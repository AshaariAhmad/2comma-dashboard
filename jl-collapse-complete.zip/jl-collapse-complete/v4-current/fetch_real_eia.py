#!/usr/bin/env python3
"""Fetch real EIA data and populate the cache.

Run this ONCE on your machine to pull live EIA series. After that, the
dashboard and backtest use the cached data — no further API calls needed
until you want to refresh.

Usage:
    export EIA_API_KEY=your_key_here
    python fetch_real_eia.py

    # Or pass key as argument:
    python fetch_real_eia.py --api-key YOUR_KEY

    # Custom start date:
    python fetch_real_eia.py --start 2010-01-01

    # Custom cache path:
    python fetch_real_eia.py --cache my_eia.parquet

Get a free API key at: https://www.eia.gov/opendata/register.php
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pipeline as P


def make_progress_logger():
    """A simple progress logger that overwrites the current line."""
    last_msg = [""]
    def cb(stage, i, n, msg):
        line = f"  [{stage:7s}] {i}/{n}  {msg}"
        # Pad to clear any longer previous line
        line += " " * max(0, len(last_msg[0]) - len(line))
        print("\r" + line, end="", flush=True)
        last_msg[0] = line
        # Newline after each fetch step for readable log
        if stage in ("fetch", "cache"):
            print()
    return cb


def main():
    parser = argparse.ArgumentParser(
        description="Fetch real EIA crude-oil panel and populate local cache.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--api-key", default=os.environ.get("EIA_API_KEY", ""),
                        help="EIA v2 API key (or set EIA_API_KEY env var)")
    parser.add_argument("--start", default="2000-01-01",
                        help="Earliest date to fetch (YYYY-MM-DD, default 2000-01-01)")
    parser.add_argument("--cache", default="eia_cache.parquet",
                        help="Cache file path (default: eia_cache.parquet)")
    parser.add_argument("--refresh", action="store_true",
                        help="Force refetch even if cache exists")
    parser.add_argument("--strict", action="store_true",
                        help="Abort on any series failure (default: skip and continue)")
    args = parser.parse_args()

    if not args.api_key:
        print("ERROR: no API key provided.")
        print("Set EIA_API_KEY env var or pass --api-key.")
        print("Sign up free: https://www.eia.gov/opendata/register.php")
        sys.exit(2)

    print("=" * 70)
    print("  EIA REAL-DATA FETCH")
    print("=" * 70)
    print(f"  Series to fetch:   {len(P.EIA_SERIES)} ({list(P.EIA_SERIES.keys())[:5]}...)")
    print(f"  Start date:        {args.start}")
    print(f"  Cache file:        {args.cache}")
    print(f"  Force refresh:     {args.refresh}")
    print(f"  Strict mode:       {args.strict}")
    print()

    t0 = time.time()
    try:
        df = P.load_eia_panel(
            api_key=args.api_key.strip(),
            start=args.start,
            cache_path=args.cache,
            refresh=args.refresh,
            progress_cb=make_progress_logger(),
            strict=args.strict,
        )
    except P.EIAError as e:
        print()
        print("=" * 70)
        print(f"  ❌ EIA ERROR: {e}")
        print("=" * 70)
        sys.exit(3)
    except Exception as e:
        print()
        print(f"  ❌ UNEXPECTED ERROR: {type(e).__name__}: {e}")
        sys.exit(4)

    elapsed = time.time() - t0
    failed = df.attrs.get("failed_series", {})

    print()
    print("=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print(f"  Wall time:         {elapsed:.1f} s")
    print(f"  Panel shape:       {df.shape[0]:,} rows × {df.shape[1]} columns")
    print(f"  Date range:        {df.index[0].date()} → {df.index[-1].date()}")
    print(f"  Columns loaded:    {list(df.columns)}")
    if failed:
        print(f"  ⚠ Series failed:    {len(failed)}")
        for col, msg in failed.items():
            print(f"     · {col}: {msg[:60]}")
    else:
        print(f"  ✓ All series loaded successfully")

    # Quick sanity check: do columns have reasonable non-null counts?
    print()
    print("  Non-null observation count per column:")
    for col in df.columns:
        n_obs = df[col].notna().sum()
        first = df[col].dropna().index[0].date() if n_obs else "—"
        last = df[col].dropna().index[-1].date() if n_obs else "—"
        bar = "█" * int(40 * n_obs / max(len(df), 1))
        print(f"    {col:<22s} {n_obs:>6,d}  {first} → {last}  {bar}")

    print()
    print("=" * 70)
    print(f"  ✅ Cache written. The dashboard and backtest will now use real EIA data.")
    print(f"  Next: streamlit run dashboard.py")
    print("=" * 70)


if __name__ == "__main__":
    main()
