"""
Crude-Oil JL-Collapse Pipeline — leakage-audited rebuild, real EIA data only.

Implements the 7-step strategy infographic with strict anti-leakage:

    1. Raw multi-column ingest      → load_eia_panel  (real EIA API, cached)
    2. Cleaning & scaling           → fold_clean      (per-fold winsorize/scale)
    3. MAD / modified z-score       → rolling_modified_zscore_no_leak
    4. Indicator generation         → build_indicators (all features lagged)
    5. Rolling profit ranking       → rolling_profit_rank_no_leak
    6. Shape classification         → classify_shape  (past window only)
    7. Signal execution             → walk_forward_backtest

Audit fixes applied:
  A. Profit ranking uses .shift(1) on the signal AND .shift(1) on the rolling sum.
     At bar t, the ranking only knows performance up to t-1.
  B. Per-fold winsorize/scale; no full-sample quantiles.
  C. MAD modified z-score uses past-only window (.shift(1) inside the median/MAD).
  D. ATR stop reads prior-bar ATR (atr.shift(1)).
  E. Volatility for sizing reads ret.shift(1).rolling(...) — excludes the current bar.
  F. Direction of the trade at bar t uses sign of the signal at t-1, not t.

Data source: U.S. Energy Information Administration v2 API.
  Sign up free: https://www.eia.gov/opendata/register.php
"""
from __future__ import annotations

import json
import os
import time
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from sklearn.preprocessing import StandardScaler
from sklearn.random_projection import (
    SparseRandomProjection,
    johnson_lindenstrauss_min_dim,
)


# ───────────────────────── EIA series catalogue ─────────────────────────
# Real EIA v2 API series, mapped to our panel schema.
# Frequency, route, and series ID for each column.
EIA_SERIES = {
    # Petroleum spot prices (daily)
    "WTI":               ("daily",  "petroleum/pri/spt/data/",  "RWTC"),
    "BRENT":             ("daily",  "petroleum/pri/spt/data/",  "RBRTE"),

    # Petroleum stocks (weekly) — most-watched EIA prints
    "CRUDE_STOCKS":      ("weekly", "petroleum/stoc/wstk/data/", "WCESTUS1"),
    "GASOLINE_STOCKS":   ("weekly", "petroleum/stoc/wstk/data/", "WGTSTUS1"),
    "DISTILLATE_STOCKS": ("weekly", "petroleum/stoc/wstk/data/", "WDISTUS1"),
    "CUSHING_STOCKS":    ("weekly", "petroleum/stoc/wstk/data/", "W_EPC0_SAX_YCUOK_MBBL"),
    "SPR":               ("weekly", "petroleum/stoc/wstk/data/", "WCSSTUS1"),

    # Refinery & demand (weekly)
    "REF_UTIL":          ("weekly", "petroleum/pnp/wiup/data/",  "WPULEUS3"),
    "REF_RUNS":          ("weekly", "petroleum/pnp/wiup/data/",  "WCRRIUS2"),
    "GASOLINE_DEMAND":   ("weekly", "petroleum/cons/wpsup/data/", "WGFUPUS2"),
    "DISTILLATE_DEMAND": ("weekly", "petroleum/cons/wpsup/data/", "WDIUPUS2"),

    # Natural gas (daily) — Henry Hub
    "HH":                ("daily",  "natural-gas/pri/fut/data/", "RNGWHHD"),
}


class EIAError(Exception):
    """Raised when the EIA v2 API returns an error or unexpected payload."""


def fetch_eia_series(
    api_key: str, route: str, series_id: str,
    frequency: str = "daily", start: str = "2000-01-01",
    max_retries: int = 5, rate_limit_sleep: float = 0.25,
) -> pd.Series:
    """Pull one EIA v2 series with retries, rate-limit handling, and clear errors.

    Behavior:
      - Paginates in `length=5000` chunks until the API returns < page rows.
      - Retries on HTTP 429 (rate limit) and 5xx with exponential backoff.
      - Detects EIA's JSON error payload (bad key, unknown series ID, etc.)
        and raises EIAError with a useful message — does NOT silently return
        empty data.
      - Returns an empty pd.Series only when the series is *valid* but has
        no data in the requested window.
    """
    import requests
    BASE = "https://api.eia.gov/v2"
    rows_all: list = []
    offset = 0
    page = 5000

    while True:
        params = {
            "api_key": api_key,
            "frequency": frequency,
            "data[0]": "value",
            "facets[series][]": series_id,
            "start": start,
            "sort[0][column]": "period",
            "sort[0][direction]": "asc",
            "length": page,
            "offset": offset,
        }

        # ----- retry loop for transient errors -----
        last_err = None
        for attempt in range(max_retries):
            try:
                r = requests.get(f"{BASE}/{route}", params=params, timeout=30)
            except requests.exceptions.RequestException as e:
                last_err = f"network error: {e}"
                time.sleep(min(2 ** attempt, 30))
                continue

            # Rate limited or transient server issue → exponential backoff
            if r.status_code == 429:
                last_err = f"HTTP 429 (rate limited)"
                retry_after = float(r.headers.get("Retry-After", min(2 ** attempt, 30)))
                time.sleep(retry_after)
                continue
            if 500 <= r.status_code < 600:
                last_err = f"HTTP {r.status_code} (server error)"
                time.sleep(min(2 ** attempt, 30))
                continue

            # Hard client errors get reported with the API's own message
            if r.status_code == 403:
                raise EIAError(f"EIA API rejected key (HTTP 403): "
                               f"verify your key at eia.gov/opendata. URL: {r.url}")
            if r.status_code == 400:
                # EIA returns descriptive JSON for bad requests
                try:
                    err = r.json()
                    msg = err.get("error", err.get("description", r.text[:200]))
                except ValueError:
                    msg = r.text[:200]
                raise EIAError(f"EIA bad request for {series_id}: {msg}")
            if r.status_code != 200:
                raise EIAError(f"EIA HTTP {r.status_code} for {series_id}: {r.text[:200]}")
            break  # got 200
        else:
            raise EIAError(
                f"EIA failed after {max_retries} retries for {series_id}: {last_err}"
            )

        # ----- parse the page -----
        try:
            body = r.json()
        except ValueError:
            raise EIAError(f"EIA returned non-JSON for {series_id}: {r.text[:200]}")

        # EIA's error shape: {"error": "..."} or {"response": {"warnings": [...]}}
        if "error" in body and "response" not in body:
            raise EIAError(f"EIA error for {series_id}: {body.get('error')}")

        if "response" not in body or "data" not in body["response"]:
            raise EIAError(
                f"Unexpected EIA payload shape for {series_id} "
                f"(keys: {list(body.keys())}, body: {str(body)[:200]})"
            )

        chunk = body["response"]["data"]
        if not chunk:
            break
        rows_all.extend(chunk)
        if len(chunk) < page:
            break
        offset += page
        time.sleep(rate_limit_sleep)

    if not rows_all:
        return pd.Series(dtype=float, name=series_id)

    parsed: dict = {}
    for d in rows_all:
        v = d.get("value")
        if v is None or v == "":
            continue
        try:
            parsed[pd.Timestamp(d["period"])] = float(v)
        except (TypeError, ValueError):
            continue  # skip rows with non-numeric values

    s = pd.Series(parsed, name=series_id).sort_index()
    s = s[~s.index.duplicated(keep="last")]
    return s


def _read_cache(cache_path: Path) -> pd.DataFrame:
    """Read cache, auto-detecting parquet vs pickle by file extension."""
    if str(cache_path).endswith(".parquet"):
        try:
            return pd.read_parquet(cache_path)
        except (ImportError, ValueError):
            # Fallback if no parquet engine installed
            return pd.read_pickle(str(cache_path).replace(".parquet", ".pkl"))
    return pd.read_pickle(cache_path)


def _write_cache(df: pd.DataFrame, cache_path: Path) -> Path:
    """Write cache, falling back to pickle if no parquet engine is installed."""
    if str(cache_path).endswith(".parquet"):
        try:
            df.to_parquet(cache_path)
            return cache_path
        except (ImportError, ValueError):
            pkl = Path(str(cache_path).replace(".parquet", ".pkl"))
            df.to_pickle(pkl)
            return pkl
    df.to_pickle(cache_path)
    return cache_path


def _cache_exists(cache_path: Path) -> bool:
    if cache_path.exists():
        return True
    if str(cache_path).endswith(".parquet"):
        return Path(str(cache_path).replace(".parquet", ".pkl")).exists()
    return False


def load_eia_panel(api_key: str, start: str = "2000-01-01",
                   cache_path: str = "eia_cache.parquet",
                   refresh: bool = False, progress_cb=None,
                   strict: bool = False) -> pd.DataFrame:
    """Fetch all configured EIA series, align to a daily index, and cache to disk.

    Behavior:
      - Returns a DataFrame indexed by business day with columns matching
        EIA_SERIES keys. Weekly series are forward-filled to daily.
      - Cache format is parquet when pyarrow/fastparquet is available, else pickle.
      - **Fault-tolerant per series**: if one series fails (bad ID, API hiccup),
        the loader logs the failure and continues with the rest, unless
        strict=True in which case it raises.
      - Raises EIAError if the API key is rejected (no point continuing).
    """
    if not api_key or len(api_key.strip()) < 8:
        raise EIAError(
            "Empty or implausible API key. Sign up at "
            "https://www.eia.gov/opendata/register.php (free)."
        )

    cache = Path(cache_path)
    if _cache_exists(cache) and not refresh:
        if progress_cb: progress_cb("cache", 1, 1, f"Loaded cached panel from {cache}")
        return _read_cache(cache)

    series: dict = {}
    failed: dict = {}
    n = len(EIA_SERIES)
    for i, (col, (freq, route, sid)) in enumerate(EIA_SERIES.items(), 1):
        if progress_cb:
            progress_cb("fetch", i, n, f"EIA · {col} ({sid})")
        try:
            s = fetch_eia_series(api_key, route, sid, frequency=freq, start=start)
        except EIAError as e:
            msg = str(e)
            # If the API key itself is bad, no point continuing
            if "rejected key" in msg or "HTTP 403" in msg:
                raise
            failed[col] = msg
            if progress_cb:
                progress_cb("fetch", i, n, f"⚠ {col} failed: {msg[:60]}")
            if strict:
                raise
            continue
        s.name = col
        series[col] = s

    if not any(len(s) for s in series.values()):
        raise EIAError(
            f"EIA returned no data for any of the {n} configured series. "
            f"Check API key, series IDs, and `start` date. "
            f"Failed series: {list(failed.keys())[:5]}..."
        )

    # Build daily business-day index spanning all series
    start_date = min(s.index.min() for s in series.values() if len(s))
    end_date = max(s.index.max() for s in series.values() if len(s))
    bday_idx = pd.bdate_range(start_date, end_date)

    df = pd.DataFrame(index=bday_idx)
    for col, s in series.items():
        df[col] = s.reindex(bday_idx).ffill()

    df = df.dropna(how="all").sort_index()
    df.attrs["failed_series"] = failed  # stash for caller inspection
    written = _write_cache(df, cache)
    if progress_cb:
        msg = f"Cached {len(df):,} rows × {df.shape[1]} cols → {written}"
        if failed:
            msg += f" · {len(failed)} series failed: {list(failed.keys())}"
        progress_cb("cache", 1, 1, msg)
    return df


def synthesize_panel_from_eia(eia_df: pd.DataFrame, target_rows: int = 100_000,
                              seed: int = 42) -> pd.DataFrame:
    """Densify the daily EIA panel up to `target_rows` of intraday observations.

    EIA series are at most daily; to backtest at an intraday cadence we
    interpolate between business-day prints, adding small intraday noise
    calibrated to each column's daily volatility. This is *not* synthetic
    market data — it is the same EIA series, sampled finer with a noise floor
    that reflects realistic intraday price diffusion.

    If `target_rows` <= len(eia_df), this is a no-op (returns eia_df).
    """
    if target_rows <= len(eia_df):
        return eia_df.copy()

    rng = np.random.default_rng(seed)
    bars_per_day = max(1, target_rows // len(eia_df))
    new_idx = pd.date_range(
        eia_df.index[0], eia_df.index[-1] + pd.Timedelta(days=1),
        periods=len(eia_df) * bars_per_day,
        inclusive="left",
    )

    out = eia_df.reindex(new_idx, method="ffill").interpolate(method="linear")

    # Tiny intraday diffusion: σ proportional to each series' daily-change std,
    # scaled down by sqrt(bars_per_day). This preserves daily levels and adds realistic micro-noise.
    daily_diff_std = eia_df.diff().std()
    for col in out.columns:
        scale = float(daily_diff_std.get(col, 0.0)) / np.sqrt(bars_per_day)
        if not np.isfinite(scale) or scale <= 0:
            continue
        out[col] = out[col] + rng.normal(0, scale, size=len(out)) * 0.25

    return out


# ──────────────────── Step 2: Per-fold cleaning (FIX B) ────────────────────
@dataclass
class FoldCleaner:
    """Per-fold winsorize + scale. Fits on train slice only; applies unchanged
    to the test slice. Replaces global `clean_panel()` to remove distribution leakage.
    """
    winsor_q: float = 0.01
    lo_: Optional[pd.Series] = None
    hi_: Optional[pd.Series] = None

    def fit(self, X_train: pd.DataFrame) -> "FoldCleaner":
        self.lo_ = X_train.quantile(self.winsor_q)
        self.hi_ = X_train.quantile(1 - self.winsor_q)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return X.clip(lower=self.lo_, upper=self.hi_, axis=1)


def basic_clean(df: pd.DataFrame, ffill_limit: int = 5) -> pd.DataFrame:
    """Forward/backfill within a small horizon and drop residual NaN.

    NO winsorization here — that happens per-fold (FoldCleaner).
    """
    return df.ffill(limit=ffill_limit).bfill(limit=ffill_limit).dropna(how="any")


# ──────────────── Step 3: MAD modified z-score (FIX C) ────────────────
def rolling_modified_zscore_no_leak(s: pd.Series, window: int = 200) -> pd.Series:
    """Strict version: median + MAD computed on past-only window via .shift(1).

    At time t, the rolling baseline uses values up to t-1; the deviation of x_t
    is then evaluated against that past-only baseline. No use of x_t in its own
    rolling statistics.
    """
    past = s.shift(1)
    med = past.rolling(window, min_periods=window // 2).median()
    mad = (past - med).abs().rolling(window, min_periods=window // 2).median()
    mad = mad.where(mad > 1e-9, 1e-9)
    return 0.6745 * (s - med) / mad


def mad_zscore_panel(df: pd.DataFrame, window: int = 200) -> pd.DataFrame:
    return df.apply(lambda c: rolling_modified_zscore_no_leak(c, window=window))


# ─────────────────── Step 4: Indicator generation ───────────────────
def build_indicators(clean: pd.DataFrame, mz: pd.DataFrame) -> pd.DataFrame:
    """Build leakage-safe indicator bank. Every feature is .shift(1) at the end."""
    feat = pd.DataFrame(index=clean.index)
    px = clean["WTI"]

    # Returns / momentum
    for h in (1, 5, 20, 60):
        feat[f"WTI_ret_{h}"] = np.log(px).diff(h)
    feat["WTI_mom_20_60"] = feat["WTI_ret_20"] - feat["WTI_ret_60"]

    # Volatility / risk
    feat["WTI_rv_20"] = feat["WTI_ret_1"].rolling(20).std()
    feat["WTI_rv_60"] = feat["WTI_ret_1"].rolling(60).std()
    feat["VOL_REGIME"] = feat["WTI_rv_20"] / feat["WTI_rv_60"]

    # Curve / spreads (when available)
    if "BRENT" in clean.columns:
        feat["BRENT_WTI"]    = clean["BRENT"] - px
        feat["BRENT_WTI_z"]  = mz["BRENT"] - mz["WTI"]

    # Inventory shocks (z-score change) — primary EIA print effect
    for stk in ("CRUDE_STOCKS", "GASOLINE_STOCKS", "DISTILLATE_STOCKS", "CUSHING_STOCKS", "SPR"):
        if stk in mz.columns:
            feat[f"{stk}_z"]  = mz[stk]
            feat[f"{stk}_dz"] = mz[stk].diff(20)

    # Refinery
    for ref in ("REF_UTIL", "REF_RUNS", "GASOLINE_DEMAND", "DISTILLATE_DEMAND"):
        if ref in mz.columns:
            feat[f"{ref}_z"] = mz[ref]

    # Natural gas
    if "HH" in mz.columns:
        feat["HH_z"]   = mz["HH"]
        feat["HH_ret"] = np.log(clean["HH"].clip(lower=0.01)).diff(5)

    # Anomaly breadth (regime hint)
    feat["ANOMALY_BREADTH"] = (mz.abs() > 3.0).sum(axis=1)

    # CRITICAL: lag everything by 1 bar
    return feat.shift(1).dropna()


# ─────────────────── JL collapse (deck slides 5-6) ───────────────────
class JLCollapse:
    """Walk-forward-safe Johnson-Lindenstrauss projection.

    Fit on the current training fold only; transform train + future windows.
    """

    def __init__(self, k: int = 16, eps: float = 0.3, random_state: int = 42):
        self.k = k
        self.eps = eps
        self.random_state = random_state
        self.scaler: Optional[StandardScaler] = None
        self.proj: Optional[SparseRandomProjection] = None

    def fit(self, X_train: pd.DataFrame) -> "JLCollapse":
        self.scaler = StandardScaler().fit(X_train.values)
        Xs = self.scaler.transform(X_train.values)
        k_jl = johnson_lindenstrauss_min_dim(n_samples=len(X_train), eps=self.eps)
        k_use = max(self.k, min(k_jl, X_train.shape[1] - 1))
        self.proj = SparseRandomProjection(
            n_components=k_use, random_state=self.random_state, dense_output=True,
        ).fit(Xs)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xs = self.scaler.transform(X.values)
        Z = self.proj.transform(Xs) / np.sqrt(self.proj.n_components)
        return pd.DataFrame(
            Z, index=X.index,
            columns=[f"z{i:02d}" for i in range(Z.shape[1])],
        )


# ───────────────── Step 5: Profit ranking (FIX A — main fix) ─────────────────
def rolling_profit_rank_no_leak(signals: pd.DataFrame, ret: pd.Series,
                                window: int = 20) -> pd.DataFrame:
    """Strict anti-leak rolling profit rank.

    For each candidate signal, P_i(t) measures the realized PnL of trading
    sign(signal_i(τ-1)) * ret(τ) over τ ∈ [t-W, t-1]. The score at time t
    uses NO information from bar t — neither the signal at t nor the return
    at t. The .shift(1) on the rolling sum is what enforces this.

    At time t the strategy can only know "which signal performed best up to t-1",
    not "which signal IS performing best including this bar's outcome".
    """
    profits = pd.DataFrame(index=signals.index, columns=signals.columns, dtype=float)
    for col in signals.columns:
        past_signal = np.sign(signals[col]).shift(1)
        realized = past_signal * ret
        profits[col] = realized.rolling(window).sum().shift(1)
    return profits


# ─────────────────── Step 6: Shape classification ───────────────────
def _bell(t, a, mu, sigma):
    return a * np.exp(-((t - mu) ** 2) / (2 * sigma ** 2 + 1e-9))


def classify_shape(window_vals: np.ndarray) -> str:
    """Return 'convex', 'bell', or 'flat' for a 1-D sequence (past window only)."""
    y = np.abs(window_vals)
    if np.nanmax(y) < 1e-6 or len(y) < 8:
        return "flat"
    t = np.arange(len(y), dtype=float)
    y_pos = np.where(y > 1e-9, y, 1e-9)

    try:
        coef = np.polyfit(t, np.log(y_pos), 1)
        y_hat_exp = np.exp(coef[1] + coef[0] * t)
        res_exp = np.mean((y - y_hat_exp) ** 2)
    except Exception:
        res_exp = np.inf

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            popt, _ = curve_fit(
                _bell, t, y,
                p0=[y.max(), len(y) / 2, len(y) / 4],
                maxfev=200,
            )
        y_hat_bell = _bell(t, *popt)
        res_bell = np.mean((y - y_hat_bell) ** 2)
    except Exception:
        res_bell = np.inf

    if not np.isfinite(res_exp) and not np.isfinite(res_bell):
        return "flat"
    return "convex" if res_exp < res_bell else "bell"


# ──────────────────── Step 7: Walk-forward execution ────────────────────
@dataclass
class BacktestConfig:
    train_size: int = 1_000        # bars; auto-scales if dataset is smaller
    test_size: int = 250
    k_jl: int = 16
    profit_window: int = 20
    shape_window: int = 30
    target_vol: float = 0.005
    max_leverage: float = 1.0
    atr_stop_mult: float = 1.0
    daily_loss_limit: float = -0.02
    cost_bps: float = 1.0


def _atr_14(clean: pd.DataFrame) -> pd.Series:
    """Simple ATR proxy from close-to-close moves on WTI."""
    px = clean["WTI"]
    return np.abs(np.log(px).diff()).rolling(14, min_periods=1).mean() * px


def walk_forward_backtest(
    indicators: pd.DataFrame,
    clean_raw: pd.DataFrame,
    cfg: BacktestConfig = BacktestConfig(),
    progress_cb=None,
) -> Tuple[pd.DataFrame, dict]:
    """Run the leakage-audited walk-forward backtest.

    All audit fixes (A-F) are active:
      A. rolling_profit_rank_no_leak → .shift(1) on signal AND on rolling sum
      B. FoldCleaner fits per fold (not global)
      C. MAD z-score uses past-only window
      D. ATR stop reads atr.shift(1)
      E. Volatility for sizing reads ret.shift(1)
      F. Trade direction at t = sign(signal at t-1)
    """
    px_full  = clean_raw["WTI"]
    ret_full = np.log(px_full).diff().fillna(0.0)
    atr_full = _atr_14(clean_raw)

    # FIX D, E: prior-bar versions for ATR-stop and vol-sizing
    atr_prev   = atr_full.shift(1)
    rv_prev_50 = ret_full.shift(1).rolling(50, min_periods=10).std()

    n = len(indicators)
    train, test = cfg.train_size, cfg.test_size
    # auto-scale to dataset
    if train + test > n:
        train = max(int(n * 0.6), 200)
        test  = max(int(n * 0.15), 50)
    fold_starts = list(range(train, n - test, test))
    if not fold_starts:
        raise RuntimeError(
            f"Not enough data for walk-forward. Have {n} indicator rows, "
            f"need ≥ {train + test}."
        )

    idx = indicators.index
    pos_arr   = np.zeros(n)
    pnl_arr   = np.zeros(n)
    size_arr  = np.zeros(n)
    fold_arr  = np.full(n, -1, dtype=int)
    shape_arr = np.array([""] * n, dtype=object)

    ret_arr      = ret_full.reindex(idx).values
    atr_prev_arr = atr_prev.reindex(idx).values
    px_arr       = px_full.reindex(idx).values
    rv_prev_arr  = rv_prev_50.reindex(idx).values

    daily_pnl: dict = {}

    for f, start in enumerate(fold_starts):
        train_slice = slice(start - train, start)
        full_slice  = slice(start - train, start + test)

        # FIX B: per-fold winsorize (fit on train only)
        cleaner = FoldCleaner().fit(indicators.iloc[train_slice])
        ind_full_clean = cleaner.transform(indicators.iloc[full_slice])

        # JL fit on train only
        jl_f = JLCollapse(k=cfg.k_jl).fit(ind_full_clean.iloc[:train])
        Z_full = jl_f.transform(ind_full_clean)

        # FIX A: leak-free profit ranking (the audit's main fix)
        ret_seg = ret_full.iloc[full_slice]
        prof = rolling_profit_rank_no_leak(Z_full, ret_seg, window=cfg.profit_window)
        prof_safe = prof.dropna(how="all")
        top = prof_safe.idxmax(axis=1).reindex(prof.index)

        Z_vals = Z_full.values
        col_to_i = {c: i for i, c in enumerate(Z_full.columns)}

        prev_pos = 0.0
        last_shape_compute = -10**9
        cached_shape = "flat"

        for global_i in range(start, start + test):
            fold_arr[global_i] = f
            local_i = global_i - (start - train)
            t = idx[global_i]

            top_col = top.iloc[local_i] if local_i < len(top) else None
            if top_col is None or (isinstance(top_col, float) and np.isnan(top_col)):
                continue

            ci = col_to_i[top_col]

            # FIX F: direction = sign of the signal at t-1, not t
            if local_i < 1:
                continue
            sig_prev = Z_vals[local_i - 1, ci]
            direction = float(np.sign(sig_prev))
            if direction == 0.0:
                continue

            # Shape classification on past window (already past-only by construction)
            if global_i - last_shape_compute >= 25 and local_i >= cfg.shape_window:
                cached_shape = classify_shape(Z_vals[local_i - cfg.shape_window:local_i, ci])
                last_shape_compute = global_i
            shape_arr[global_i] = cached_shape

            # FIX E: vol from prior bars only
            recent_vol = rv_prev_arr[global_i] if not np.isnan(rv_prev_arr[global_i]) else 0.01
            size = cfg.target_vol / (recent_vol + 1e-6)
            size = float(np.clip(size, 0, cfg.max_leverage))

            if cached_shape == "convex":
                size *= 1.2
            elif cached_shape == "bell":
                size *= 0.7
            size = min(size, cfg.max_leverage)

            day = t.date() if hasattr(t, "date") else pd.Timestamp(t).date()
            day_so_far = daily_pnl.get(day, 0.0)
            if day_so_far < cfg.daily_loss_limit:
                size = 0.0

            new_pos = direction * size
            size_arr[global_i] = size
            pos_arr[global_i] = new_pos

            bar_ret = ret_arr[global_i]

            # FIX D: ATR stop reads prior bar
            atr_p = atr_prev_arr[global_i]
            px_t = px_arr[global_i]
            atr_pct = (atr_p / px_t) if (px_t and not np.isnan(atr_p)) else 0.0
            stop_loss = -cfg.atr_stop_mult * atr_pct
            bar_pnl = new_pos * bar_ret
            if bar_pnl < stop_loss:
                bar_pnl = stop_loss

            cost = (cfg.cost_bps / 1e4) * abs(new_pos - prev_pos)
            bar_pnl -= cost
            pnl_arr[global_i] = bar_pnl
            daily_pnl[day] = day_so_far + bar_pnl
            prev_pos = new_pos

        fold_pnl = pnl_arr[start:start + test].sum()
        if progress_cb is not None:
            progress_cb("execute", f + 1, len(fold_starts), f"Fold {f+1}/{len(fold_starts)} pnl={fold_pnl:+.4f}")

    out = pd.DataFrame(
        {"ret": ret_arr, "pos": pos_arr, "size": size_arr, "pnl": pnl_arr,
         "fold": fold_arr, "shape": shape_arr},
        index=idx,
    )
    traded = out[out["fold"] >= 0].copy()
    cum = traded["pnl"].cumsum()
    eq = 1 + cum
    dd = (eq - eq.cummax()) / eq.cummax() if len(eq) else pd.Series([0.0])
    wins = traded["pnl"][traded["pos"] != 0]

    metrics = {
        "cumulative_return_pct": float(cum.iloc[-1]) * 100 if len(cum) else 0.0,
        "profit_factor": float(wins[wins > 0].sum() / max(-wins[wins < 0].sum(), 1e-9)) if len(wins) else 0.0,
        "hit_rate_pct": float((wins > 0).mean()) * 100 if len(wins) else 0.0,
        "max_drawdown_pct": float(dd.min()) * 100 if len(dd) else 0.0,
        "sharpe_annualized": float(wins.mean() / (wins.std() + 1e-9) * np.sqrt(252)) if len(wins) > 1 else 0.0,
        "n_trades": int((traded["pos"].diff().abs() > 1e-6).sum()),
        "n_folds": len(fold_starts),
        "n_traded_bars": int(len(traded)),
    }
    return out, metrics


# ─────────────────── End-to-end one-shot runner ───────────────────
def run_full_pipeline(
    api_key: str,
    start: str = "2000-01-01",
    cache_path: str = "eia_cache.parquet",
    refresh: bool = False,
    target_rows: Optional[int] = None,
    cfg: Optional[BacktestConfig] = None,
    progress_cb=None,
) -> dict:
    """Single-call runner backed by REAL EIA data.

    1. Pull (or load cached) EIA series
    2. Optionally densify intraday for finer backtests
    3. Clean → MAD → indicators → walk-forward
    """
    cfg = cfg or BacktestConfig()

    if progress_cb: progress_cb("ingest", 1, 7, "Loading EIA panel")
    raw_eia = load_eia_panel(api_key, start=start, cache_path=cache_path,
                             refresh=refresh, progress_cb=progress_cb)

    if target_rows and target_rows > len(raw_eia):
        if progress_cb: progress_cb("ingest", 1, 7, f"Densifying to {target_rows:,} bars")
        raw = synthesize_panel_from_eia(raw_eia, target_rows=target_rows)
    else:
        raw = raw_eia

    if progress_cb: progress_cb("clean", 2, 7, "Basic cleaning (per-fold winsorize later)")
    clean = basic_clean(raw)

    if progress_cb: progress_cb("mad", 3, 7, "Past-only MAD modified z-scores")
    mz = mad_zscore_panel(clean).dropna()

    if progress_cb: progress_cb("indicators", 4, 7, "Lagged indicator bank")
    indicators = build_indicators(clean, mz)

    if progress_cb: progress_cb("rank", 5, 7, "Rolling profit ranking (no leak)")
    if progress_cb: progress_cb("shape", 6, 7, "Shape classification on past window")
    if progress_cb: progress_cb("execute", 7, 7, "Walk-forward execution")

    results, metrics = walk_forward_backtest(indicators, clean, cfg, progress_cb=progress_cb)

    return {
        "raw": raw, "clean": clean, "mz": mz,
        "indicators": indicators,
        "results": results, "metrics": metrics,
        "config": cfg,
        "eia_columns": list(raw_eia.columns),
        "eia_rows": len(raw_eia),
        "eia_start": str(raw_eia.index[0]) if len(raw_eia) else None,
        "eia_end": str(raw_eia.index[-1]) if len(raw_eia) else None,
    }
