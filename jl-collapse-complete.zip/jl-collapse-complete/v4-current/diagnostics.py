"""Diagnostic test runners — exposed as functions the dashboard can call.

Each test function returns a dict {passed, message, details, duration_sec}.
The actual test bodies are duplicated/refactored from the standalone
test_*.py scripts so we can run them in-process with progress callbacks.
"""
from __future__ import annotations

import io
import time
import traceback
from contextlib import redirect_stdout
from typing import Callable
from unittest.mock import patch, MagicMock

import numpy as np
import pandas as pd

import pipeline as P


# ─────────────────── Test 1: Leakage on pure noise ───────────────────
def _make_random_market(n=8000, seed=0):
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2010-01-01", periods=n)
    log_wti = np.cumsum(rng.normal(0, 0.012, n)) + np.log(70.0)
    wti = np.exp(log_wti)
    cols = {"WTI": wti, "BRENT": wti + 2 + rng.normal(0, 0.5, n)}
    for k in ("CRUDE_STOCKS", "GASOLINE_STOCKS", "DISTILLATE_STOCKS",
              "CUSHING_STOCKS", "SPR", "REF_UTIL", "REF_RUNS",
              "GASOLINE_DEMAND", "DISTILLATE_DEMAND", "HH"):
        cols[k] = np.cumsum(rng.normal(0, 1, n)) + 100
    return pd.DataFrame(cols, index=idx)


def run_leakage_test(progress_cb: Callable[[int, int, str], None] | None = None,
                     n_seeds: int = 8) -> dict:
    """Feed pure noise; expect hit rate ~50% and Sharpe ~0."""
    t0 = time.time()
    results = []
    for seed in range(n_seeds):
        if progress_cb: progress_cb(seed, n_seeds, f"seed {seed}: building noise market")
        raw = _make_random_market(n=8000, seed=seed)
        clean = P.basic_clean(raw)
        mz = P.mad_zscore_panel(clean).dropna()
        indicators = P.build_indicators(clean, mz)
        if progress_cb: progress_cb(seed, n_seeds, f"seed {seed}: walk-forward")
        cfg = P.BacktestConfig(train_size=1500, test_size=500)
        _, m = P.walk_forward_backtest(indicators, clean, cfg)
        results.append({**m, "seed": seed})

    hit = np.mean([r["hit_rate_pct"] for r in results])
    sharpe = np.mean([r["sharpe_annualized"] for r in results])
    cum = np.mean([r["cumulative_return_pct"] for r in results])
    duration = time.time() - t0
    passed = abs(hit - 50.0) < 3.0 and abs(sharpe) < 0.5

    msg = (
        f"hit={hit:.2f}% (expect ≈ 50%) · sharpe={sharpe:+.2f} (expect ≈ 0) · "
        f"cum={cum:+.1f}% over {n_seeds} seeds"
    )
    return {
        "passed": passed,
        "message": msg,
        "duration_sec": duration,
        "details": {"per_seed": results, "mean_hit": hit, "mean_sharpe": sharpe, "mean_cum": cum},
    }


# ─────────────── Test 2: Negative control (leaky baseline) ───────────────
def _leaky_rolling_profit_rank(signals, ret, window=20):
    profits = pd.DataFrame(index=signals.index, columns=signals.columns, dtype=float)
    for col in signals.columns:
        pnl = np.sign(signals[col]) * ret    # NO shift — peeks at current bar
        profits[col] = pnl.rolling(window).sum()
    return profits


def run_negative_control(progress_cb: Callable[[int, int, str], None] | None = None,
                         n_seeds: int = 8) -> dict:
    """Reintroduce the leaky ranker; the noise test must catch it."""
    t0 = time.time()
    results = []
    original = P.rolling_profit_rank_no_leak
    P.rolling_profit_rank_no_leak = _leaky_rolling_profit_rank
    try:
        for seed in range(n_seeds):
            if progress_cb: progress_cb(seed, n_seeds, f"leaky seed {seed}")
            raw = _make_random_market(n=8000, seed=seed)
            clean = P.basic_clean(raw)
            mz = P.mad_zscore_panel(clean).dropna()
            indicators = P.build_indicators(clean, mz)
            cfg = P.BacktestConfig(train_size=1500, test_size=500)
            _, m = P.walk_forward_backtest(indicators, clean, cfg)
            results.append({**m, "seed": seed})
    finally:
        P.rolling_profit_rank_no_leak = original

    hit = np.mean([r["hit_rate_pct"] for r in results])
    sharpe = np.mean([r["sharpe_annualized"] for r in results])
    duration = time.time() - t0
    # Test passes when leakage IS detected (hit > 53%)
    passed = hit > 53.0
    msg = (
        f"leaky hit={hit:.2f}% sharpe={sharpe:+.2f} — "
        f"{'caught' if passed else 'MISSED'} the leak"
    )
    return {
        "passed": passed,
        "message": msg,
        "duration_sec": duration,
        "details": {"per_seed": results, "mean_hit": hit, "mean_sharpe": sharpe},
    }


# ─────────────── Test 3: EIA loader (mocked requests) ───────────────
def _make_fake_eia_response(series_id, n_rows=300, freq="daily"):
    if freq == "daily":
        idx = pd.bdate_range("2020-01-01", periods=n_rows)
    else:
        idx = pd.date_range("2020-01-03", periods=n_rows, freq="W-FRI")
    rows = [{"period": str(d.date()), "value": str(50.0 + i * 0.05)}
            for i, d in enumerate(idx)]
    return {"response": {"data": rows}}


def _fake_get(url, params=None, timeout=None):
    sid = params.get("facets[series][]") if params else "X"
    freq = params.get("frequency", "daily") if params else "daily"
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = _make_fake_eia_response(sid, n_rows=300, freq=freq)
    resp.raise_for_status = MagicMock()
    return resp


def run_eia_loader_test(progress_cb: Callable[[int, int, str], None] | None = None) -> dict:
    """Verify loader logic via mocked requests.get (no real API call)."""
    t0 = time.time()
    sub_results = []
    cache_path = "/tmp/dashboard_eia_test.parquet"
    import os
    for ext in (".parquet", ".pkl"):
        p = cache_path.replace(".parquet", ext)
        if os.path.exists(p): os.unlink(p)

    try:
        # Sub-test 1: fetch_eia_series
        if progress_cb: progress_cb(0, 4, "fetch_eia_series")
        with patch("requests.get", side_effect=_fake_get):
            s = P.fetch_eia_series("KEY", "petroleum/pri/spt/data/", "RWTC", "daily")
        ok1 = len(s) == 300
        sub_results.append(("fetch_eia_series", ok1, f"got {len(s)} rows"))

        # Sub-test 2: load_eia_panel
        if progress_cb: progress_cb(1, 4, "load_eia_panel")
        with patch("requests.get", side_effect=_fake_get):
            df = P.load_eia_panel("KEY", cache_path=cache_path, refresh=True)
        ok2 = set(df.columns) == set(P.EIA_SERIES.keys()) and len(df) > 0
        sub_results.append(("load_eia_panel",
                            ok2, f"shape={df.shape}, cols={len(df.columns)}"))

        # Sub-test 3: cache reuse
        if progress_cb: progress_cb(2, 4, "cache reuse")
        call_count = {"n": 0}
        def counting(*a, **kw):
            call_count["n"] += 1
            return _fake_get(*a, **kw)
        with patch("requests.get", side_effect=counting):
            df2 = P.load_eia_panel("KEY", cache_path=cache_path, refresh=False)
        ok3 = call_count["n"] == 0
        sub_results.append(("cache_reuse", ok3, f"network calls: {call_count['n']}"))

        # Sub-test 4: end-to-end run
        if progress_cb: progress_cb(3, 4, "end-to-end")
        out = P.run_full_pipeline(
            api_key="KEY", cache_path=cache_path,
            cfg=P.BacktestConfig(train_size=150, test_size=40),
        )
        ok4 = out["metrics"]["n_folds"] >= 1 and "results" in out
        sub_results.append(("end_to_end", ok4,
                            f"{out['metrics']['n_folds']} folds, "
                            f"{len(out['indicators'])} indicator rows"))
    finally:
        for ext in (".parquet", ".pkl"):
            p = cache_path.replace(".parquet", ext)
            if os.path.exists(p): os.unlink(p)

    duration = time.time() - t0
    all_ok = all(r[1] for r in sub_results)
    msg = " · ".join(f"{n}: {'✓' if ok else '✗'}" for n, ok, _ in sub_results)
    return {
        "passed": all_ok,
        "message": msg,
        "duration_sec": duration,
        "details": {"sub_results": sub_results},
    }


# ─────────────── Convenience: run all three ───────────────
def run_all_tests(progress_cb: Callable[[str, int, int, str], None] | None = None) -> dict:
    """Run all three tests sequentially with a unified callback."""
    results = {}
    tests = [
        ("eia_loader", run_eia_loader_test),
        ("leakage",    run_leakage_test),
        ("negative_control", run_negative_control),
    ]
    for name, fn in tests:
        def cb(i, n, msg, _name=name):
            if progress_cb: progress_cb(_name, i, n, msg)
        try:
            results[name] = fn(progress_cb=cb)
        except Exception as e:
            results[name] = {
                "passed": False,
                "message": f"crashed: {e}",
                "duration_sec": 0.0,
                "details": {"traceback": traceback.format_exc()},
            }
    return results
