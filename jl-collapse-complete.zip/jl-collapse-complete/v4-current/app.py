"""
Crude-Oil JL-Collapse Pipeline — Streamlit frontend (real EIA data, leak-audited).

Run locally:
    streamlit run app.py
"""
from __future__ import annotations

import os
import time
from io import BytesIO
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from pipeline import BacktestConfig, run_full_pipeline, EIA_SERIES


# ─────────────────────────────── Page setup ───────────────────────────────
st.set_page_config(
    page_title="JL Collapse — Crude Oil",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ─────────────────────────────── Styling ───────────────────────────────
st.markdown(
    """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;500;700;800&family=Fraunces:opsz,wght@9..144,400;9..144,700;9..144,900&display=swap');

        .stApp {
            background:
                radial-gradient(circle at 15% 20%, rgba(255, 153, 0, 0.06), transparent 50%),
                radial-gradient(circle at 85% 80%, rgba(0, 200, 255, 0.04), transparent 50%),
                #0a0a0c;
            color: #e8e6e1;
        }
        .block-container { padding-top: 2.5rem; padding-bottom: 4rem; max-width: 1400px; }

        html, body, [class*="css"] { font-family: 'JetBrains Mono', monospace; }
        h1, h2, h3 { font-family: 'Fraunces', serif; font-weight: 900; letter-spacing: -0.02em; }
        h1 { color: #ff9500; font-size: 3.4rem; line-height: 1.0; margin-bottom: 0.2rem; }
        h2 { color: #e8e6e1; font-size: 1.4rem; margin-top: 2.2rem; }
        h3 { color: #ff9500; font-size: 1.1rem; }

        .header-strip {
            display: flex; justify-content: space-between; align-items: baseline;
            border-bottom: 1px solid #2a2a30; padding-bottom: 0.6rem; margin-bottom: 2rem;
            font-size: 0.72rem; letter-spacing: 0.18em; text-transform: uppercase;
            color: #6e6c66;
        }
        .header-strip .accent { color: #ff9500; }

        .stButton > button {
            background: #ff9500; color: #0a0a0c;
            border: none; border-radius: 0;
            font-family: 'JetBrains Mono', monospace; font-weight: 800;
            letter-spacing: 0.16em; text-transform: uppercase;
            padding: 1rem 2.5rem; font-size: 0.95rem;
            transition: all 0.15s ease;
            box-shadow: 4px 4px 0 #2a2a30;
        }
        .stButton > button:hover {
            background: #ffb340; transform: translate(-2px, -2px);
            box-shadow: 6px 6px 0 #2a2a30; color: #0a0a0c;
        }
        .stButton > button:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 #2a2a30; }

        .kpi-card {
            background: #131316;
            border: 1px solid #2a2a30;
            border-left: 3px solid #ff9500;
            padding: 1.2rem 1.5rem;
        }
        .kpi-label { font-size: 0.65rem; letter-spacing: 0.22em; text-transform: uppercase; color: #6e6c66; margin-bottom: 0.4rem; }
        .kpi-value { font-size: 2.2rem; font-weight: 800; line-height: 1; color: #e8e6e1; }
        .kpi-foot { font-size: 0.7rem; color: #6e6c66; margin-top: 0.4rem; letter-spacing: 0.05em; }
        .kpi-positive { color: #4ade80; }
        .kpi-negative { color: #f87171; }
        .kpi-cyan { color: #38bdf8; }
        .kpi-purple { color: #c084fc; }

        .step-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.4rem; margin: 1.5rem 0; }
        .step-cell {
            background: #131316; border: 1px solid #2a2a30; padding: 0.7rem;
            font-size: 0.7rem; line-height: 1.3; min-height: 80px;
            position: relative;
        }
        .step-cell.done { border-color: #ff9500; background: #1a1611; }
        .step-cell.active { border-color: #38bdf8; background: #0f1620; }
        .step-cell .num { color: #ff9500; font-weight: 800; font-size: 0.8rem; }
        .step-cell .lbl { color: #e8e6e1; margin-top: 0.3rem; font-weight: 500; }
        .step-cell.done::after { content: "✓"; position: absolute; top: 0.4rem; right: 0.5rem; color: #ff9500; }

        .stProgress > div > div > div { background: linear-gradient(90deg, #ff9500, #ffb340); }

        .log-panel {
            background: #050507; border: 1px solid #2a2a30; padding: 1rem 1.2rem;
            font-family: 'JetBrains Mono', monospace; font-size: 0.78rem;
            color: #4ade80; max-height: 220px; overflow-y: auto;
        }
        .log-panel .ts { color: #6e6c66; }
        .log-panel .ok { color: #4ade80; }

        .audit-badge {
            display: inline-block;
            background: #1a1611; border: 1px solid #ff9500; color: #ff9500;
            padding: 0.3rem 0.7rem; font-size: 0.7rem; letter-spacing: 0.12em;
            text-transform: uppercase; margin-right: 0.4rem;
        }

        .footer {
            border-top: 1px solid #2a2a30; margin-top: 3rem; padding-top: 1rem;
            font-size: 0.7rem; color: #6e6c66; letter-spacing: 0.05em;
        }

        #MainMenu, header, footer { visibility: hidden; }

        .stTextInput input, .stNumberInput input {
            background: #131316 !important; color: #e8e6e1 !important;
            border: 1px solid #2a2a30 !important; border-radius: 0 !important;
            font-family: 'JetBrains Mono', monospace !important;
        }
    </style>
    """,
    unsafe_allow_html=True,
)


# ─────────────────────────────── Header ───────────────────────────────
st.markdown(
    """
    <div class="header-strip">
        <span><span class="accent">●</span> JL.COLLAPSE / CRUDE OIL · v2 — REAL EIA</span>
        <span>WALK-FORWARD · LEAK-AUDITED · MAD-ROBUST</span>
        <span>PIPELINE READY</span>
    </div>
    """,
    unsafe_allow_html=True,
)

col_hero_left, col_hero_right = st.columns([2, 1])
with col_hero_left:
    st.markdown("# JL Collapse.")
    st.markdown(
        '<p style="color: #a8a59f; font-size: 1.05rem; max-width: 600px; line-height: 1.5;">'
        "Compress real EIA crude-oil columns into a tradable latent vector. "
        "Detect spikes with MAD, rank signals by rolling profit, classify their shape, "
        "execute under a strict walk-forward risk overlay. <b style='color:#ff9500;'>One button.</b>"
        "</p>",
        unsafe_allow_html=True,
    )
with col_hero_right:
    st.markdown(
        '<div style="text-align: right; font-size: 0.7rem; color: #6e6c66; letter-spacing: 0.18em; '
        'text-transform: uppercase; margin-top: 1.2rem;">'
        "Implementation Workflow<br/>"
        '<span style="color: #ff9500; font-size: 1.4rem; font-family: Fraunces;">7 STEPS</span><br/>'
        "Raw → Clean → MAD → Indicators<br/>→ Rank → Shape → Execute"
        "</div>",
        unsafe_allow_html=True,
    )

# Audit badges
st.markdown(
    """
    <div style="margin-top: 0.6rem; margin-bottom: 1.5rem;">
      <span class="audit-badge">FIX A · profit-rank shifted</span>
      <span class="audit-badge">FIX B · per-fold winsor</span>
      <span class="audit-badge">FIX C · MAD past-only</span>
      <span class="audit-badge">FIX D · prior-bar ATR</span>
      <span class="audit-badge">FIX E · prior-bar vol</span>
      <span class="audit-badge">FIX F · t−1 direction</span>
    </div>
    """,
    unsafe_allow_html=True,
)


# ─────────────────────────────── Configuration ───────────────────────────────
st.markdown("## Data source")

api_col, cache_col, refresh_col = st.columns([2, 1, 1])
with api_col:
    default_key = os.environ.get("EIA_API_KEY", "")
    api_key = st.text_input(
        "EIA v2 API key",
        value=default_key, type="password",
        help="Free key at eia.gov/opendata/register.php · or set EIA_API_KEY env var",
    )
with cache_col:
    cache_path = st.text_input("Cache file", value="eia_cache.parquet")
with refresh_col:
    refresh = st.checkbox("Force refresh", value=False)

# Cache status
cache_exists = Path(cache_path).exists()
cache_msg = (
    f"Cached panel found at {cache_path}" if cache_exists
    else "No cache yet — first run will fetch ~12 EIA series (1-2 min)"
)
st.caption(f"⏵ {cache_msg}")

st.markdown("## Configuration")

cfg_col1, cfg_col2, cfg_col3, cfg_col4 = st.columns(4)
with cfg_col1:
    target_rows = st.select_slider(
        "Backtest cadence",
        options=[0, 25_000, 50_000, 100_000],
        value=0,
        format_func=lambda x: "Daily (raw EIA)" if x == 0 else f"Densified to {x:,}",
        help="0 = use EIA's native daily cadence; >0 = interpolate to that many bars",
    )
with cfg_col2:
    k_jl = st.select_slider("JL latent dim k", options=[8, 16, 32, 64], value=16)
with cfg_col3:
    target_vol = st.slider("Target bar vol", 0.001, 0.02, 0.005, 0.001, format="%.3f")
with cfg_col4:
    daily_loss = st.slider("Daily loss limit", -0.05, -0.005, -0.02, 0.005, format="%.3f")

with st.expander("Advanced (anti-leakage / cost / stop)"):
    adv1, adv2, adv3, adv4 = st.columns(4)
    with adv1:
        train_size = st.number_input("Train window (bars)", 200, 50_000, 1_000, 100)
    with adv2:
        test_size = st.number_input("Test window (bars)", 50, 10_000, 250, 50)
    with adv3:
        atr_mult = st.slider("ATR stop ×", 0.5, 3.0, 1.0, 0.1)
    with adv4:
        cost_bps = st.slider("Cost (bps/turn)", 0.0, 5.0, 1.0, 0.5)


# ─────────────────────────────── Run button ───────────────────────────────
st.markdown("##  ")
_, run_col, _ = st.columns([1, 2, 1])
with run_col:
    run = st.button("▶  Run Full Pipeline", use_container_width=True,
                    disabled=not api_key)
    if not api_key:
        st.caption("⚠️ Enter an EIA API key above to enable run.")


# ─────────────────────────────── Step grid ───────────────────────────────
STEPS = [
    ("01", "Raw EIA ingest"),
    ("02", "Cleaning & scaling"),
    ("03", "MAD / modified z-score"),
    ("04", "Indicator generation"),
    ("05", "Rolling profit ranking"),
    ("06", "Shape classification"),
    ("07", "Signal execution"),
]


def render_step_grid(active: int, done_through: int) -> str:
    cells = []
    for i, (num, lbl) in enumerate(STEPS):
        klass = "step-cell"
        if i < done_through:
            klass += " done"
        elif i == active:
            klass += " active"
        cells.append(f'<div class="{klass}"><div class="num">{num}</div><div class="lbl">{lbl}</div></div>')
    return f'<div class="step-grid">{"".join(cells)}</div>'


step_grid_slot = st.empty()
step_grid_slot.markdown(render_step_grid(-1, 0), unsafe_allow_html=True)


# ─────────────────────────────── Pipeline run ───────────────────────────────
if run:
    progress_slot = st.progress(0.0, text="Booting pipeline…")
    log_slot = st.empty()
    log_lines: list[str] = []

    STEP_NAME_TO_INDEX = {
        "ingest": 0, "fetch": 0, "cache": 0,
        "clean": 1, "mad": 2, "indicators": 3,
        "rank": 4, "shape": 5, "execute": 6,
    }

    def on_progress(stage: str, n: int, total: int, msg: str):
        idx = STEP_NAME_TO_INDEX.get(stage, 0)
        ts = time.strftime("%H:%M:%S")
        log_lines.append(f'<span class="ts">{ts}</span>  <span class="ok">▸</span>  [{stage}] {msg}')
        log_html = "<br/>".join(log_lines[-14:])
        log_slot.markdown(f'<div class="log-panel">{log_html}</div>', unsafe_allow_html=True)
        step_grid_slot.markdown(render_step_grid(idx, idx), unsafe_allow_html=True)
        progress_slot.progress((idx + 1) / 7, text=f"Step {idx + 1}/7 — {msg}")

    cfg = BacktestConfig(
        train_size=int(train_size), test_size=int(test_size),
        k_jl=int(k_jl), target_vol=float(target_vol),
        atr_stop_mult=float(atr_mult), daily_loss_limit=float(daily_loss),
        cost_bps=float(cost_bps),
    )

    t0 = time.time()
    try:
        out = run_full_pipeline(
            api_key=api_key.strip(),
            cache_path=cache_path,
            refresh=refresh,
            target_rows=int(target_rows) if target_rows > 0 else None,
            cfg=cfg,
            progress_cb=on_progress,
        )
    except Exception as e:
        st.error(f"Pipeline error: {e}")
        st.stop()

    elapsed = time.time() - t0
    progress_slot.progress(1.0, text=f"Complete in {elapsed:.1f}s")
    step_grid_slot.markdown(render_step_grid(-1, 7), unsafe_allow_html=True)

    st.session_state["out"] = out
    st.session_state["elapsed"] = elapsed


# ─────────────────────────────── Results ───────────────────────────────
if "out" in st.session_state:
    out = st.session_state["out"]
    metrics = out["metrics"]

    # EIA panel info
    st.markdown("## EIA panel")
    info_left, info_right = st.columns([3, 1])
    with info_left:
        st.markdown(
            f'<div style="font-size: 0.85rem; color: #a8a59f; letter-spacing: 0.04em;">'
            f'Pulled <b style="color:#ff9500;">{out["eia_rows"]:,}</b> business-day rows · '
            f'<b style="color:#ff9500;">{len(out["eia_columns"])}</b> series · '
            f'{out["eia_start"][:10]} → {out["eia_end"][:10]}<br/>'
            f'<span style="color:#6e6c66; font-size:0.75rem;">{", ".join(out["eia_columns"])}</span>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with info_right:
        st.markdown(
            f'<div style="text-align: right; font-size: 0.75rem; color: #6e6c66;">'
            f'Trained on <b style="color:#ff9500;">{len(out["indicators"]):,}</b> indicator rows<br/>'
            f'across <b style="color:#ff9500;">{metrics["n_folds"]}</b> walk-forward folds'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("## Performance dashboard")
    st.markdown(
        f'<div style="color: #6e6c66; font-size: 0.78rem; letter-spacing: 0.05em; margin-bottom: 1rem;">'
        f'Walk-forward · {metrics["n_folds"]} folds · {metrics["n_trades"]:,} trades · '
        f'{metrics["n_traded_bars"]:,} test bars · completed in {st.session_state["elapsed"]:.1f}s'
        f'</div>',
        unsafe_allow_html=True,
    )

    cum = metrics["cumulative_return_pct"]
    pf = metrics["profit_factor"]
    hr = metrics["hit_rate_pct"]
    dd = metrics["max_drawdown_pct"]
    cum_class = "kpi-positive" if cum > 0 else "kpi-negative"

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(
            f'<div class="kpi-card"><div class="kpi-label">Cumulative Return</div>'
            f'<div class="kpi-value {cum_class}">{cum:+,.1f}%</div>'
            f'<div class="kpi-foot">since inception · sum of bar pnl</div></div>',
            unsafe_allow_html=True,
        )
    with k2:
        st.markdown(
            f'<div class="kpi-card"><div class="kpi-label">Profit Factor</div>'
            f'<div class="kpi-value kpi-cyan">{pf:.2f}</div>'
            f'<div class="kpi-foot">gross profit / gross loss</div></div>',
            unsafe_allow_html=True,
        )
    with k3:
        st.markdown(
            f'<div class="kpi-card"><div class="kpi-label">Hit Rate</div>'
            f'<div class="kpi-value kpi-purple">{hr:.1f}%</div>'
            f'<div class="kpi-foot">winning trades / total</div></div>',
            unsafe_allow_html=True,
        )
    with k4:
        st.markdown(
            f'<div class="kpi-card"><div class="kpi-label">Max Drawdown</div>'
            f'<div class="kpi-value kpi-negative">{dd:.2f}%</div>'
            f'<div class="kpi-foot">peak to trough</div></div>',
            unsafe_allow_html=True,
        )

    # Sharpe in a separate row
    sh = metrics["sharpe_annualized"]
    sh_class = "kpi-positive" if sh > 0 else "kpi-negative"
    st.markdown(
        f'<div class="kpi-card" style="margin-top:0.8rem;">'
        f'<div class="kpi-label">Annualized Sharpe (trade-bar)</div>'
        f'<div class="kpi-value {sh_class}">{sh:+.2f}</div>'
        f'<div class="kpi-foot">expect 0.7–1.5 on real EIA · &gt;3 is suspicious</div></div>',
        unsafe_allow_html=True,
    )

    # ─────── Charts ───────
    traded = out["results"][out["results"]["fold"] >= 0].copy()
    eq = 1 + traded["pnl"].cumsum()
    drawdown = (eq - eq.cummax()) / eq.cummax() * 100

    PLOT_BG = "#0a0a0c"; GRID = "#2a2a30"; AXIS = "#6e6c66"
    AMBER = "#ff9500"; GREEN = "#4ade80"; RED = "#f87171"
    CYAN = "#38bdf8"; PURPLE = "#c084fc"

    def style_fig(fig, height=380, title=None):
        fig.update_layout(
            paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
            font=dict(family="JetBrains Mono", size=11, color="#a8a59f"),
            height=height, margin=dict(l=50, r=20, t=40 if title else 20, b=40),
            xaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=AXIS),
            yaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=AXIS),
            title=dict(text=title, font=dict(color=AMBER, size=13), x=0.0) if title else None,
            hoverlabel=dict(bgcolor="#131316", bordercolor=AMBER, font_family="JetBrains Mono"),
            legend=dict(font=dict(color="#a8a59f")),
        )
        return fig

    chart_left, chart_right = st.columns(2)
    with chart_left:
        fig_eq = go.Figure()
        fig_eq.add_trace(go.Scatter(
            x=eq.index, y=eq.values, mode="lines",
            line=dict(color=GREEN, width=1.4),
            fill="tozeroy", fillcolor="rgba(74, 222, 128, 0.08)",
        ))
        st.plotly_chart(style_fig(fig_eq, title="Equity curve (1 + Σ pnl)"), use_container_width=True)
    with chart_right:
        fig_dd = go.Figure()
        fig_dd.add_trace(go.Scatter(
            x=drawdown.index, y=drawdown.values, mode="lines",
            line=dict(color=RED, width=1.0),
            fill="tozeroy", fillcolor="rgba(248, 113, 113, 0.18)",
        ))
        st.plotly_chart(style_fig(fig_dd, title="Drawdown (%)"), use_container_width=True)

    chart_left2, chart_right2 = st.columns(2)
    with chart_left2:
        roll = traded["pnl"].rolling(min(2000, len(traded)//4 or 1), min_periods=50)
        sharpe = roll.mean() / (roll.std() + 1e-9) * np.sqrt(252)
        fig_sh = go.Figure()
        fig_sh.add_trace(go.Scatter(x=sharpe.index, y=sharpe.values, mode="lines",
                                    line=dict(color=CYAN, width=1.0)))
        fig_sh.add_hline(y=0, line=dict(color=AXIS, width=0.5))
        st.plotly_chart(style_fig(fig_sh, title="Rolling Sharpe"), use_container_width=True)
    with chart_right2:
        by_shape = (
            traded[traded["shape"].isin(["convex", "bell", "flat"])]
            .groupby("shape")["pnl"]
            .agg(["mean", "count", lambda x: (x > 0).mean()])
        )
        if len(by_shape):
            by_shape.columns = ["mean_pnl", "n", "hit_rate"]
            colors_map = {"convex": AMBER, "bell": PURPLE, "flat": "#7f7f7f"}
            fig_sh2 = go.Figure()
            fig_sh2.add_trace(go.Bar(
                x=by_shape.index, y=(by_shape["hit_rate"] * 100).values,
                marker_color=[colors_map.get(s, "#7f7f7f") for s in by_shape.index],
                text=[f'{v*100:.1f}%' for v in by_shape["hit_rate"]],
                textposition="outside", textfont=dict(color="#e8e6e1"),
            ))
            fig_sh2.add_hline(y=50, line=dict(color=AXIS, width=0.5, dash="dash"))
            st.plotly_chart(style_fig(fig_sh2, title="Hit rate by shape (%)"), use_container_width=True)

    # WTI + MAD ─────────────────────
    if "WTI" in out["mz"].columns:
        st.markdown("## Anomaly detection (Step 3)")
        sample = out["mz"].iloc[-1500:]
        fig_mad = make_subplots(
            rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05,
            row_heights=[0.55, 0.45],
            subplot_titles=("WTI price (real EIA)", "Modified z-score (past-only window)"),
        )
        px_tail = out["clean"]["WTI"].reindex(sample.index)
        fig_mad.add_trace(go.Scatter(x=px_tail.index, y=px_tail.values,
                                     line=dict(color=AMBER, width=1.0), showlegend=False), row=1, col=1)
        fig_mad.add_trace(go.Scatter(x=sample.index, y=sample["WTI"].values,
                                     line=dict(color=CYAN, width=0.8), showlegend=False), row=2, col=1)
        fig_mad.add_hline(y=3.5, line=dict(color=AMBER, width=0.6, dash="dash"), row=2, col=1)
        fig_mad.add_hline(y=-3.5, line=dict(color=AMBER, width=0.6, dash="dash"), row=2, col=1)
        fig_mad = style_fig(fig_mad, height=480)
        fig_mad.update_annotations(font=dict(color=AMBER, size=12))
        st.plotly_chart(fig_mad, use_container_width=True)

    # Downloads ─────────────────────
    st.markdown("## Export")
    dl1, dl2, dl3 = st.columns(3)
    with dl1:
        st.download_button("Trade log (CSV)",
                           data=out["results"].to_csv().encode(),
                           file_name="jl_results.csv", mime="text/csv")
    with dl2:
        st.download_button("Metrics (CSV)",
                           data=pd.DataFrame([metrics]).to_csv(index=False).encode(),
                           file_name="jl_metrics.csv", mime="text/csv")
    with dl3:
        try:
            buf = BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w:
                out["results"].to_excel(w, sheet_name="trades")
                pd.DataFrame([metrics]).to_excel(w, sheet_name="metrics", index=False)
                out["clean"].head(2000).to_excel(w, sheet_name="eia_sample")
            st.download_button("Full report (XLSX)", data=buf.getvalue(),
                               file_name="jl_report.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        except ImportError:
            st.caption("Install openpyxl for XLSX export")

    # Honest disclaimer ─────────────
    st.markdown(
        '<div style="border-left: 3px solid #ff9500; background: #131316; '
        'padding: 1rem 1.4rem; margin-top: 2rem; font-size: 0.82rem; line-height: 1.5;">'
        '<b style="color: #ff9500; letter-spacing: 0.1em; font-size: 0.7rem; '
        'text-transform: uppercase;">Reading the numbers</b><br/>'
        'On real EIA data with all six leakage fixes applied, expect '
        'Sharpe in the 0.4–1.2 range, hit rate 51–55%, and modest cumulative return. '
        'A Sharpe above ~3 is a leakage red flag — the noise test in '
        '<code>test_leakage.py</code> ships with the repo to keep us honest.'
        '</div>',
        unsafe_allow_html=True,
    )

else:
    if api_key:
        st.markdown(
            '<div style="text-align: center; color: #6e6c66; font-size: 0.85rem; '
            'padding: 3rem 0; letter-spacing: 0.08em;">'
            "Press <span style='color: #ff9500;'>▶ Run Full Pipeline</span> to fetch real EIA data and backtest."
            "</div>", unsafe_allow_html=True,
        )

# ─── Footer ───
st.markdown(
    """
    <div class="footer">
        <span style="color: #ff9500;">JL.COLLAPSE v2</span> ·
        Real EIA data · 6 leakage fixes audited ·
        <a href="https://www.eia.gov/opendata/" style="color: #38bdf8;">EIA Open Data</a> ·
        Free key at <a href="https://www.eia.gov/opendata/register.php" style="color: #38bdf8;">eia.gov/opendata/register.php</a>
    </div>
    """,
    unsafe_allow_html=True,
)
