"""Negative control: re-introduce the original leaky profit ranking and verify
the noise test correctly flags it as leaky. This proves the test has teeth.
"""
import sys
sys.path.insert(0, "/home/claude/repo2")

import numpy as np
import pandas as pd
import pipeline as P


def leaky_rolling_profit_rank(signals, ret, window=20):
    """The original leaky version — uses sign(signal at t) and ret at t in the same window."""
    profits = pd.DataFrame(index=signals.index, columns=signals.columns, dtype=float)
    for col in signals.columns:
        pnl = np.sign(signals[col]) * ret    # NO shift — peeks at current bar
        profits[col] = pnl.rolling(window).sum()
    return profits


# Monkey-patch
P.rolling_profit_rank_no_leak = leaky_rolling_profit_rank

# Re-run the same noise test
from test_leakage import make_random_market

results = []
print("NEGATIVE CONTROL — leaky ranking, pure-noise features")
print("Expectation: leak should produce visibly inflated hit rate (~55%+)")
print()
for seed in range(8):
    raw = make_random_market(n=8000, seed=seed)
    clean = P.basic_clean(raw)
    mz = P.mad_zscore_panel(clean).dropna()
    indicators = P.build_indicators(clean, mz)
    cfg = P.BacktestConfig(train_size=1500, test_size=500)
    _, m = P.walk_forward_backtest(indicators, clean, cfg)
    results.append(m)
    print(f"  seed {seed}:  hit={m['hit_rate_pct']:5.2f}%  sharpe={m['sharpe_annualized']:+6.2f}")

hit = [m["hit_rate_pct"] for m in results]
shp = [m["sharpe_annualized"] for m in results]
print()
print(f"Mean hit rate (LEAKY): {np.mean(hit):.2f}%")
print(f"Mean Sharpe   (LEAKY): {np.mean(shp):+.2f}")
print()
if np.mean(hit) > 53.0:
    print("✅ Negative control fired — the test correctly detects leakage when present.")
else:
    print("⚠️ Negative control did not fire — test may not be sensitive enough.")
