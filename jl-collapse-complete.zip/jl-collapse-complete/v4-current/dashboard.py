"""
JL Collapse Dashboard — single entry point.

Run with:
    streamlit run dashboard.py

One command surfaces:
  🏠 Home          — system status, latest run, quick actions
  🔬 Diagnostics   — run all leakage / loader tests, see results live
  📡 EIA Data      — inspect cached panel, refresh, browse columns
  ▶ Run Strategy   — full 7-step pipeline + walk-forward backtest
  📊 History       — past runs comparison (SQLite-backed)
  📚 About         — methodology, audit fixes, references
"""
from __future__ import annotations

import json
import os
import time
from io import BytesIO
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

import diagnostics as D
import history as H
from pipeline import BacktestConfig, EIA_SERIES, run_full_pipeline


# ─────────────────────────────── Page setup ───────────────────────────────
st.set_page_config(
    page_title="JL Collapse · Dashboard",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="expanded",
)

DB_PATH = "runs.db"
H.init_db(DB_PATH)


# ─────────────────────────────── Styling ───────────────────────────────
st.markdown(
    """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;500;700;800&family=Fraunces:opsz,wght@9..144,400;9..144,700;9..144,900&display=swap');

        .stApp {
            background:
                radial-gradient(circle at 15% 20%, rgba(255, 153, 0, 0.06), transparent 50%),
                radial-gradient(circle at 85% 80%, rgba(0, 200, 255, 0.04), transparent 50%),
                #0a0a0c;
            color: #e8e6e1;
        }
        .block-container { padding-top: 2rem; padding-bottom: 4rem; max-width: 1400px; }

        html, body, [class*="css"] { font-family: 'JetBrains Mono', monospace; }
        h1, h2, h3 { font-family: 'Fraunces', serif; font-weight: 900; letter-spacing: -0.02em; }
        h1 { color: #ff9500; font-size: 2.6rem; line-height: 1.0; margin-bottom: 0.4rem; }
        h2 { color: #e8e6e1; font-size: 1.4rem; margin-top: 2rem; }
        h3 { color: #ff9500; font-size: 1.05rem; }

        /* Sidebar nav */
        section[data-testid="stSidebar"] {
            background: #0e0e11; border-right: 1px solid #2a2a30;
        }
        section[data-testid="stSidebar"] h1 {
            color: #ff9500; font-size: 1.4rem; padding: 0.5rem 0 0.2rem;
            border-bottom: 1px solid #2a2a30; margin-bottom: 1rem;
        }
        section[data-testid="stSidebar"] .stRadio > label {
            font-family: 'JetBrains Mono', monospace; color: #6e6c66;
            font-size: 0.65rem; letter-spacing: 0.18em; text-transform: uppercase;
        }
        section[data-testid="stSidebar"] [role="radiogroup"] label {
            font-family: 'JetBrains Mono', monospace; font-size: 0.95rem;
            padding: 0.5rem 0;
        }

        .header-strip {
            display: flex; justify-content: space-between; align-items: baseline;
            border-bottom: 1px solid #2a2a30; padding-bottom: 0.5rem; margin-bottom: 1.6rem;
            font-size: 0.7rem; letter-spacing: 0.18em; text-transform: uppercase;
            color: #6e6c66;
        }
        .header-strip .accent { color: #ff9500; }

        .stButton > button {
            background: #ff9500; color: #0a0a0c;
            border: none; border-radius: 0;
            font-family: 'JetBrains Mono', monospace; font-weight: 800;
            letter-spacing: 0.14em; text-transform: uppercase;
            padding: 0.85rem 2rem; font-size: 0.85rem;
            transition: all 0.15s ease;
            box-shadow: 4px 4px 0 #2a2a30;
        }
        .stButton > button:hover {
            background: #ffb340; transform: translate(-2px, -2px);
            box-shadow: 6px 6px 0 #2a2a30; color: #0a0a0c;
        }
        .stButton > button:active { transform: translate(2px, 2px); box-shadow: 2px 2px 0 #2a2a30; }

        .kpi-card {
            background: #131316;
            border: 1px solid #2a2a30;
            border-left: 3px solid #ff9500;
            padding: 1rem 1.3rem;
        }
        .kpi-label { font-size: 0.62rem; letter-spacing: 0.22em; text-transform: uppercase;
                     color: #6e6c66; margin-bottom: 0.3rem; }
        .kpi-value { font-size: 1.9rem; font-weight: 800; line-height: 1; color: #e8e6e1; }
        .kpi-foot { font-size: 0.7rem; color: #6e6c66; margin-top: 0.4rem; letter-spacing: 0.05em; }
        .kpi-pos  { color: #4ade80; }
        .kpi-neg  { color: #f87171; }
        .kpi-cyan { color: #38bdf8; }
        .kpi-purple { color: #c084fc; }

        .status-pill {
            display: inline-block;
            padding: 0.25rem 0.7rem; font-size: 0.7rem;
            letter-spacing: 0.12em; text-transform: uppercase;
            border: 1px solid currentColor; border-radius: 0;
        }
        .status-ok   { color: #4ade80; }
        .status-warn { color: #fbbf24; }
        .status-fail { color: #f87171; }
        .status-unk  { color: #6e6c66; }

        .test-row {
            background: #131316; border: 1px solid #2a2a30; padding: 0.9rem 1.2rem;
            margin-bottom: 0.5rem; display: flex; justify-content: space-between;
            align-items: center;
        }
        .test-row.pass { border-left: 3px solid #4ade80; }
        .test-row.fail { border-left: 3px solid #f87171; }
        .test-row.unk  { border-left: 3px solid #6e6c66; }
        .test-name  { font-weight: 700; font-size: 0.95rem; color: #e8e6e1; }
        .test-meta  { font-size: 0.75rem; color: #6e6c66; margin-top: 0.2rem; }

        .step-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.4rem; margin: 1.2rem 0; }
        .step-cell {
            background: #131316; border: 1px solid #2a2a30; padding: 0.7rem;
            font-size: 0.7rem; line-height: 1.3; min-height: 75px; position: relative;
        }
        .step-cell.done { border-color: #ff9500; background: #1a1611; }
        .step-cell.active { border-color: #38bdf8; background: #0f1620; }
        .step-cell .num { color: #ff9500; font-weight: 800; font-size: 0.78rem; }
        .step-cell .lbl { color: #e8e6e1; margin-top: 0.3rem; font-weight: 500; }
        .step-cell.done::after { content: "✓"; position: absolute; top: 0.3rem; right: 0.5rem; color: #ff9500; }

        .stProgress > div > div > div { background: linear-gradient(90deg, #ff9500, #ffb340); }

        .log-panel {
            background: #050507; border: 1px solid #2a2a30; padding: 0.9rem 1.1rem;
            font-family: 'JetBrains Mono', monospace; font-size: 0.76rem;
            color: #4ade80; max-height: 220px; overflow-y: auto;
        }
        .log-panel .ts { color: #6e6c66; }

        .stTextInput input, .stNumberInput input {
            background: #131316 !important; color: #e8e6e1 !important;
            border: 1px solid #2a2a30 !important; border-radius: 0 !important;
            font-family: 'JetBrains Mono', monospace !important;
        }

        #MainMenu, header, footer { visibility: hidden; }
    </style>
    """,
    unsafe_allow_html=True,
)


# ─────────────────────────────── Sidebar nav ───────────────────────────────
with st.sidebar:
    st.markdown("# JL.COLLAPSE")
    st.markdown(
        '<div style="color:#6e6c66; font-size:0.7rem; letter-spacing:0.16em; '
        'text-transform:uppercase; margin-bottom:1rem;">Crude Oil Strategy</div>',
        unsafe_allow_html=True,
    )

    page = st.radio(
        "Navigation",
        [
            "🏠  Home",
            "🔬  Diagnostics",
            "📡  EIA Data",
            "▶   Run Strategy",
            "📊  History",
            "📚  About",
        ],
        label_visibility="collapsed",
    )

    st.markdown("---")
    # Sidebar status indicators
    test_status = H.latest_test_status(DB_PATH)

    def _pill(name: str, label: str) -> str:
        info = test_status.get(name)
        if info is None:
            return f'<div style="margin: 0.3rem 0;"><span class="status-pill status-unk">UNK</span> <span style="color:#6e6c66; font-size:0.78rem;">{label}</span></div>'
        klass = "status-ok" if info["passed"] else "status-fail"
        word = "PASS" if info["passed"] else "FAIL"
        return f'<div style="margin: 0.3rem 0;"><span class="status-pill {klass}">{word}</span> <span style="color:#a8a59f; font-size:0.78rem;">{label}</span></div>'

    st.markdown('<div style="color:#6e6c66; font-size:0.65rem; letter-spacing:0.18em; '
                'text-transform:uppercase; margin-bottom:0.5rem;">System status</div>',
                unsafe_allow_html=True)
    st.markdown(_pill("eia_loader", "EIA loader"), unsafe_allow_html=True)
    st.markdown(_pill("leakage", "Leakage test"), unsafe_allow_html=True)
    st.markdown(_pill("negative_control", "Negative control"), unsafe_allow_html=True)

    # Cache status
    st.markdown("---")
    cache_p = Path("eia_cache.parquet")
    cache_pkl = Path("eia_cache.pkl")
    cache_actual = cache_p if cache_p.exists() else (cache_pkl if cache_pkl.exists() else None)
    if cache_actual:
        size_kb = cache_actual.stat().st_size / 1024
        st.markdown(
            f'<div style="font-size:0.72rem; color:#a8a59f;">'
            f'<span style="color:#4ade80;">●</span> EIA cache: {size_kb:.0f} KB<br/>'
            f'<span style="color:#6e6c66; font-size:0.68rem;">{cache_actual.name}</span>'
            f'</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<div style="font-size:0.72rem; color:#a8a59f;">'
            '<span style="color:#fbbf24;">●</span> No EIA cache yet'
            '</div>', unsafe_allow_html=True,
        )

    # Run count
    runs_df = H.list_runs(DB_PATH, limit=1000)
    n_runs = len(runs_df)
    st.markdown(
        f'<div style="font-size:0.72rem; color:#a8a59f; margin-top:0.5rem;">'
        f'<span style="color:#38bdf8;">●</span> {n_runs} run{"s" if n_runs != 1 else ""} on record'
        f'</div>', unsafe_allow_html=True,
    )


# ─────────────────────────────── Helpers ───────────────────────────────
PLOT_BG = "#0a0a0c"; GRID = "#2a2a30"; AXIS = "#6e6c66"
AMBER = "#ff9500"; GREEN = "#4ade80"; RED = "#f87171"; CYAN = "#38bdf8"; PURPLE = "#c084fc"


def style_fig(fig, height=380, title=None):
    fig.update_layout(
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        font=dict(family="JetBrains Mono", size=11, color="#a8a59f"),
        height=height, margin=dict(l=50, r=20, t=40 if title else 20, b=40),
        xaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=AXIS),
        yaxis=dict(gridcolor=GRID, zerolinecolor=GRID, color=AXIS),
        title=dict(text=title, font=dict(color=AMBER, size=13), x=0.0) if title else None,
        hoverlabel=dict(bgcolor="#131316", bordercolor=AMBER, font_family="JetBrains Mono"),
        legend=dict(font=dict(color="#a8a59f")),
    )
    return fig


def kpi(label: str, value: str, foot: str = "", color_class: str = "") -> str:
    return (
        f'<div class="kpi-card"><div class="kpi-label">{label}</div>'
        f'<div class="kpi-value {color_class}">{value}</div>'
        f'<div class="kpi-foot">{foot}</div></div>'
    )


def header(title: str, subtitle: str = ""):
    st.markdown(
        f'<div class="header-strip">'
        f'<span><span class="accent">●</span> JL.COLLAPSE / {title.upper()}</span>'
        f'<span>{subtitle}</span><span>v3 · UNIFIED</span></div>',
        unsafe_allow_html=True,
    )


# ═══════════════════════════════════════════════════════════════════
#                              🏠 HOME
# ═══════════════════════════════════════════════════════════════════
if page.startswith("🏠"):
    header("Home", "control center")
    st.markdown("# Welcome to JL Collapse.")
    st.markdown(
        '<p style="color:#a8a59f; font-size:1rem; max-width:680px; line-height:1.55;">'
        "Compress real EIA crude-oil columns into a tradable latent vector. "
        "Detect spikes, rank signals by rolling profit, classify their shape, "
        "execute under a strict walk-forward risk overlay. "
        "All operations live in this dashboard — pick a section in the sidebar to begin."
        "</p>",
        unsafe_allow_html=True,
    )

    # Quick-glance KPIs from latest run
    runs = H.list_runs(DB_PATH, limit=1)
    st.markdown("## Latest run")
    if len(runs) == 0:
        st.markdown(
            '<div style="background:#131316; border:1px solid #2a2a30; '
            'border-left:3px solid #fbbf24; padding:1rem 1.4rem; font-size:0.85rem;">'
            "No runs yet. Head to <b style='color:#ff9500;'>▶ Run Strategy</b> "
            "to fetch EIA data and execute the pipeline for the first time."
            "</div>", unsafe_allow_html=True,
        )
    else:
        r = runs.iloc[0]
        c1, c2, c3, c4 = st.columns(4)
        cum_class = "kpi-pos" if r["cumulative_pct"] > 0 else "kpi-neg"
        sh_class  = "kpi-pos" if r["sharpe"] > 0 else "kpi-neg"
        with c1: st.markdown(kpi("Cumulative Return", f'{r["cumulative_pct"]:+.1f}%',
                                 f'{r["ts"].strftime("%Y-%m-%d %H:%M")}', cum_class), unsafe_allow_html=True)
        with c2: st.markdown(kpi("Sharpe", f'{r["sharpe"]:+.2f}',
                                 "expect 0.4–1.5 · >3 suspicious", sh_class), unsafe_allow_html=True)
        with c3: st.markdown(kpi("Hit Rate", f'{r["hit_rate_pct"]:.1f}%',
                                 f'{r["n_trades"]:,} trades', "kpi-purple"), unsafe_allow_html=True)
        with c4: st.markdown(kpi("Max Drawdown", f'{r["max_drawdown"]:.2f}%',
                                 "peak to trough", "kpi-neg"), unsafe_allow_html=True)

    # Quick action panel
    st.markdown("## Quick actions")
    qa1, qa2, qa3 = st.columns(3)
    with qa1:
        st.markdown(
            '<div class="kpi-card" style="border-left-color:#38bdf8;">'
            '<div class="kpi-label">Diagnostics</div>'
            '<div style="font-size:0.85rem; line-height:1.5; margin:0.6rem 0;">'
            'Run all 3 leakage / loader tests in ~15s and confirm the engine is honest.'
            '</div></div>', unsafe_allow_html=True,
        )
    with qa2:
        st.markdown(
            '<div class="kpi-card">'
            '<div class="kpi-label">Run Strategy</div>'
            '<div style="font-size:0.85rem; line-height:1.5; margin:0.6rem 0;">'
            'Fetch EIA · clean · MAD · indicators · rank · classify · execute. One button.'
            '</div></div>', unsafe_allow_html=True,
        )
    with qa3:
        st.markdown(
            '<div class="kpi-card" style="border-left-color:#c084fc;">'
            '<div class="kpi-label">EIA Data</div>'
            '<div style="font-size:0.85rem; line-height:1.5; margin:0.6rem 0;">'
            'Inspect what\'s cached locally · refresh from EIA · browse columns.'
            '</div></div>', unsafe_allow_html=True,
        )

    # Run trend (when 2+ runs exist)
    runs_all = H.list_runs(DB_PATH, limit=50)
    if len(runs_all) >= 2:
        st.markdown("## Sharpe across recent runs")
        runs_chart = runs_all.sort_values("ts")
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=runs_chart["ts"], y=runs_chart["sharpe"],
            mode="lines+markers", line=dict(color=CYAN, width=1.4),
            marker=dict(size=8, color=AMBER),
        ))
        fig.add_hline(y=3.0, line=dict(color=RED, width=0.6, dash="dash"),
                      annotation_text="leakage red flag", annotation_font_color=RED)
        st.plotly_chart(style_fig(fig, height=320, title=None), use_container_width=True)


# ═══════════════════════════════════════════════════════════════════
#                          🔬 DIAGNOSTICS
# ═══════════════════════════════════════════════════════════════════
elif page.startswith("🔬"):
    header("Diagnostics", "leakage + loader + negative control")
    st.markdown("# Diagnostics.")
    st.markdown(
        '<p style="color:#a8a59f; font-size:0.95rem; max-width:680px; line-height:1.55;">'
        "Three regression tests guard the engine: a noise test that proves the "
        "strategy has no edge on random data; a negative control that re-introduces "
        "the v1 leak and confirms the noise test catches it; and an EIA loader test "
        "that mocks the HTTP layer to verify pagination, parsing, and caching."
        "</p>",
        unsafe_allow_html=True,
    )

    n_seeds = st.slider("Random seeds per noise test (more = slower, tighter bounds)", 4, 20, 8)

    if st.button("▶  Run all diagnostics", use_container_width=False):
        log_slot = st.empty()
        log_lines: list[str] = []

        def cb(test_name, i, n, msg):
            ts = time.strftime("%H:%M:%S")
            log_lines.append(
                f'<span class="ts">{ts}</span>  <span style="color:#38bdf8;">[{test_name}]</span>  '
                f'{i}/{n} · {msg}'
            )
            log_slot.markdown(
                f'<div class="log-panel">{"<br/>".join(log_lines[-14:])}</div>',
                unsafe_allow_html=True,
            )

        with st.spinner("Running diagnostics…"):
            results = {}
            # EIA loader
            results["eia_loader"] = D.run_eia_loader_test(
                progress_cb=lambda i, n, m: cb("eia_loader", i, n, m),
            )
            # Leakage
            results["leakage"] = D.run_leakage_test(
                progress_cb=lambda i, n, m: cb("leakage", i, n, m),
                n_seeds=n_seeds,
            )
            # Negative control
            results["negative_control"] = D.run_negative_control(
                progress_cb=lambda i, n, m: cb("negative_control", i, n, m),
                n_seeds=n_seeds,
            )

        # Persist
        for name, r in results.items():
            H.record_test(name, r["passed"], r["duration_sec"], r["message"], db_path=DB_PATH)

        st.session_state["diagnostics_results"] = results
        st.success(f"Diagnostics complete · {sum(r['passed'] for r in results.values())}/3 passed")

    # Display latest results
    results = st.session_state.get("diagnostics_results")
    if results is None:
        # Reconstruct from DB if available
        latest = H.latest_test_status(DB_PATH)
        if latest:
            st.markdown("## Last recorded status")
            for name in ("eia_loader", "leakage", "negative_control"):
                info = latest.get(name)
                if info:
                    klass = "pass" if info["passed"] else "fail"
                    word = "PASSED" if info["passed"] else "FAILED"
                    color = "#4ade80" if info["passed"] else "#f87171"
                    ts = pd.to_datetime(info["ts"], unit="s").strftime("%Y-%m-%d %H:%M:%S")
                    st.markdown(
                        f'<div class="test-row {klass}">'
                        f'<div><div class="test-name">{name.replace("_", " ").title()}</div>'
                        f'<div class="test-meta">last run: {ts}</div></div>'
                        f'<div style="color:{color}; font-weight:800; letter-spacing:0.15em;">{word}</div>'
                        f'</div>', unsafe_allow_html=True,
                    )
    else:
        st.markdown("## Results")
        labels = {
            "eia_loader":       "EIA loader (mocked)",
            "leakage":          "Leakage test (pure noise)",
            "negative_control": "Negative control (leaky baseline)",
        }
        for name, r in results.items():
            klass = "pass" if r["passed"] else "fail"
            word = "PASSED" if r["passed"] else "FAILED"
            color = "#4ade80" if r["passed"] else "#f87171"
            st.markdown(
                f'<div class="test-row {klass}">'
                f'<div><div class="test-name">{labels[name]}</div>'
                f'<div class="test-meta">{r["message"]} · {r["duration_sec"]:.1f}s</div></div>'
                f'<div style="color:{color}; font-weight:800; letter-spacing:0.15em;">{word}</div>'
                f'</div>', unsafe_allow_html=True,
            )

        # Side-by-side noise vs leaky comparison
        leak = results.get("leakage", {}).get("details", {})
        neg  = results.get("negative_control", {}).get("details", {})
        if leak and neg:
            st.markdown("## Noise test vs. negative control")
            comp = pd.DataFrame({
                "metric": ["Mean hit rate (%)", "Mean Sharpe", "Verdict"],
                "Anti-leak (current)": [
                    f'{leak.get("mean_hit", 0):.2f}',
                    f'{leak.get("mean_sharpe", 0):+.2f}',
                    "no edge on noise ✓",
                ],
                "Leaky baseline (control)": [
                    f'{neg.get("mean_hit", 0):.2f}',
                    f'{neg.get("mean_sharpe", 0):+.2f}',
                    "inflated alpha caught ✓",
                ],
                "Expected": ["≈ 50.0", "≈ 0.0", ""],
            })
            st.dataframe(comp, hide_index=True, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════
#                          📡 EIA DATA
# ═══════════════════════════════════════════════════════════════════
elif page.startswith("📡"):
    header("EIA Data", "browse · refresh · inspect")
    st.markdown("# EIA Data Panel.")
    st.markdown(
        '<p style="color:#a8a59f; font-size:0.95rem; max-width:680px; line-height:1.55;">'
        "Inspect the cached EIA series, refresh from the API, or browse raw values "
        "before they enter the pipeline. The cache is auto-loaded by the strategy runner."
        "</p>",
        unsafe_allow_html=True,
    )

    # API key
    default_key = os.environ.get("EIA_API_KEY", "")
    api_key = st.text_input("EIA v2 API key", value=default_key, type="password",
                            help="Free at eia.gov/opendata/register.php")
    cache_path = st.text_input("Cache file", value="eia_cache.parquet")

    cache_p = Path(cache_path)
    cache_pkl = Path(cache_path.replace(".parquet", ".pkl"))
    cache_actual = cache_p if cache_p.exists() else (cache_pkl if cache_pkl.exists() else None)

    col_a, col_b = st.columns([1, 1])
    with col_a:
        refresh_btn = st.button(
            "↻  Refresh from EIA",
            disabled=not api_key, use_container_width=True,
        )
    with col_b:
        if cache_actual:
            st.markdown(
                f'<div style="font-size:0.8rem; color:#a8a59f; padding-top:0.6rem;">'
                f'Cache: <b>{cache_actual.name}</b> · '
                f'{cache_actual.stat().st_size / 1024:.0f} KB · '
                f'last modified {pd.Timestamp(cache_actual.stat().st_mtime, unit="s").strftime("%Y-%m-%d %H:%M")}'
                f'</div>', unsafe_allow_html=True,
            )

    if refresh_btn:
        log_slot = st.empty()
        log_lines: list[str] = []
        def cb(stage, i, n, msg):
            ts = time.strftime("%H:%M:%S")
            log_lines.append(f'<span class="ts">{ts}</span>  [{stage}] {i}/{n} · {msg}')
            log_slot.markdown(
                f'<div class="log-panel">{"<br/>".join(log_lines[-12:])}</div>',
                unsafe_allow_html=True,
            )
        with st.spinner("Fetching from EIA…"):
            try:
                from pipeline import load_eia_panel, EIAError
                df = load_eia_panel(api_key.strip(), cache_path=cache_path,
                                    refresh=True, progress_cb=cb)
                failed = df.attrs.get("failed_series", {})
                if failed:
                    st.warning(
                        f"Refreshed with partial data: {df.shape[0]:,} rows × "
                        f"{df.shape[1]} columns. {len(failed)} series failed: "
                        f"{', '.join(failed.keys())}"
                    )
                else:
                    st.success(f"Refreshed: {df.shape[0]:,} rows × {df.shape[1]} columns")
                st.session_state["eia_panel"] = df
            except EIAError as e:
                st.error(f"EIA API error: {e}")
                st.info(
                    "Tip: you can also populate the cache from the command line:\n\n"
                    "```bash\n"
                    "export EIA_API_KEY=your_key\n"
                    "python fetch_real_eia.py\n"
                    "```"
                )
            except Exception as e:
                st.error(f"Refresh failed: {e}")

    # Show panel from session or cache
    panel = st.session_state.get("eia_panel")
    if panel is None and cache_actual is not None:
        try:
            from pipeline import _read_cache
            panel = _read_cache(cache_actual)
            st.session_state["eia_panel"] = panel
        except Exception as e:
            st.warning(f"Could not load cache: {e}")

    if panel is not None and len(panel) > 0:
        st.markdown("## Panel summary")
        c1, c2, c3, c4 = st.columns(4)
        with c1: st.markdown(kpi("Rows", f'{len(panel):,}',
                                 "business days", "kpi-cyan"), unsafe_allow_html=True)
        with c2: st.markdown(kpi("Columns", str(panel.shape[1]),
                                 "EIA series", "kpi-purple"), unsafe_allow_html=True)
        with c3: st.markdown(kpi("From", panel.index[0].strftime("%Y-%m-%d"),
                                 "first observation"), unsafe_allow_html=True)
        with c4: st.markdown(kpi("To", panel.index[-1].strftime("%Y-%m-%d"),
                                 "most recent"), unsafe_allow_html=True)

        # Per-column inspection
        st.markdown("## Browse a series")
        col = st.selectbox("Column", panel.columns, index=0)
        meta_route, meta_id = "", ""
        if col in EIA_SERIES:
            _, meta_route, meta_id = EIA_SERIES[col]

        s = panel[col].dropna()
        st.markdown(
            f'<div style="font-size:0.78rem; color:#6e6c66;">'
            f'EIA series ID: <b style="color:#ff9500;">{meta_id or "N/A"}</b> · '
            f'route: <code>{meta_route or "N/A"}</code> · '
            f'{len(s):,} non-null obs · range [{s.min():.2f} → {s.max():.2f}]'
            f'</div>', unsafe_allow_html=True,
        )

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=s.index, y=s.values,
                                 line=dict(color=AMBER, width=1.0)))
        st.plotly_chart(style_fig(fig, height=360, title=col), use_container_width=True)

        # Series catalogue
        st.markdown("## Catalogue")
        cat = pd.DataFrame(
            [{"column": k, "frequency": v[0], "route": v[1], "series_id": v[2]}
             for k, v in EIA_SERIES.items()]
        )
        st.dataframe(cat, hide_index=True, use_container_width=True)
    else:
        st.markdown(
            '<div style="background:#131316; border:1px solid #2a2a30; '
            'border-left:3px solid #fbbf24; padding:1rem 1.4rem; font-size:0.85rem;">'
            "No EIA panel cached or loaded. Enter your API key above and press "
            "<b style='color:#ff9500;'>↻ Refresh from EIA</b> to fetch ~12 series."
            "</div>", unsafe_allow_html=True,
        )


# ═══════════════════════════════════════════════════════════════════
#                          ▶ RUN STRATEGY
# ═══════════════════════════════════════════════════════════════════
elif page.startswith("▶"):
    header("Run Strategy", "7-step pipeline + walk-forward")
    st.markdown("# Run Strategy.")

    default_key = os.environ.get("EIA_API_KEY", "")
    api_col, cache_col, refresh_col = st.columns([2, 1, 1])
    with api_col:
        api_key = st.text_input("EIA v2 API key", value=default_key, type="password")
    with cache_col:
        cache_path = st.text_input("Cache file", value="eia_cache.parquet")
    with refresh_col:
        refresh = st.checkbox("Force refresh", value=False)

    cfg_col1, cfg_col2, cfg_col3, cfg_col4 = st.columns(4)
    with cfg_col1:
        target_rows = st.select_slider(
            "Backtest cadence",
            options=[0, 25_000, 50_000, 100_000],
            value=0,
            format_func=lambda x: "Daily (raw EIA)" if x == 0 else f"{x:,} bars",
        )
    with cfg_col2:
        k_jl = st.select_slider("JL latent dim k", options=[8, 16, 32, 64], value=16)
    with cfg_col3:
        target_vol = st.slider("Target bar vol", 0.001, 0.02, 0.005, 0.001, format="%.3f")
    with cfg_col4:
        daily_loss = st.slider("Daily loss limit", -0.05, -0.005, -0.02, 0.005, format="%.3f")

    with st.expander("Advanced (anti-leakage / cost / stop)"):
        adv1, adv2, adv3, adv4 = st.columns(4)
        with adv1: train_size = st.number_input("Train window (bars)", 200, 50_000, 1_000, 100)
        with adv2: test_size  = st.number_input("Test window (bars)", 50, 10_000, 250, 50)
        with adv3: atr_mult   = st.slider("ATR stop ×", 0.5, 3.0, 1.0, 0.1)
        with adv4: cost_bps   = st.slider("Cost (bps/turn)", 0.0, 5.0, 1.0, 0.5)

    st.markdown("##  ")
    _, run_col, _ = st.columns([1, 2, 1])
    with run_col:
        run = st.button("▶  Run Full Pipeline", use_container_width=True,
                        disabled=not api_key)
        if not api_key:
            st.caption("⚠️ Enter an EIA API key above (or set EIA_API_KEY env var).")

    STEPS = [
        ("01", "Raw EIA ingest"),
        ("02", "Cleaning & scaling"),
        ("03", "MAD / modified z-score"),
        ("04", "Indicator generation"),
        ("05", "Rolling profit ranking"),
        ("06", "Shape classification"),
        ("07", "Signal execution"),
    ]

    def render_step_grid(active: int, done_through: int) -> str:
        cells = []
        for i, (num, lbl) in enumerate(STEPS):
            klass = "step-cell"
            if i < done_through: klass += " done"
            elif i == active:    klass += " active"
            cells.append(f'<div class="{klass}"><div class="num">{num}</div><div class="lbl">{lbl}</div></div>')
        return f'<div class="step-grid">{"".join(cells)}</div>'

    step_grid_slot = st.empty()
    step_grid_slot.markdown(render_step_grid(-1, 0), unsafe_allow_html=True)

    if run:
        progress_slot = st.progress(0.0, text="Booting pipeline…")
        log_slot = st.empty()
        log_lines: list[str] = []

        STEP_NAME_TO_INDEX = {
            "ingest": 0, "fetch": 0, "cache": 0,
            "clean": 1, "mad": 2, "indicators": 3,
            "rank": 4, "shape": 5, "execute": 6,
        }

        def on_progress(stage, n, total, msg):
            idx = STEP_NAME_TO_INDEX.get(stage, 0)
            ts = time.strftime("%H:%M:%S")
            log_lines.append(f'<span class="ts">{ts}</span>  [{stage}] {msg}')
            log_html = "<br/>".join(log_lines[-14:])
            log_slot.markdown(f'<div class="log-panel">{log_html}</div>', unsafe_allow_html=True)
            step_grid_slot.markdown(render_step_grid(idx, idx), unsafe_allow_html=True)
            progress_slot.progress((idx + 1) / 7, text=f"Step {idx + 1}/7 — {msg}")

        cfg = BacktestConfig(
            train_size=int(train_size), test_size=int(test_size),
            k_jl=int(k_jl), target_vol=float(target_vol),
            atr_stop_mult=float(atr_mult), daily_loss_limit=float(daily_loss),
            cost_bps=float(cost_bps),
        )

        t0 = time.time()
        try:
            out = run_full_pipeline(
                api_key=api_key.strip(), cache_path=cache_path, refresh=refresh,
                target_rows=int(target_rows) if target_rows > 0 else None,
                cfg=cfg, progress_cb=on_progress,
            )
        except Exception as e:
            st.error(f"Pipeline error: {e}")
            st.stop()

        elapsed = time.time() - t0
        progress_slot.progress(1.0, text=f"Complete in {elapsed:.1f}s")
        step_grid_slot.markdown(render_step_grid(-1, 7), unsafe_allow_html=True)

        # Persist
        H.record_run(out, elapsed, db_path=DB_PATH)
        st.session_state["run_out"] = out
        st.session_state["run_elapsed"] = elapsed
        st.success(f"Run complete in {elapsed:.1f}s — recorded to history")

    # Display latest run
    out = st.session_state.get("run_out")
    if out is not None:
        m = out["metrics"]
        st.markdown("## Performance")
        cum_class = "kpi-pos" if m["cumulative_return_pct"] > 0 else "kpi-neg"
        sh_class  = "kpi-pos" if m["sharpe_annualized"] > 0 else "kpi-neg"
        c1, c2, c3, c4 = st.columns(4)
        with c1: st.markdown(kpi("Cumulative", f'{m["cumulative_return_pct"]:+.1f}%',
                                 "Σ bar pnl", cum_class), unsafe_allow_html=True)
        with c2: st.markdown(kpi("Profit Factor", f'{m["profit_factor"]:.2f}',
                                 "gross/loss", "kpi-cyan"), unsafe_allow_html=True)
        with c3: st.markdown(kpi("Hit Rate", f'{m["hit_rate_pct"]:.1f}%',
                                 f'{m["n_trades"]:,} trades', "kpi-purple"), unsafe_allow_html=True)
        with c4: st.markdown(kpi("Max DD", f'{m["max_drawdown_pct"]:.2f}%',
                                 "peak to trough", "kpi-neg"), unsafe_allow_html=True)

        st.markdown(kpi("Annualized Sharpe", f'{m["sharpe_annualized"]:+.2f}',
                        "expect 0.4–1.5 · >3 is suspicious", sh_class),
                    unsafe_allow_html=True)

        # Charts
        traded = out["results"][out["results"]["fold"] >= 0].copy()
        eq = 1 + traded["pnl"].cumsum()
        dd_series = (eq - eq.cummax()) / eq.cummax() * 100

        ch1, ch2 = st.columns(2)
        with ch1:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=eq.index, y=eq.values,
                                     line=dict(color=GREEN, width=1.4),
                                     fill="tozeroy", fillcolor="rgba(74, 222, 128, 0.08)"))
            st.plotly_chart(style_fig(fig, title="Equity (1 + Σ pnl)"), use_container_width=True)
        with ch2:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=dd_series.index, y=dd_series.values,
                                     line=dict(color=RED, width=1.0),
                                     fill="tozeroy", fillcolor="rgba(248, 113, 113, 0.18)"))
            st.plotly_chart(style_fig(fig, title="Drawdown (%)"), use_container_width=True)

        # Downloads
        st.markdown("## Export")
        dl1, dl2, dl3 = st.columns(3)
        with dl1:
            st.download_button("Trade log (CSV)", data=out["results"].to_csv().encode(),
                               file_name="jl_results.csv", mime="text/csv")
        with dl2:
            st.download_button("Metrics (CSV)",
                               data=pd.DataFrame([m]).to_csv(index=False).encode(),
                               file_name="jl_metrics.csv", mime="text/csv")
        with dl3:
            try:
                buf = BytesIO()
                with pd.ExcelWriter(buf, engine="openpyxl") as w:
                    out["results"].to_excel(w, sheet_name="trades")
                    pd.DataFrame([m]).to_excel(w, sheet_name="metrics", index=False)
                st.download_button("XLSX report", data=buf.getvalue(),
                                   file_name="jl_report.xlsx",
                                   mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            except ImportError:
                st.caption("Install openpyxl for XLSX export")


# ═══════════════════════════════════════════════════════════════════
#                          📊 HISTORY
# ═══════════════════════════════════════════════════════════════════
elif page.startswith("📊"):
    header("History", "every run, recorded")
    st.markdown("# Run History.")

    runs = H.list_runs(DB_PATH, limit=200)
    if len(runs) == 0:
        st.markdown(
            '<div style="background:#131316; border:1px solid #2a2a30; '
            'border-left:3px solid #fbbf24; padding:1rem 1.4rem; font-size:0.85rem;">'
            "No runs recorded yet."
            "</div>", unsafe_allow_html=True,
        )
    else:
        # Top KPIs across all runs
        st.markdown("## Across all runs")
        c1, c2, c3, c4 = st.columns(4)
        with c1: st.markdown(kpi("Total runs", str(len(runs)), "since first record"), unsafe_allow_html=True)
        with c2: st.markdown(kpi("Best Sharpe", f'{runs["sharpe"].max():+.2f}',
                                 "across runs", "kpi-cyan"), unsafe_allow_html=True)
        with c3: st.markdown(kpi("Median hit rate", f'{runs["hit_rate_pct"].median():.1f}%',
                                 "all runs", "kpi-purple"), unsafe_allow_html=True)
        with c4: st.markdown(kpi("Median DD", f'{runs["max_drawdown"].median():.2f}%',
                                 "across runs", "kpi-neg"), unsafe_allow_html=True)

        # Sharpe trend
        st.markdown("## Sharpe over time")
        ranked = runs.sort_values("ts")
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=ranked["ts"], y=ranked["sharpe"],
                                 mode="lines+markers",
                                 line=dict(color=CYAN, width=1.4),
                                 marker=dict(size=8, color=AMBER)))
        fig.add_hline(y=3.0, line=dict(color=RED, width=0.6, dash="dash"))
        fig.add_hline(y=0.5, line=dict(color=GREEN, width=0.4, dash="dot"))
        st.plotly_chart(style_fig(fig, height=300), use_container_width=True)

        # Detailed table
        st.markdown("## Run log")
        display = runs[["ts", "sharpe", "hit_rate_pct", "cumulative_pct",
                        "max_drawdown", "profit_factor", "n_trades", "n_folds",
                        "duration_sec", "eia_rows"]].copy()
        display.columns = ["timestamp", "sharpe", "hit %", "cum %", "max dd %",
                           "pf", "trades", "folds", "secs", "eia rows"]
        for col in ("sharpe", "hit %", "cum %", "max dd %", "pf", "secs"):
            display[col] = display[col].round(2)
        st.dataframe(display, hide_index=True, use_container_width=True)

        # Clear button (with confirmation)
        with st.expander("⚠️ Clear all run history (irreversible)"):
            st.caption(f"This deletes all {len(runs)} runs from {DB_PATH}.")
            if st.button("Confirm: delete all runs", type="secondary"):
                n = H.clear_runs(DB_PATH)
                st.success(f"Deleted {n} runs. Refresh to update.")


# ═══════════════════════════════════════════════════════════════════
#                          📚 ABOUT
# ═══════════════════════════════════════════════════════════════════
elif page.startswith("📚"):
    header("About", "methodology · audit · references")
    st.markdown("# About JL Collapse.")
    st.markdown(
        """
        ### What it does

        A 7-step pipeline that turns the EIA's daily/weekly crude-oil panel into
        a tradable signal:

        1. **Raw multi-column ingest** — real EIA v2 API series (cached locally)
        2. **Cleaning & scaling** — basic ffill + per-fold winsorize
        3. **MAD / modified z-score** — robust to fat tails, past-only window
        4. **Indicator generation** — 24+ lagged features
        5. **Rolling profit ranking** — pick the signal that's working *now*
        6. **Shape classification** — convex (trend) vs bell (mean-revert)
        7. **Signal execution** — walk-forward with strict risk gates

        ### Audit history

        v1 of this engine passed an external leakage audit that flagged six issues.
        v2 fixed all of them, plus three additional ones the audit didn't catch.
        v3 (this dashboard) wraps everything behind one entry point.

        | Audit issue | Fix | Code |
        |---|---|---|
        | A — main fix | Profit ranking shifts both signal and rolling sum | `rolling_profit_rank_no_leak` |
        | B | Per-fold winsorize, never global | `FoldCleaner` inside walk-forward |
        | C | MAD z-score uses past-only window | `rolling_modified_zscore_no_leak` |
        | D | ATR stop reads prior bar | `atr.shift(1)` |
        | E | Volatility for sizing reads prior bar | `ret.shift(1).rolling(50)` |
        | F | Trade direction at t = sign of signal at t-1 | `Z_vals[local_i - 1, ci]` |

        ### Verification

        The Diagnostics tab runs three tests in ~15s:

        - **EIA loader** — pagination, parsing, cache reuse, end-to-end (mocked).
        - **Leakage** — feed pure noise; expect ≈ 50% hit rate, ≈ 0 Sharpe.
        - **Negative control** — re-introduce the v1 leak; expect the noise test
          to *fail* (proving the test has teeth).

        ### Reading the numbers

        On real EIA data with all six fixes applied, expect:

        - Sharpe in the **0.4 – 1.5** range
        - Hit rate **51 – 55%**
        - Profit factor **1.0 – 1.5**

        Sharpe above ~3 is a leakage red flag — `test_leakage.py` is your trip-wire.

        ### References

        - Johnson, W.B. and Lindenstrauss, J. (1984). *Extensions of Lipschitz mappings into a Hilbert space.*
        - EIA Open Data v2 API · <https://www.eia.gov/opendata/>
        - Series browser · <https://www.eia.gov/opendata/browser/>
        """
    )


# ─────────────────────────────── Footer ───────────────────────────────
st.markdown(
    """
    <div style="border-top: 1px solid #2a2a30; margin-top: 3rem; padding-top: 0.8rem;
                font-size: 0.7rem; color: #6e6c66; letter-spacing: 0.05em;">
        <span style="color: #ff9500;">JL.COLLAPSE v3 · UNIFIED</span> ·
        Real EIA data · 6 leakage fixes audited ·
        SQLite-backed run history · One entry point: <code>streamlit run dashboard.py</code>
    </div>
    """,
    unsafe_allow_html=True,
)
