# JL Collapse — Complete Bundle

Everything we built across this thread, in one zip.

## What's here

```
jl-collapse-complete/
├── README.md                       ← you are here
├── v4-current/                     ← ★ START HERE — the latest, complete version
│   ├── dashboard.py                  Single-entry Streamlit dashboard
│   ├── fetch_real_eia.py             CLI: fetch real EIA data into cache
│   ├── pipeline.py                   7-step + JL + walk-forward + EIA loader
│   ├── ... (full repo, see v4-current/README.md)
│   └── tests/                        4 test suites (in repo root, prefixed test_*)
│
├── v1-original-notebook.ipynb      ← Original Jupyter notebook (the first deliverable)
│
└── archive/                        ← Earlier zipped versions, for reference
    ├── v1-original-notebook-and-app.zip   First single-button frontend
    ├── v2-leakage-audited.zip             6 audit fixes applied
    ├── v3-unified-dashboard.zip           Multi-tab Streamlit dashboard
    └── v4-hardened-real-api.zip           Same as v4-current/, zipped
```

## To run the latest version

```bash
cd v4-current/
pip install -r requirements.txt
export EIA_API_KEY=your_key      # free at eia.gov/opendata/register.php
python fetch_real_eia.py          # populate cache from real EIA (~1-2 min)
streamlit run dashboard.py        # open the dashboard
```

For details, read `v4-current/README.md`.

## Evolution at a glance

| Version | What it added |
|---|---|
| **v1** | Original 7-step notebook + Streamlit app on synthetic data |
| **v2** | Leakage audit — fixed 6 leakage holes (profit-rank shift, per-fold winsor, MAD past-only, prior-bar ATR/vol, t-1 direction). Switched default to real EIA loader. |
| **v3** | Unified Streamlit dashboard with 6 tabs (Home / Diagnostics / EIA Data / Run Strategy / History / About). SQLite-backed run history. |
| **v4** | **Production-hardened EIA API client** — retry/backoff on 429/5xx, fault-tolerant per-series, EIAError with clear messages. 9 mocked failure-mode tests. CLI fetcher (`fetch_real_eia.py`). |

## Test results (run on v4)

| Test suite | Result | Time |
|---|---|---|
| `test_eia_loader.py` | 4 sub-tests passing | 2s |
| `test_real_api_errors.py` | **9/9 failure modes handled** | 7s |
| `test_leakage.py` | 49.98% hit rate on pure noise (expect ~50%) | 14s |
| `test_negative_control.py` | Caught deliberate leak at 58.40% | 26s |
| `backtest_1day.py` | 1-day backtest validates engine end-to-end | 5s |

## Important caveat

The EIA API is not reachable from the sandbox where this was built, so any
backtest result you see in this thread used synthetic-but-realistic shape data
(NOT live EIA). The pipeline code paths against the real API are tested
extensively via mocks. To get real-EIA numbers, run `fetch_real_eia.py` on
your machine with your own key.
