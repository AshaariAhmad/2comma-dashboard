@echo off
cd /d "%~dp0\streamlit_v2"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
streamlit run app.py
pause
