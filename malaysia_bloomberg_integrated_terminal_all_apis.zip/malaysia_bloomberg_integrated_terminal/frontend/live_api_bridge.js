/*
  Live API Bridge for the Bloomberg-style Malaysia terminal.
  Design rule: preserve the original visual design and add API wiring only.
*/
(function () {
  'use strict';

  const API_BASE = window.location.origin;
  const DEFAULT_SYMBOLS = ['1155.KL', '1295.KL', '1023.KL', '5347.KL', '5183.KL', '5225.KL', '^KLSE'];
  const TF_TO_API = {
    '1D': { period: '5d', interval: '5m' },
    '5D': { period: '5d', interval: '15m' },
    '1M': { period: '1mo', interval: '1d' },
    '3M': { period: '3mo', interval: '1d' },
    '1Y': { period: '1y', interval: '1d' },
    '5Y': { period: '5y', interval: '1wk' },
  };

  let currentSymbol = '1155.KL';
  let liveCandles = [];
  let liveQuote = null;
  let liveUniverse = [];
  let liveSourceStatus = [];
  let liveFinancialRows = [];
  let liveLogs = [];
  let liveCommodities = [];
  let liveCommodityReferences = [];
  let liveFx = [];
  let liveFxOfficialSources = [];
  let liveApiSources = [];

  const original = {
    drawChart: window.drawChart,
    renderStats: window.renderStats,
    renderEquityPage: window.renderEquityPage,
    renderFXPage: window.renderFXPage,
    renderTopMarkets: window.renderTopMarkets,
    execCmd: window.execCmd,
    refreshAll: window.refreshAll,
  };

  function money(v, decimals = 2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '--';
    if (Math.abs(n) < 1) return n.toFixed(4);
    return n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  }

  function pct(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '--';
    return `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`;
  }

  function vol(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '--';
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return String(Math.round(n));
  }

  function normalizeInputSymbol(raw) {
    let s = String(raw || '').trim().toUpperCase();
    if (!s) return s;
    s = s.replace(' EQUITY', '').replace(' MK', '').replace(' MY', '').trim();
    if (s === 'KLCI' || s === 'KLSE' || s === 'FBMKLCI') return '^KLSE';
    if (s === 'WTI') return 'CL=F';
    if (s === 'BRENT') return 'BZ=F';
    if (s === 'FCPO' || s === 'CPO' || s === 'PALM') return 'PO=F';
    if (/^\d{4}$/.test(s)) return `${s}.KL`;
    return s;
  }

  async function apiGet(path) {
    const res = await fetch(`${API_BASE}${path}`, { cache: 'no-store' });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`${res.status} ${res.statusText}: ${text.slice(0, 160)}`);
    }
    return await res.json();
  }

  function showApiToast(title, msg) {
    if (typeof window.showToast === 'function') window.showToast(title, msg);
  }

  function setStatus(mode, message) {
    const statusItems = document.querySelectorAll('#statusBar .status-item span');
    if (statusItems && statusItems[0]) statusItems[0].textContent = mode;
    const latency = document.getElementById('latency');
    if (latency) latency.textContent = message || 'API';
    const msgRate = document.getElementById('msgRate');
    if (msgRate) msgRate.textContent = liveLogs.length ? String(liveLogs.length) : '0';
  }

  function stopDemoMotion() {
    if (window.__demoInterval) {
      clearInterval(window.__demoInterval);
      window.__demoInterval = null;
    }
    setStatus('LIVE API / FALLBACK', 'connected');
  }

  function quoteToWatchlistItem(q) {
    const r = q || {};
    const price = Number(r.price ?? r.close ?? r.regularMarketPrice);
    const chg = Number(r.change_percent ?? r.regularMarketChangePercent ?? 0);
    return {
      sym: r.symbol || '--',
      name: r.name || r.shortName || r.longName || r.symbol || '--',
      price: Number.isFinite(price) ? price : 0,
      chg: Number.isFinite(chg) ? chg : 0,
      vol: vol(r.volume ?? r.regularMarketVolume),
      sector: r.sector || r.asset_type || 'Malaysia',
      source_api: r.source_api || 'api',
      warning: r.warning || r.data_delay_warning || '',
      currency: r.currency || 'MYR',
      raw: r,
    };
  }

  async function fetchLatest(symbol) {
    const s = normalizeInputSymbol(symbol);
    return await apiGet(`/api/market/latest?symbol=${encodeURIComponent(s)}`);
  }

  async function fetchHistory(symbol, timeframeLabel) {
    const s = normalizeInputSymbol(symbol);
    const tf = TF_TO_API[timeframeLabel || chartTimeframe] || TF_TO_API['1M'];
    const data = await apiGet(`/api/market/history?symbol=${encodeURIComponent(s)}&period=${encodeURIComponent(tf.period)}&interval=${encodeURIComponent(tf.interval)}`);
    liveCandles = Array.isArray(data.rows) ? data.rows : [];
    return data;
  }

  async function loadSecurity(symbol, silent = false) {
    const s = normalizeInputSymbol(symbol);
    currentSymbol = s;
    try {
      const [quote, history] = await Promise.all([
        fetchLatest(s),
        fetchHistory(s, window.chartTimeframe || '1M'),
      ]);
      liveQuote = quote;
      const item = quoteToWatchlistItem(quote);
      updateChartHeader(item, quote);
      if (history && history.warning) showApiToast('DATA WARNING', history.warning);
      await loadFinancials(s, true);
      renderStats();
      drawChart();
      if (!silent) showApiToast(`LOADED: ${s}`, `${item.name} | ${item.currency || ''} ${money(item.price)} | ${pct(item.chg)}`);
    } catch (err) {
      console.error(err);
      showApiToast(`API ERROR: ${s}`, err.message || 'Unable to fetch symbol');
      if (original.drawChart) original.drawChart();
    }
  }

  function updateChartHeader(item, quote) {
    const title = document.getElementById('chartTitle');
    const price = document.getElementById('chartPrice');
    const change = document.getElementById('chartChange');
    if (title) title.textContent = `${item.sym} ${item.sym.endsWith('.KL') ? 'BURSA EQUITY' : 'MARKET'}`;
    if (price) price.textContent = money(item.price);
    if (change) {
      const up = item.chg >= 0;
      change.className = up ? 'up' : 'dn';
      const abs = Number(quote.change_abs ?? 0);
      change.textContent = `${up ? '▲' : '▼'} ${abs >= 0 ? '+' : ''}${money(abs)} (${pct(item.chg)})`;
    }
  }

  async function loadUniverse() {
    try {
      const data = await apiGet('/api/universe');
      liveUniverse = data.rows || [];
      const symbols = liveUniverse.length ? liveUniverse.slice(0, 12).map(x => x.symbol) : DEFAULT_SYMBOLS;
      const quotes = [];
      for (const sym of symbols) {
        try {
          const q = await fetchLatest(sym);
          quotes.push(quoteToWatchlistItem(q));
        } catch (e) {
          console.warn('quote failed', sym, e);
        }
      }
      if (quotes.length) {
        DATA.watchlist.splice(0, DATA.watchlist.length, ...quotes.filter(x => x.sym !== '^KLSE'));
        const klse = quotes.find(x => x.sym === '^KLSE');
        if (klse) {
          DATA.indices.splice(0, DATA.indices.length, {
            sym: '^KLSE',
            name: 'FTSE Bursa Malaysia KLCI',
            price: klse.price,
            chg: klse.chg,
            raw: klse.raw,
          });
        }
        renderWatchlist();
        renderIndices();
        renderTicker();
      }
    } catch (err) {
      console.error(err);
      showApiToast('UNIVERSE WARNING', 'Using embedded fallback watchlist because universe API failed');
    }
  }

  async function loadCommoditiesAndFx() {
    try {
      const [com, fx] = await Promise.all([apiGet('/api/commodities/latest'), apiGet('/api/fx/latest')]);
      liveCommodities = com.rows || [];
      liveCommodityReferences = com.references || [];
      liveFx = fx.rows || [];
      liveFxOfficialSources = fx.official_sources || [];
      DATA.fx.splice(0, DATA.fx.length, ...liveFx.map(x => ({
        pair: x.pair || x.symbol,
        bid: Number(x.price || x.close || 0),
        ask: Number(x.price || x.close || 0),
        chg: Number(x.change_percent || 0),
        high: Number(x.high || x.price || 0),
        low: Number(x.low || x.price || 0),
        source_api: x.source_api,
      })));
      renderTopMarkets();
      renderFXPage();
    } catch (err) {
      console.error(err);
      showApiToast('FX/COMMODITY WARNING', 'Some commodity or FX feeds failed');
    }
  }

  async function loadFinancials(symbol, silent) {
    try {
      const fin = await apiGet(`/api/financials?symbol=${encodeURIComponent(normalizeInputSymbol(symbol))}`);
      liveFinancialRows = fin.rows || [];
      if (!silent) showApiToast('FINANCIALS', `${liveFinancialRows.length} statement rows loaded`);
    } catch (err) {
      liveFinancialRows = [];
      if (!silent) showApiToast('FINANCIALS WARNING', err.message || 'No financial statement data');
    }
  }

  async function loadLogs() {
    try {
      const logs = await apiGet('/api/ingestion/logs?limit=50');
      liveLogs = logs.rows || [];
      setStatus('LIVE API / FALLBACK', 'connected');
    } catch (_) {
      liveLogs = [];
    }
  }
  async function loadSourceStatus() {
    try {
      const data = await apiGet('/api/sources/status');
      liveApiSources = data.rows || [];
      renderSourceStatusPanel();
    } catch (err) {
      liveApiSources = [];
      console.warn('source status failed', err);
    }
  }

  function renderSourceStatusPanel() {
    const el = document.getElementById('econCalBody');
    if (!el) return;
    const sources = liveApiSources.slice(0, 14);
    const rows = sources.map(s => {
      const ok = s.configured === true || s.status.includes('public') || s.status.includes('reference') || s.source_api === 'yfinance_yahoo';
      return `<div style="padding:3px 6px;border-bottom:1px solid #0d0d0d;display:grid;grid-template-columns:78px 1fr 42px;gap:6px;align-items:center;">
        <span style="color:var(--accent-orange);font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${s.source_api}</span>
        <span style="color:#999;font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${s.used_for}">${s.used_for}</span>
        <span class="badge ${ok ? 'badge-up' : 'badge-neu'}">${ok ? 'ON' : 'KEY'}</span>
      </div>`;
    }).join('');
    const refCount = liveCommodityReferences.length + liveFxOfficialSources.length;
    el.innerHTML = `<div style="padding:3px 6px;color:var(--accent-orange);font-size:9px;border-bottom:1px solid #1a1a1a;letter-spacing:1px;">API SOURCE STATUS | REF ${refCount}</div>` + rows;
  }

  async function refreshOfficialReferences() {
    try {
      await Promise.allSettled([
        apiGet('/api/commodities/fcpo/references'),
        apiGet('/api/commodities/palm-oil/fundamentals'),
      ]);
      showApiToast('REFERENCE FEEDS', 'FCPO/Bursa/MPOB reference endpoints refreshed and stored');
    } catch (err) {
      showApiToast('REFERENCE WARNING', err.message || 'Unable to refresh reference feeds');
    }
  }

  window.renderTopMarkets = function renderTopMarketsLive() {
    const el = document.getElementById('topMarkets');
    if (!el) return;
    const klci = (DATA.indices || [])[0];
    const wti = liveCommodities.find(x => x.symbol === 'CL=F');
    const brent = liveCommodities.find(x => x.symbol === 'BZ=F');
    const fcpo = liveCommodities.find(x => x.symbol === 'PO=F');
    const usdm = liveFx.find(x => x.pair === 'USD/MYR' || x.symbol === 'MYR=X');
    const sgdm = liveFx.find(x => x.pair === 'SGD/MYR' || x.symbol === 'SGDMYR=X');
    const items = [
      klci && { sym: 'KLCI', val: money(klci.price), chg: pct(klci.chg), up: Number(klci.chg) >= 0 },
      wti && { sym: 'WTI', val: money(wti.price), chg: pct(wti.change_percent), up: Number(wti.change_percent) >= 0 },
      brent && { sym: 'BRENT', val: money(brent.price), chg: pct(brent.change_percent), up: Number(brent.change_percent) >= 0 },
      fcpo && { sym: 'FCPO*', val: money(fcpo.price), chg: pct(fcpo.change_percent), up: Number(fcpo.change_percent) >= 0 },
      usdm && { sym: 'USD/MYR', val: money(usdm.price, 4), chg: pct(usdm.change_percent), up: Number(usdm.change_percent) >= 0 },
      sgdm && { sym: 'SGD/MYR', val: money(sgdm.price, 4), chg: pct(sgdm.change_percent), up: Number(sgdm.change_percent) >= 0 },
    ].filter(Boolean);
    if (!items.length && original.renderTopMarkets) return original.renderTopMarkets();
    el.innerHTML = items.map(i => `<div class="market-item"><span class="sym">${i.sym}</span><span class="val">${i.val}</span><span class="chg ${i.up ? 'up' : 'dn'}">${i.chg}</span></div>`).join('');
  };

  window.selectSecurity = function selectSecurityLive(sym, el) {
    document.querySelectorAll('.ticker-row').forEach(r => r.classList.remove('selected'));
    if (el) el.classList.add('selected');
    loadSecurity(sym);
  };

  window.drawChart = function drawLiveChart() {
    if (!liveCandles || liveCandles.length < 2) {
      if (original.drawChart) return original.drawChart();
      return;
    }
    const canvas = document.getElementById('chartCanvas');
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height - 80;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const W = canvas.width, H = canvas.height;
    const pad = { top: 20, right: 64, bottom: 30, left: 12 };
    const cW = W - pad.left - pad.right;
    const cH = H - pad.top - pad.bottom;
    const raw = liveCandles.filter(c => Number.isFinite(Number(c.close)));
    const maxBars = Math.min(raw.length, chartTimeframe === '1D' ? 160 : 260);
    const candles = raw.slice(-maxBars).map(c => ({
      open: Number(c.open ?? c.close), high: Number(c.high ?? c.close), low: Number(c.low ?? c.close), close: Number(c.close), volume: Number(c.volume || 0), event_time: c.event_time,
    }));
    const prices = candles.flatMap(c => [c.high, c.low]).filter(Number.isFinite);
    const minP = Math.min(...prices), maxP = Math.max(...prices);
    const range = Math.max(maxP - minP, 0.0001);
    const scaleY = p => pad.top + cH - ((p - minP) / range) * cH;
    const barW = cW / candles.length;
    ctx.strokeStyle = 'rgba(255,102,0,0.08)';
    for (let i = 0; i <= 5; i++) {
      const y = pad.top + (cH / 5) * i;
      ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke();
      const pVal = maxP - (range / 5) * i;
      ctx.fillStyle = '#555'; ctx.font = '9px "Share Tech Mono"'; ctx.textAlign = 'right'; ctx.fillText(money(pVal), W - 2, y + 3);
    }
    if (chartType === 'line' || chartType === 'area') {
      ctx.beginPath();
      candles.forEach((c, i) => {
        const x = pad.left + i * barW + barW / 2;
        i === 0 ? ctx.moveTo(x, scaleY(c.close)) : ctx.lineTo(x, scaleY(c.close));
      });
      ctx.strokeStyle = chartType === 'line' ? 'rgba(0,170,255,0.95)' : 'rgba(0,255,65,0.9)';
      ctx.lineWidth = 1.5; ctx.stroke();
    } else {
      const candleW = Math.max(barW * 0.65, 1);
      candles.forEach((c, i) => {
        const x = pad.left + i * barW;
        const up = c.close >= c.open;
        ctx.fillStyle = up ? '#00ff41' : '#ff2233';
        ctx.strokeStyle = up ? '#00ff41' : '#ff2233';
        ctx.beginPath(); ctx.moveTo(x + barW / 2, scaleY(c.high)); ctx.lineTo(x + barW / 2, scaleY(c.low)); ctx.stroke();
        const top = Math.min(scaleY(c.open), scaleY(c.close));
        const h = Math.abs(scaleY(c.open) - scaleY(c.close)) || 1;
        if (chartType === 'bar') {
          ctx.beginPath(); ctx.moveTo(x, scaleY(c.open)); ctx.lineTo(x + barW / 2, scaleY(c.open)); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(x + barW / 2, scaleY(c.close)); ctx.lineTo(x + barW, scaleY(c.close)); ctx.stroke();
        } else {
          ctx.fillRect(x + (barW - candleW) / 2, top, candleW, h);
        }
      });
    }
    const maxVol = Math.max(...candles.map(c => c.volume || 0), 1);
    const volH = 28;
    candles.forEach((c, i) => {
      const x = pad.left + i * barW;
      const up = c.close >= c.open;
      ctx.fillStyle = up ? 'rgba(0,255,65,0.18)' : 'rgba(255,34,51,0.18)';
      ctx.fillRect(x, H - pad.bottom - (c.volume / maxVol) * volH, Math.max(barW * 0.8, 1), (c.volume / maxVol) * volH);
    });
    const last = candles[candles.length - 1].close;
    const py = scaleY(last);
    ctx.setLineDash([2, 4]); ctx.strokeStyle = 'rgba(255,170,0,0.55)';
    ctx.beginPath(); ctx.moveTo(pad.left, py); ctx.lineTo(W - pad.right - 40, py); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#111'; ctx.strokeStyle = '#ffaa00';
    ctx.fillRect(W - pad.right - 40, py - 7, 39, 14); ctx.strokeRect(W - pad.right - 40, py - 7, 39, 14);
    ctx.fillStyle = '#ffaa00'; ctx.font = '8px "Share Tech Mono"'; ctx.textAlign = 'center'; ctx.fillText(money(last), W - pad.right - 20, py + 3);
  };

  window.setTimeframe = function setTimeframeLive(tf, btn) {
    window.chartTimeframe = tf;
    chartTimeframe = tf;
    document.querySelectorAll('.chart-btn').forEach(b => {
      if (['1D', '5D', '1M', '3M', '1Y', '5Y'].includes(b.textContent)) b.classList.remove('active');
    });
    if (btn) btn.classList.add('active');
    fetchHistory(currentSymbol, tf).then(() => drawChart()).catch(err => showApiToast('HISTORY ERROR', err.message));
  };

  window.renderStats = function renderStatsLive() {
    const el = document.getElementById('statsBody');
    if (!el) return;
    const q = liveQuote || {};
    const fields = [
      ['Name', q.name || q.longName || q.shortName || currentSymbol],
      ['Source', q.source_api || '--'],
      ['Currency', q.currency || 'MYR'],
      ['Open', money(q.open)],
      ['High', money(q.high)],
      ['Low', money(q.low)],
      ['Previous Close', money(q.previous_close)],
      ['Volume', vol(q.volume)],
      ['Sector', q.sector || '--'],
      ['Industry', q.industry || '--'],
      ['Market Cap', q.marketCap ? vol(q.marketCap) : '--'],
      ['P/E', q.trailingPE ? money(q.trailingPE) : '--'],
      ['Dividend Yield', q.dividendYield ? pct(Number(q.dividendYield) * 100) : '--'],
      ['Known At', q.known_at_time || q.ingestion_time || '--'],
    ];
    el.innerHTML = fields.map(([k, v]) => `<div class="sat-data-row"><span class="sat-data-label">${k}</span><span class="sat-data-value">${v}</span></div>`).join('') +
      `<div style="margin-top:8px;color:#665500;font-size:9px;line-height:1.4;">${q.warning || 'Yahoo/yfinance data can be delayed or incomplete. FCPO proxy is labelled when used.'}</div>`;
  };

  window.renderEquityPage = function renderEquityPageLive() {
    const el = document.getElementById('equityTableBody');
    if (!el) return;
    const rows = (DATA.watchlist || []).map(d => ({ ...d, name: d.name || d.sym }));
    let html = `<table class="data-table"><thead><tr><th>SYM</th><th>NAME</th><th>PRICE</th><th>CHG%</th><th>VOL</th><th>SECTOR</th><th>SOURCE</th><th>WARNING</th></tr></thead><tbody>`;
    html += rows.map(d => `<tr onclick="loadSecurity('${d.sym}')" style="cursor:pointer;"><td style="color:var(--accent-orange);">${d.sym}</td><td>${d.name}</td><td>${money(d.price)}</td><td class="${d.chg >= 0 ? 'up' : 'dn'}">${pct(d.chg)}</td><td>${d.vol || '--'}</td><td>${d.sector || '--'}</td><td>${d.source_api || '--'}</td><td style="color:#665500;">${d.warning ? 'delayed/unofficial' : ''}</td></tr>`).join('');
    html += `</tbody></table>`;
    el.innerHTML = html;
    const side = document.getElementById('fundamentalsBody');
    if (side) {
      const sample = liveFinancialRows.slice(0, 12);
      side.innerHTML = `<div class="eq-label">FINANCIAL STATEMENTS</div><div style="font-size:9px;color:#665500;margin-bottom:6px;">${currentSymbol} | ${sample.length ? 'API loaded' : 'No statement rows loaded'}</div>` +
        sample.map(r => `<div class="sat-data-row"><span class="sat-data-label">${String(r.metric || '').slice(0, 22)}</span><span class="sat-data-value">${money(r.value, 0)}</span></div>`).join('');
    }
  };

  window.renderFXPage = function renderFXPageLive() {
    const el = document.getElementById('fxTableBody');
    if (!el) return;
    if (!DATA.fx || DATA.fx.length === 0) {
      if (original.renderFXPage) return original.renderFXPage();
      return;
    }
    let html = `<table class="data-table"><thead><tr><th>PAIR</th><th>BID</th><th>ASK</th><th>CHG%</th><th>HIGH</th><th>LOW</th><th>SOURCE</th></tr></thead><tbody>`;
    html += DATA.fx.map(f => `<tr><td style="color:var(--accent-orange);">${f.pair}</td><td>${money(f.bid, 4)}</td><td>${money(f.ask, 4)}</td><td class="${f.chg >= 0 ? 'up' : 'dn'}">${pct(f.chg)}</td><td>${money(f.high, 4)}</td><td>${money(f.low, 4)}</td><td>${f.source_api || 'api'}</td></tr>`).join('');
    html += `</tbody></table>`;
    el.innerHTML = html;
  };

  window.execCmd = function execCmdLive() {
    const input = document.getElementById('cmdInput');
    const raw = input.value.trim();
    const cmd = raw.toUpperCase();
    if (!cmd) return;
    const first = cmd.split(/\s+/)[0];
    if (['API', 'SOURCES', 'SRC'].includes(first)) {
      input.value = '';
      loadSourceStatus().then(() => showApiToast('API SOURCES', `${liveApiSources.length} provider routes loaded`));
      return;
    }
    if (['FCPO', 'PALM', 'MPOB'].includes(first)) {
      input.value = '';
      refreshOfficialReferences();
      return;
    }
    if (COMMANDS[first]) {
      if (original.execCmd) return original.execCmd();
      return;
    }
    const symbol = normalizeInputSymbol(first);
    input.value = '';
    loadSecurity(symbol);
  };

  window.refreshAll = async function refreshAllLive() {
    showApiToast('REFRESH', 'Refreshing live API feeds...');
    await loadAllLive();
  };

  async function loadAllLive() {
    stopDemoMotion();
    setStatus('LIVE API / FALLBACK', 'loading');
    await loadUniverse();
    await loadCommoditiesAndFx();
    await loadLogs();
    await loadSourceStatus();
    await loadSecurity(currentSymbol, true);
    renderTopMarkets();
    renderTicker();
    setStatus('LIVE API / FALLBACK', 'connected');
  }

  window.loadSecurity = loadSecurity;
  window.__malaysiaTerminalApi = { loadAllLive, loadSecurity, apiGet, loadSourceStatus, refreshOfficialReferences };

  window.addEventListener('load', () => {
    setTimeout(() => {
      const user = document.querySelector('.top-user');
      if (user) user.textContent = 'MALAYSIA MARKET TERMINAL | API CONNECTED | DELAY WARNINGS ENABLED';
      showApiToast('API BRIDGE', 'Connecting Bloomberg-style UI to Malaysia live-data backend');
      loadAllLive().catch(err => {
        console.error(err);
        setStatus('API FALLBACK', 'offline');
        showApiToast('BACKEND ERROR', 'Start FastAPI backend: uvicorn backend.api_server:app --reload');
      });
    }, 450);
  });
})();
