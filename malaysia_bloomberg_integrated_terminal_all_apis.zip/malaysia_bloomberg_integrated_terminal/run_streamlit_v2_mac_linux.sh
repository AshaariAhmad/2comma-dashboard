#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/streamlit_v2"
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
streamlit run app.py
