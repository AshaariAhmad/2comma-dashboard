# Malaysia Bloomberg-Style Integrated Terminal

This package integrates your uploaded Bloomberg-style HTML terminal frontend with a real Python/FastAPI backend and the complete Malaysia Market Terminal v2 data pipeline.

The design from `frontend/index.original.html` is preserved. The new file `frontend/index.html` only adds a live API bridge script and accurate source/status labels.

## What is included

```text
malaysia_bloomberg_integrated_terminal/
├── frontend/
│   ├── index.html              # Your Bloomberg-style UI + live API bridge script injected
│   ├── index.original.html     # Original uploaded design kept unchanged
│   └── live_api_bridge.js      # Adds live data wiring without redesigning UI
├── backend/
│   ├── api_server.py           # FastAPI backend serving frontend + APIs
│   ├── data_fetchers.py        # Live/near-live fetchers from Malaysia Market Terminal v2
│   ├── storage.py              # raw → bronze → silver → gold storage
│   └── catalog_manager.py      # catalog helper
├── catalog/
│   ├── sources.yaml
│   ├── datasets.yaml
│   ├── columns.csv
│   └── seed_bursa_tickers.csv
├── data_store/
│   ├── raw/
│   ├── bronze/
│   ├── silver/
│   ├── gold/
│   ├── latest/
│   └── logs/
├── streamlit_v2/               # Complete previous Streamlit v2 terminal preserved
├── requirements.txt
├── .env.example
├── run_windows.bat
├── run_mac_linux.sh
└── README.md
```

## What it fetches

No live values are hardcoded by the backend.

- Bursa Malaysia `.KL` stocks using yfinance/Yahoo fallback
- FTSE Bursa Malaysia KLCI using `^KLSE`
- WTI crude oil futures using `CL=F`
- Brent crude oil futures using `BZ=F`
- Palm oil / FCPO proxy using `PO=F`, clearly labelled as proxy/unofficial
- USD/MYR, SGD/MYR, EUR/MYR, GBP/MYR using Yahoo/yfinance fallback
- Financial statements from yfinance/Yahoo when available
- Optional Twelve Data Bursa/XKLS universe and fundamentals if API key is supplied
- Optional EIA crude oil source if API key is supplied
- Optional BNM exchange-rate metadata is attempted by the backend

## How to run on Windows

1. Extract the ZIP.
2. Open the folder.
3. Double-click:

```text
run_windows.bat
```

Or run manually:

```bash
cd malaysia_bloomberg_integrated_terminal
python -m pip install -r requirements.txt
python -m uvicorn backend.api_server:app --host 0.0.0.0 --port 8000 --reload
```

Then open Chrome:

```text
http://127.0.0.1:8000
```

## How to open from Android Chrome

Your phone and laptop must be on the same Wi-Fi.

On the laptop, run:

```bash
python -m uvicorn backend.api_server:app --host 0.0.0.0 --port 8000 --reload
```

Find your laptop local IP address, for example:

```text
192.168.1.25
```

Open this on Android Chrome:

```text
http://192.168.1.25:8000
```

## Commands in the terminal UI

Try these in the command bar:

```text
1155.KL
1295.KL
1023.KL
5347.KL
^KLSE
WTI
BRENT
FCPO
```

You can also type only the Bursa code:

```text
1155
1295
5347
```

The bridge normalizes those into `.KL` tickers.

## Backend API endpoints

```text
GET /api/health
GET /api/universe
GET /api/universe?refresh=true
GET /api/market/latest?symbol=1155.KL
GET /api/market/history?symbol=1155.KL&period=1mo&interval=1d
GET /api/financials?symbol=1155.KL
GET /api/commodities/latest
GET /api/fx/latest
GET /api/ingestion/logs
GET /api/catalog/columns
GET /api/catalog/sources
GET /api/query?sql=SELECT%20*%20FROM%20v_silver%20LIMIT%205
```

## Data architecture

Every successful API fetch is stored into:

```text
raw API response → bronze parquet → silver parquet → gold parquet
```

Required timestamp/metadata columns are added where available:

```text
event_time
ingestion_time
known_at_time
source_api
symbol
asset
timeframe
raw_file_path
ingestion_batch_id
```

## Important limitations

- This is not an official Bloomberg replacement.
- Yahoo/yfinance data can be delayed, missing, or incomplete.
- FCPO data is marked as proxy/unofficial unless you connect a licensed/official feed.
- The seed Bursa list is not a complete Bursa universe.
- Full Bursa universe requires a reliable provider, such as Twelve Data XKLS, with API key and coverage.

## Optional API keys

Copy `.env.example` to `.env`:

```bash
copy .env.example .env
```

Then fill:

```text
TWELVE_DATA_API_KEY=your_key_here
EIA_API_KEY=your_key_here
```

Restart the server after editing `.env`.

## Streamlit v2 preserved

The previous complete Streamlit v2 terminal is preserved inside:

```text
streamlit_v2/
```

Run it separately with:

```text
run_streamlit_v2_windows.bat
```

This integrated package gives you both:

1. Your Bloomberg-style HTML frontend.
2. The complete Malaysia Market Terminal v2 backend/data pipeline.

## Extended APIs added

This version adds the previously left-out catalog sources without changing the Bloomberg-style frontend design:

- Twelve Data `/time_series` through `/api/market/history?provider=twelve_data`
- Twelve Data `/profile` through `/api/market/profile?provider=twelve_data`
- FMP profile and financial statements through `/api/market/profile?provider=fmp` and `/api/financials?provider=fmp`
- EIA WTI/Brent official spot rows through `/api/commodities/latest` when `EIA_API_KEY` is set
- BNM multi-currency attempts plus data.gov.my daily exchange rates through `/api/fx/latest`
- MPOB BEPI reference metadata through `/api/commodities/palm-oil/fundamentals`
- Bursa FCPO contract specs, Bursa derivatives price page metadata, Investing.com FCPO reference, and licensed vendor placeholder through `/api/commodities/fcpo/references`
- API source status through `/api/sources/status`

Frontend commands added without changing layout:

```text
API
SOURCES
SRC
FCPO
PALM
MPOB
```

These commands refresh/show source status or FCPO/palm-oil references in the existing panels.
