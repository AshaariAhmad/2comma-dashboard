"""Malaysia DIY Bloomberg-style Market Terminal.

Run:
    streamlit run app.py

This app fetches live/near-live market data where possible, stores it locally as
raw JSON + Parquet, and documents the data through CSV/YAML catalog files.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

from catalog_manager import CatalogManager
from data_fetchers import MarketDataFetcher, FetchResult, normalize_bursa_symbol
from storage import MarketStorage


# -----------------------------------------------------------------------------
# App setup
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

st.set_page_config(
    page_title="Malaysia Market Terminal",
    page_icon="📈",
    layout="wide",
)

storage = MarketStorage(root_dir=BASE_DIR / "data_store", duckdb_path=BASE_DIR / "market_terminal.duckdb")
catalog = CatalogManager(catalog_dir=BASE_DIR / "catalog")

API_TIMEOUT_SECONDS = int(os.getenv("API_TIMEOUT_SECONDS", "20") or "20")
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "300") or "300")

fetcher = MarketDataFetcher(
    twelve_data_api_key=os.getenv("TWELVE_DATA_API_KEY", ""),
    eia_api_key=os.getenv("EIA_API_KEY", ""),
    timeout_seconds=API_TIMEOUT_SECONDS,
)


# -----------------------------------------------------------------------------
# Seed watchlist. This is not a complete universe.
# -----------------------------------------------------------------------------
SEED_TICKERS = {
    "Maybank": "1155.KL",
    "Public Bank": "1295.KL",
    "CIMB": "1023.KL",
    "Tenaga Nasional": "5347.KL",
    "Petronas Chemicals": "5183.KL",
    "IHH Healthcare": "5225.KL",
    "KLCI Index": "^KLSE",
}

COMMODITY_SYMBOLS = {
    "WTI crude oil futures — Yahoo fallback": "CL=F",
    "Brent crude oil futures — Yahoo fallback": "BZ=F",
    "Palm oil futures proxy — Yahoo PO=F, unofficial/proxy": "PO=F",
    "FTSE Bursa Malaysia Palm Oil Plantation Index proxy — not FCPO": "FBMPM.FGI",
}

FX_SYMBOLS = {
    "USD/MYR — Yahoo fallback": "MYR=X",
    "SGD/MYR — Yahoo fallback": "SGDMYR=X",
    "EUR/MYR — Yahoo fallback": "EURMYR=X",
    "GBP/MYR — Yahoo fallback": "GBPMYR=X",
}


# -----------------------------------------------------------------------------
# Cached fetch wrappers
# -----------------------------------------------------------------------------
@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_yfinance_history(symbol: str, period: str, interval: str, dataset_type: str, note: str) -> FetchResult:
    return fetcher.fetch_yfinance_history(symbol=symbol, period=period, interval=interval, dataset_type=dataset_type, note=note)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_yfinance_profile(symbol: str) -> FetchResult:
    return fetcher.fetch_yfinance_quote_info(symbol=symbol)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_yfinance_financials(symbol: str) -> FetchResult:
    return fetcher.fetch_yfinance_financials(symbol=symbol)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_twelve_universe() -> FetchResult:
    return fetcher.fetch_twelve_data_universe()


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_twelve_financials(symbol: str) -> FetchResult:
    return fetcher.fetch_twelve_data_financials(symbol=symbol)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_eia_crude(benchmark: str) -> FetchResult:
    return fetcher.fetch_eia_crude_spot(benchmark=benchmark)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_bnm_fx(currency: str) -> FetchResult:
    return fetcher.fetch_bnm_exchange_rate(currency)


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_data_gov_fx() -> FetchResult:
    return fetcher.fetch_data_gov_my_exchange_rates()


@st.cache_data(ttl=CACHE_TTL_SECONDS, show_spinner=False)
def cached_mpob_overview() -> FetchResult:
    return fetcher.fetch_mpob_overview_page()


# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------
def save_and_catalog(result: FetchResult, layer: str = "silver", dataset_prefix: str = "dataset") -> None:
    """Save successful or failed fetch result to storage and update catalog for dataframes."""
    dataset_name = f"{dataset_prefix}_{result.asset}_{result.timeframe}".replace("=", "_").replace("^", "")
    save_info = storage.save_fetch_result(result, layer=layer, dataset_name=dataset_name)
    if result.dataframe is not None and not result.dataframe.empty:
        catalog.register_dataset(
            dataset_name=dataset_name,
            description=f"{result.dataset_type} fetched from {result.source_api} for {result.symbol}.",
            path_pattern=f"data_store/{layer}/{result.source_api}/{result.asset}/{result.symbol}/{result.timeframe}/**/*.parquet",
            grain="one row per event_time and symbol where applicable",
            primary_key=["event_time", "symbol"],
            source_api=result.source_api,
            status="active",
        )
        catalog.register_columns_from_df(
            df=result.dataframe,
            dataset_name=dataset_name,
            source_api=result.source_api,
            asset=result.asset,
            frequency=result.timeframe,
            raw_or_feature="raw_or_cleaned",
        )
    if save_info.get("parquet_file"):
        st.caption(f"Saved: `{save_info['parquet_file']}`")
    else:
        st.caption("No parquet saved because the dataframe was empty or the fetch failed.")


def show_fetch_status(result: FetchResult) -> None:
    if result.ok:
        st.success(result.message)
    else:
        st.warning(result.message)
    with st.expander("Source metadata / warning", expanded=False):
        st.write(
            {
                "source_api": result.source_api,
                "symbol": result.symbol,
                "asset": result.asset,
                "timeframe": result.timeframe,
                "dataset_type": result.dataset_type,
                "request_url": result.request_url,
                **result.metadata,
            }
        )


def price_cards(df: pd.DataFrame, symbol: str) -> None:
    if df is None or df.empty or "close" not in df.columns:
        st.info("No OHLCV data available for price cards.")
        return
    data = df.dropna(subset=["close"]).copy()
    if data.empty:
        st.info("No valid close prices available.")
        return
    last = data.iloc[-1]
    prev_close = data["close"].iloc[-2] if len(data) > 1 else None
    close = float(last["close"])
    change = close - float(prev_close) if prev_close is not None else 0.0
    change_pct = (change / float(prev_close) * 100.0) if prev_close not in [None, 0] else 0.0
    volume = last.get("volume", None)
    event_time = last.get("event_time", "")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric(f"{symbol} latest close", f"{close:,.4f}", f"{change_pct:+.2f}%")
    c2.metric("Point change", f"{change:+,.4f}")
    c3.metric("Volume", "N/A" if pd.isna(volume) else f"{float(volume):,.0f}")
    c4.metric("Latest event time", str(event_time)[:19])


def plot_ohlcv(df: pd.DataFrame, title: str) -> None:
    if df is None or df.empty or not {"event_time", "open", "high", "low", "close"}.issubset(df.columns):
        st.info("Not enough OHLC data to draw a candlestick chart.")
        return
    plot_df = df.dropna(subset=["event_time", "close"]).copy()
    fig = go.Figure(
        data=[
            go.Candlestick(
                x=plot_df["event_time"],
                open=plot_df["open"],
                high=plot_df["high"],
                low=plot_df["low"],
                close=plot_df["close"],
                name="OHLC",
            )
        ]
    )
    fig.update_layout(title=title, height=520, xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)


def show_dataframe(df: pd.DataFrame, label: str, max_rows: int = 500) -> None:
    st.subheader(label)
    if df is None or df.empty:
        st.info("No rows available.")
    else:
        st.dataframe(df.tail(max_rows), use_container_width=True)


# -----------------------------------------------------------------------------
# Main UI
# -----------------------------------------------------------------------------
st.title("🇲🇾 Malaysia DIY Bloomberg-Style Market Terminal")
st.caption(
    "Educational market-data terminal. Values come from APIs or local Parquet storage; no hardcoded prices, ratios, or market caps are used."
)
st.warning(
    "Data may be delayed, incomplete, unofficial, or unavailable depending on the source. This is not investment advice."
)

with st.sidebar:
    st.header("Controls")
    period = st.selectbox("History period", ["5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "max"], index=4)
    interval = st.selectbox("Interval", ["1m", "5m", "15m", "30m", "1h", "1d", "1wk", "1mo"], index=5)
    st.caption("Yahoo/yfinance limits which interval works with each period.")
    if st.button("Clear API cache"):
        st.cache_data.clear()
        st.success("Cache cleared. Next fetch will call the APIs again.")
    st.divider()
    st.write("Optional API key status")
    st.write({
        "TWELVE_DATA_API_KEY": "set" if os.getenv("TWELVE_DATA_API_KEY") else "not set",
        "EIA_API_KEY": "set" if os.getenv("EIA_API_KEY") else "not set",
    })


tab_equity, tab_financials, tab_commodities, tab_fx, tab_catalog = st.tabs(
    ["Equities & KLCI", "Financial Statements", "Crude / FCPO / Palm Oil", "Macro & FX", "Ingestion / Catalog / SQL"]
)

# -----------------------------------------------------------------------------
# Equities tab
# -----------------------------------------------------------------------------
with tab_equity:
    st.header("Bursa Malaysia equities and KLCI")
    st.info("Seed tickers are only a demo/watchlist, not a complete Bursa universe. Use Twelve Data universe fetch if you add an API key.")

    c1, c2 = st.columns([2, 1])
    with c1:
        selected_name = st.selectbox("Demo watchlist", list(SEED_TICKERS.keys()), index=0)
    with c2:
        typed_symbol = st.text_input("Ticker", value=SEED_TICKERS[selected_name], help="Examples: 1155.KL, 1295.KL, ^KLSE")
    symbol = normalize_bursa_symbol(typed_symbol)

    if st.button("Fetch selected equity/index data", type="primary"):
        result = cached_yfinance_history(
            symbol=symbol,
            period=period,
            interval=interval,
            dataset_type="equity_or_index_price_history",
            note="Yahoo/yfinance fallback for Bursa .KL tickers and ^KLSE. Data may be delayed.",
        )
        show_fetch_status(result)
        save_and_catalog(result, layer="silver", dataset_prefix="equity_price")
        if result.ok:
            price_cards(result.dataframe, result.symbol)
            plot_ohlcv(result.dataframe, f"{result.symbol} OHLCV")
            show_dataframe(result.dataframe, "OHLCV table")

    st.subheader("Optional: fetch Bursa/XKLS universe from Twelve Data")
    if st.button("Fetch Twelve Data Bursa universe"):
        universe_result = cached_twelve_universe()
        show_fetch_status(universe_result)
        save_and_catalog(universe_result, layer="bronze", dataset_prefix="bursa_universe")
        show_dataframe(universe_result.dataframe, "Twelve Data Bursa/XKLS universe")

# -----------------------------------------------------------------------------
# Financial statements tab
# -----------------------------------------------------------------------------
with tab_financials:
    st.header("Company profile and financial statements")
    fin_symbol = normalize_bursa_symbol(st.text_input("Financial statement ticker", value="1155.KL"))
    col_a, col_b = st.columns(2)

    with col_a:
        if st.button("Fetch profile/quote snapshot"):
            profile_result = cached_yfinance_profile(fin_symbol)
            show_fetch_status(profile_result)
            save_and_catalog(profile_result, layer="silver", dataset_prefix="company_profile")
            show_dataframe(profile_result.dataframe, "Profile / quote snapshot")

    with col_b:
        if st.button("Fetch financial statements"):
            yf_result = cached_yfinance_financials(fin_symbol)
            show_fetch_status(yf_result)
            save_and_catalog(yf_result, layer="silver", dataset_prefix="financials_yfinance")
            show_dataframe(yf_result.dataframe, "Yahoo/yfinance financial statement rows")

            td_result = cached_twelve_financials(fin_symbol)
            show_fetch_status(td_result)
            save_and_catalog(td_result, layer="bronze", dataset_prefix="financials_twelvedata")
            if td_result.ok:
                show_dataframe(td_result.dataframe, "Twelve Data financial statement rows")

# -----------------------------------------------------------------------------
# Commodities tab
# -----------------------------------------------------------------------------
with tab_commodities:
    st.header("WTI, Brent, FCPO proxy, and palm oil fundamentals")
    st.warning("FCPO live prices may not be freely available through a stable official public API. Proxy sources are clearly labelled.")

    commodity_choice = st.selectbox("Commodity source", list(COMMODITY_SYMBOLS.keys()), index=0)
    commodity_symbol = COMMODITY_SYMBOLS[commodity_choice]

    if st.button("Fetch Yahoo commodity/proxy data", type="primary"):
        is_proxy_note = "This is a proxy/unofficial commodity source, not official FCPO settlement data." if "proxy" in commodity_choice.lower() or commodity_symbol in {"PO=F", "FBMPM.FGI"} else "Yahoo/yfinance commodity futures fallback."
        result = cached_yfinance_history(
            symbol=commodity_symbol,
            period=period,
            interval=interval,
            dataset_type="commodity_price_history",
            note=is_proxy_note,
        )
        if result.dataframe is not None and not result.dataframe.empty and commodity_symbol in {"PO=F", "FBMPM.FGI"}:
            result.dataframe["is_proxy"] = True
            result.dataframe["data_delay_warning"] = is_proxy_note
        show_fetch_status(result)
        save_and_catalog(result, layer="silver", dataset_prefix="commodity_price")
        if result.ok:
            price_cards(result.dataframe, result.symbol)
            plot_ohlcv(result.dataframe, f"{commodity_choice}")
            show_dataframe(result.dataframe, "Commodity/proxy OHLCV table")

    st.subheader("Optional official EIA crude spot data")
    eia_choice = st.selectbox("EIA benchmark", ["WTI", "BRENT"], index=0)
    if st.button("Fetch EIA crude spot data"):
        eia_result = cached_eia_crude(eia_choice)
        show_fetch_status(eia_result)
        save_and_catalog(eia_result, layer="silver", dataset_prefix="eia_crude_spot")
        if eia_result.ok:
            price_cards(eia_result.dataframe, eia_result.symbol)
            show_dataframe(eia_result.dataframe, "EIA crude spot price table")

    st.subheader("MPOB palm oil fundamentals page")
    if st.button("Fetch MPOB BEPI overview"):
        mpob_result = cached_mpob_overview()
        show_fetch_status(mpob_result)
        save_and_catalog(mpob_result, layer="bronze", dataset_prefix="mpob_palm_oil")
        show_dataframe(mpob_result.dataframe, "MPOB overview metadata")

# -----------------------------------------------------------------------------
# Macro & FX tab
# -----------------------------------------------------------------------------
with tab_fx:
    st.header("Macro and MYR FX")
    fx_choice = st.selectbox("Yahoo FX fallback", list(FX_SYMBOLS.keys()), index=0)
    fx_symbol = FX_SYMBOLS[fx_choice]

    if st.button("Fetch Yahoo FX data", type="primary"):
        fx_result = cached_yfinance_history(
            symbol=fx_symbol,
            period=period,
            interval=interval,
            dataset_type="fx_price_history",
            note="Yahoo/yfinance FX fallback. For official Malaysian reference rates, try BNM/data.gov.my panels below.",
        )
        show_fetch_status(fx_result)
        save_and_catalog(fx_result, layer="silver", dataset_prefix="fx_yfinance")
        if fx_result.ok:
            price_cards(fx_result.dataframe, fx_result.symbol)
            plot_ohlcv(fx_result.dataframe, f"{fx_choice}")
            show_dataframe(fx_result.dataframe, "FX OHLCV table")

    st.subheader("Official / public Malaysia FX sources")
    c1, c2 = st.columns(2)
    with c1:
        bnm_currency = st.selectbox("BNM currency", ["usd", "sgd", "eur", "gbp"], index=0)
        if st.button("Fetch BNM exchange-rate endpoint"):
            bnm_result = cached_bnm_fx(bnm_currency)
            show_fetch_status(bnm_result)
            save_and_catalog(bnm_result, layer="bronze", dataset_prefix="bnm_fx")
            show_dataframe(bnm_result.dataframe, "BNM exchange-rate response")
    with c2:
        if st.button("Fetch data.gov.my exchange-rate dataset"):
            gov_result = cached_data_gov_fx()
            show_fetch_status(gov_result)
            save_and_catalog(gov_result, layer="bronze", dataset_prefix="data_gov_my_fx")
            show_dataframe(gov_result.dataframe, "data.gov.my exchange-rate rows")

# -----------------------------------------------------------------------------
# Ingestion / Catalog / SQL tab
# -----------------------------------------------------------------------------
with tab_catalog:
    st.header("Ingestion logs, catalog, and DuckDB SQL")
    storage.register_latest_views()

    st.subheader("Ingestion log")
    log_df = storage.read_ingestion_log()
    show_dataframe(log_df, "data_store/logs/ingestion_log.csv", max_rows=1000)

    st.subheader("Column catalog")
    columns_df = catalog.load_columns()
    show_dataframe(columns_df, "catalog/columns.csv", max_rows=1000)

    st.subheader("Source catalog")
    st.json(catalog.load_sources())

    st.subheader("Dataset catalog")
    st.json(catalog.load_datasets())

    st.subheader("DuckDB SQL console")
    default_sql = "SELECT * FROM read_parquet('data_store/silver/**/*.parquet', union_by_name=true) LIMIT 100;"
    sql = st.text_area("SQL", value=default_sql, height=120)
    if st.button("Run SQL"):
        try:
            result_df = storage.query_duckdb(sql)
            st.dataframe(result_df, use_container_width=True)
        except Exception as exc:  # noqa: BLE001
            st.error(f"SQL failed: {exc}")
