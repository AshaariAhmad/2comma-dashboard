# Malaysia DIY Bloomberg-Style Market Terminal

A local Streamlit market-data terminal for Malaysian financial markets.

This project is designed to avoid the common mistake of building a static React page with hardcoded stock data. Displayed values are fetched from APIs or loaded from local Parquet storage.

## What it covers

- Bursa Malaysia equities using `.KL` tickers through yfinance/Yahoo fallback
- FTSE Bursa Malaysia KLCI using `^KLSE`
- Company profile and financial statements when available
- WTI crude oil and Brent crude oil
- FCPO / crude palm oil proxies, clearly labelled as proxy/unofficial when not an official live FCPO feed
- MPOB BEPI palm oil fundamentals page metadata
- USD/MYR, SGD/MYR, EUR/MYR, GBP/MYR using yfinance fallback
- Optional BNM and data.gov.my exchange-rate sources
- Optional Twelve Data Bursa/XKLS universe and fundamentals
- Optional EIA official WTI/Brent spot data
- Local raw JSON + Parquet storage
- DuckDB SQL querying
- Ingestion logs
- CSV/YAML data catalog

## Important data limitations

This is not an official Bloomberg replacement.

- yfinance/Yahoo can be delayed, incomplete, or unavailable.
- FCPO free live data may not be available from a stable official public API. The app labels FCPO substitutes as proxies.
- The seed ticker list is only a demo/watchlist. It is not a complete Bursa Malaysia universe.
- A complete Bursa/XKLS universe should be fetched from a real data provider such as Twelve Data when an API key is supplied.
- Do not use `event_time` alone for modelling. Use `known_at_time <= prediction_time` to avoid future leakage.

## Folder structure

```text
malaysia_market_terminal_v2/
├── app.py
├── data_fetchers.py
├── storage.py
├── catalog_manager.py
├── requirements.txt
├── README.md
├── .env.example
├── run_windows.bat
├── run_mac_linux.sh
├── market_terminal.duckdb              # created after running
├── catalog/
│   ├── sources.yaml
│   ├── datasets.yaml
│   ├── columns.csv
│   └── seed_bursa_tickers.csv
└── data_store/
    ├── raw/
    ├── bronze/
    ├── silver/
    ├── gold/
    ├── latest/
    └── logs/
```

## Windows setup

1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Open the project folder.
4. Double-click:

```text
run_windows.bat
```

Or run manually:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
streamlit run app.py
```

## Mac / Linux setup

```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

Or manually:

```bash
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
streamlit run app.py
```

## Optional API keys

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Then fill in optional keys:

```text
TWELVE_DATA_API_KEY=your_key_here
EIA_API_KEY=your_key_here
```

The app works without these keys, but optional providers unlock more data.

## Storage architecture

The app follows this structure:

```text
raw API response → bronze parsed table → silver cleaned table → gold/dashboard table
```

Current implementation:

- Raw JSON responses go to `data_store/raw/`
- Parsed/cleaned Parquet files go to `data_store/bronze/` or `data_store/silver/`
- Latest snapshots go to `data_store/latest/`
- Logs go to `data_store/logs/ingestion_log.csv`

## Required timestamp fields

Every stored dataset attempts to include:

- `event_time`
- `ingestion_time`
- `known_at_time`
- `source_api`
- `symbol`
- `asset`
- `timeframe`
- `raw_file_path`
- `ingestion_batch_id`

## DuckDB examples

After fetching data, go to the SQL tab and try:

```sql
SELECT *
FROM read_parquet('data_store/silver/**/*.parquet', union_by_name=true)
LIMIT 100;
```

Latest saved tables:

```sql
SELECT *
FROM read_parquet('data_store/latest/*.parquet', union_by_name=true)
LIMIT 100;
```

## Common ticker examples

```text
1155.KL  = Maybank
1295.KL  = Public Bank
1023.KL  = CIMB
5347.KL  = Tenaga Nasional
^KLSE    = FTSE Bursa Malaysia KLCI
CL=F     = WTI crude oil futures fallback
BZ=F     = Brent crude oil futures fallback
PO=F     = palm oil futures proxy if Yahoo supports it
MYR=X    = USD/MYR Yahoo fallback
SGDMYR=X = SGD/MYR Yahoo fallback
```

## Anti-hallucination rules implemented

- No hardcoded price, market cap, ISIN, or financial ratio is used as live data.
- Seed tickers are clearly marked as a sample/watchlist, not a complete universe.
- FCPO proxy sources are labelled as proxy/unofficial.
- Optional sources fail gracefully when API keys are missing.
- All fetch attempts are logged.
- The catalog auto-registers columns but marks unknown definitions for manual review.

## Next upgrades

- Add FastAPI backend and React frontend.
- Add licensed Bursa/FCPO feed if available.
- Add Great Expectations checks.
- Add scheduled ingestion through Windows Task Scheduler.
- Add model features in `data_store/gold/` only after anti-leakage rules are validated.

## Extended provider methods available

The Streamlit v2 copy now includes the same extended fetcher/catalog support as the FastAPI backend: Twelve Data time_series/profile, FMP profile/financials, EIA official crude, BNM/data.gov.my FX references, MPOB BEPI, Bursa FCPO references, Investing.com FCPO reference, and licensed FCPO vendor placeholder. The Streamlit UI may expose fewer panels than the Bloomberg HTML UI, but the fetcher and catalog files are included.
