"""Live data fetchers for the Malaysia DIY Bloomberg-style market terminal.

Design rules:
- No invented prices, ratios, or market caps.
- Every API call returns source metadata and timestamps.
- Optional paid/free-key providers are used only when keys are supplied.
- FCPO is treated carefully: if no official live API is available, the app labels the data as proxy/unofficial.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
import json
import os
import time

import pandas as pd
import requests
import yfinance as yf
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


UTC = timezone.utc


def utc_now_iso() -> str:
    """Return current UTC time in ISO-8601 format."""
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def normalize_bursa_symbol(symbol: str) -> str:
    """Normalize Bursa symbols for yfinance.

    Examples:
    - 1155 -> 1155.KL
    - 1155.KL -> 1155.KL
    - ^KLSE -> ^KLSE
    """
    s = str(symbol).strip().upper()
    if not s:
        return s
    if s.startswith("^") or s.endswith("=F") or s.endswith("=X") or "." in s:
        return s
    if s.isdigit():
        return f"{s}.KL"
    return s


def symbol_to_asset(symbol: str) -> str:
    """Create a clean asset label from a market symbol."""
    s = str(symbol).upper().replace(".KL", "").replace("=F", "").replace("=X", "").replace("^", "")
    return s.replace("/", "_").replace("-", "_")


@dataclass
class FetchResult:
    """Standard return object for all fetchers."""

    ok: bool
    source_api: str
    symbol: str
    asset: str
    timeframe: str
    dataset_type: str
    message: str
    request_url: Optional[str] = None
    raw_payload: Any = None
    dataframe: pd.DataFrame = field(default_factory=pd.DataFrame)
    metadata: Dict[str, Any] = field(default_factory=dict)


class MarketDataFetcher:
    """Fetch market, fundamental, commodity, and FX data from supported sources."""

    def __init__(
        self,
        twelve_data_api_key: Optional[str] = None,
        eia_api_key: Optional[str] = None,
        fmp_api_key: Optional[str] = None,
        timeout_seconds: int = 20,
    ) -> None:
        self.twelve_data_api_key = twelve_data_api_key or os.getenv("TWELVE_DATA_API_KEY", "").strip()
        self.eia_api_key = eia_api_key or os.getenv("EIA_API_KEY", "").strip()
        self.fmp_api_key = fmp_api_key or os.getenv("FMP_API_KEY", "").strip()
        self.timeout_seconds = int(timeout_seconds)
        self.session = self._build_session()

    def _build_session(self) -> requests.Session:
        """Create a requests session with conservative retry logic."""
        session = requests.Session()
        retry = Retry(
            total=3,
            connect=3,
            read=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers.update({"User-Agent": "MalaysiaMarketTerminal/1.0"})
        return session

    # ------------------------------------------------------------------
    # Yahoo / yfinance
    # ------------------------------------------------------------------
    def fetch_yfinance_history(
        self,
        symbol: str,
        period: str = "1mo",
        interval: str = "1d",
        dataset_type: str = "price_history",
        note: str = "Yahoo/yfinance delayed or unofficial market data source.",
    ) -> FetchResult:
        """Fetch OHLCV history from yfinance.

        yfinance does not provide an official SLA. We label it as fallback/delayed.
        """
        normalized = normalize_bursa_symbol(symbol)
        ingestion_time = utc_now_iso()
        try:
            ticker = yf.Ticker(normalized)
            hist = ticker.history(period=period, interval=interval, auto_adjust=False, actions=True)
            if hist is None or hist.empty:
                return FetchResult(
                    ok=False,
                    source_api="yfinance_yahoo",
                    symbol=normalized,
                    asset=symbol_to_asset(normalized),
                    timeframe=interval,
                    dataset_type=dataset_type,
                    message=f"No data returned for {normalized}. Try another interval/period or source.",
                    metadata={"provider_note": note, "ingestion_time": ingestion_time},
                )

            df = hist.reset_index()
            # yfinance names the time column Date or Datetime depending on interval.
            first_col = df.columns[0]
            df = df.rename(columns={first_col: "event_time"})
            rename_map = {
                "Open": "open",
                "High": "high",
                "Low": "low",
                "Close": "close",
                "Adj Close": "adj_close",
                "Volume": "volume",
                "Dividends": "dividends",
                "Stock Splits": "stock_splits",
            }
            df = df.rename(columns=rename_map)
            df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
            df = df.dropna(subset=["event_time"]).sort_values("event_time")
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "yfinance_yahoo"
            df["symbol"] = normalized
            df["asset"] = symbol_to_asset(normalized)
            df["timeframe"] = interval
            df["data_delay_warning"] = "Yahoo/yfinance data may be delayed or unavailable for some tickers."
            df["is_proxy"] = False

            raw_payload = {
                "symbol": normalized,
                "period": period,
                "interval": interval,
                "rows": int(len(df)),
                "columns": list(df.columns),
                "provider_note": note,
            }
            return FetchResult(
                ok=True,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe=interval,
                dataset_type=dataset_type,
                message=f"Fetched {len(df):,} rows from yfinance/Yahoo for {normalized}.",
                request_url=f"yfinance://{normalized}?period={period}&interval={interval}",
                raw_payload=raw_payload,
                dataframe=df,
                metadata={"provider_note": note, "ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001 - show readable API failure to user.
            return FetchResult(
                ok=False,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe=interval,
                dataset_type=dataset_type,
                message=f"yfinance fetch failed for {normalized}: {exc}",
                metadata={"provider_note": note, "ingestion_time": ingestion_time, "error": str(exc)},
            )

    def fetch_yfinance_quote_info(self, symbol: str) -> FetchResult:
        """Fetch latest quote metadata from yfinance.

        The returned fields vary by ticker. Missing values are kept as null.
        """
        normalized = normalize_bursa_symbol(symbol)
        ingestion_time = utc_now_iso()
        fields = [
            "symbol",
            "shortName",
            "longName",
            "sector",
            "industry",
            "country",
            "currency",
            "exchange",
            "marketCap",
            "trailingPE",
            "forwardPE",
            "dividendYield",
            "bookValue",
            "priceToBook",
            "fiftyTwoWeekHigh",
            "fiftyTwoWeekLow",
            "regularMarketPrice",
            "regularMarketVolume",
            "regularMarketChangePercent",
        ]
        try:
            ticker = yf.Ticker(normalized)
            info = ticker.info or {}
            record = {field: info.get(field) for field in fields}
            record.update(
                {
                    "event_time": ingestion_time,
                    "ingestion_time": ingestion_time,
                    "known_at_time": ingestion_time,
                    "source_api": "yfinance_yahoo",
                    "symbol": normalized,
                    "asset": symbol_to_asset(normalized),
                    "timeframe": "snapshot",
                    "data_delay_warning": "Company profile/quote fields from Yahoo/yfinance can be delayed, partial, or unavailable.",
                }
            )
            df = pd.DataFrame([record])
            return FetchResult(
                ok=True,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe="snapshot",
                dataset_type="company_profile_quote",
                message=f"Fetched quote/profile snapshot for {normalized}.",
                request_url=f"yfinance://{normalized}/info",
                raw_payload={"available_info_keys": sorted(list(info.keys()))},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe="snapshot",
                dataset_type="company_profile_quote",
                message=f"Quote/profile fetch failed for {normalized}: {exc}",
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )

    def fetch_yfinance_financials(self, symbol: str) -> FetchResult:
        """Fetch financial statements from yfinance if available.

        This function does not invent missing statement values. If Yahoo/yfinance has
        no statement data for a ticker, the returned dataframe is empty.
        """
        normalized = normalize_bursa_symbol(symbol)
        ingestion_time = utc_now_iso()
        try:
            ticker = yf.Ticker(normalized)
            statement_frames: List[pd.DataFrame] = []
            sources: List[Tuple[str, pd.DataFrame]] = [
                ("income_statement_annual", ticker.income_stmt),
                ("balance_sheet_annual", ticker.balance_sheet),
                ("cash_flow_annual", ticker.cashflow),
                ("income_statement_quarterly", ticker.quarterly_income_stmt),
                ("balance_sheet_quarterly", ticker.quarterly_balance_sheet),
                ("cash_flow_quarterly", ticker.quarterly_cashflow),
            ]
            for statement_name, wide_df in sources:
                if wide_df is None or wide_df.empty:
                    continue
                tmp = wide_df.copy()
                tmp.index.name = "metric"
                long_df = tmp.reset_index().melt(id_vars="metric", var_name="period", value_name="value")
                long_df["period"] = pd.to_datetime(long_df["period"], errors="coerce").dt.date.astype(str)
                long_df["statement"] = statement_name
                statement_frames.append(long_df)

            if statement_frames:
                df = pd.concat(statement_frames, ignore_index=True)
            else:
                df = pd.DataFrame(columns=["metric", "period", "value", "statement"])

            df["event_time"] = ingestion_time
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "yfinance_yahoo"
            df["symbol"] = normalized
            df["asset"] = symbol_to_asset(normalized)
            df["timeframe"] = "financial_statement"
            df["data_delay_warning"] = "Financial statements from Yahoo/yfinance may be partial or unavailable for some Malaysian tickers."

            return FetchResult(
                ok=True,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe="financial_statement",
                dataset_type="financial_statements",
                message=f"Fetched {len(df):,} financial statement rows from yfinance/Yahoo for {normalized}.",
                request_url=f"yfinance://{normalized}/financials",
                raw_payload={"rows": int(len(df)), "statements_attempted": [x[0] for x in sources]},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="yfinance_yahoo",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe="financial_statement",
                dataset_type="financial_statements",
                message=f"Financial statement fetch failed for {normalized}: {exc}",
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )

    # ------------------------------------------------------------------
    # Twelve Data optional source
    # ------------------------------------------------------------------
    def fetch_twelve_data_universe(self) -> FetchResult:
        """Fetch Bursa Malaysia symbol universe from Twelve Data, if an API key is supplied."""
        ingestion_time = utc_now_iso()
        if not self.twelve_data_api_key:
            return FetchResult(
                ok=False,
                source_api="twelve_data",
                symbol="XKLS",
                asset="BURSA_MALAYSIA_UNIVERSE",
                timeframe="snapshot",
                dataset_type="symbol_universe",
                message="TWELVE_DATA_API_KEY is not set. Universe fetch skipped.",
                metadata={"ingestion_time": ingestion_time, "requires_api_key": True},
            )
        url = "https://api.twelvedata.com/stocks"
        params = {"exchange": "XKLS", "apikey": self.twelve_data_api_key}
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload.get("data", payload if isinstance(payload, list) else [])
            df = pd.DataFrame(data)
            if df.empty:
                raise ValueError(f"Twelve Data returned no universe rows: {payload}")
            df["event_time"] = ingestion_time
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "twelve_data"
            df["asset"] = "BURSA_MALAYSIA_UNIVERSE"
            df["timeframe"] = "snapshot"
            return FetchResult(
                ok=True,
                source_api="twelve_data",
                symbol="XKLS",
                asset="BURSA_MALAYSIA_UNIVERSE",
                timeframe="snapshot",
                dataset_type="symbol_universe",
                message=f"Fetched {len(df):,} Bursa/XKLS symbols from Twelve Data.",
                request_url=resp.url.replace(self.twelve_data_api_key, "***"),
                raw_payload={"rows": int(len(df)), "columns": list(df.columns)},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="twelve_data",
                symbol="XKLS",
                asset="BURSA_MALAYSIA_UNIVERSE",
                timeframe="snapshot",
                dataset_type="symbol_universe",
                message=f"Twelve Data universe fetch failed: {exc}",
                request_url=url,
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )

    def fetch_twelve_data_financials(self, symbol: str) -> FetchResult:
        """Fetch optional Twelve Data financial statements.

        The API key is optional. We try income_statement, balance_sheet, and cash_flow
        using Twelve Data's documented endpoint names.
        """
        normalized = normalize_bursa_symbol(symbol)
        clean_symbol = normalized.replace(".KL", "")
        ingestion_time = utc_now_iso()
        if not self.twelve_data_api_key:
            return FetchResult(
                ok=False,
                source_api="twelve_data",
                symbol=normalized,
                asset=symbol_to_asset(normalized),
                timeframe="financial_statement",
                dataset_type="financial_statements",
                message="TWELVE_DATA_API_KEY is not set. Twelve Data financials skipped.",
                metadata={"ingestion_time": ingestion_time, "requires_api_key": True},
            )
        endpoints = ["income_statement", "balance_sheet", "cash_flow"]
        rows: List[Dict[str, Any]] = []
        raw_payload: Dict[str, Any] = {}
        for endpoint in endpoints:
            url = f"https://api.twelvedata.com/{endpoint}"
            params = {"symbol": clean_symbol, "exchange": "XKLS", "apikey": self.twelve_data_api_key}
            try:
                resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
                raw_payload[endpoint] = resp.json()
                payload = raw_payload[endpoint]
                statement_data = payload.get(endpoint) or payload.get("data") or []
                if isinstance(statement_data, dict):
                    statement_data = statement_data.get("quarterly") or statement_data.get("annual") or [statement_data]
                if not isinstance(statement_data, list):
                    statement_data = []
                for item in statement_data:
                    if isinstance(item, dict):
                        period = item.get("fiscal_date") or item.get("date") or item.get("period")
                        for metric, value in item.items():
                            if isinstance(value, (dict, list)):
                                continue
                            rows.append(
                                {
                                    "statement": endpoint,
                                    "metric": metric,
                                    "period": period,
                                    "value": value,
                                }
                            )
            except Exception as exc:  # noqa: BLE001
                raw_payload[endpoint] = {"error": str(exc)}
        df = pd.DataFrame(rows)
        if not df.empty:
            df["event_time"] = ingestion_time
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "twelve_data"
            df["symbol"] = normalized
            df["asset"] = symbol_to_asset(normalized)
            df["timeframe"] = "financial_statement"
        return FetchResult(
            ok=not df.empty,
            source_api="twelve_data",
            symbol=normalized,
            asset=symbol_to_asset(normalized),
            timeframe="financial_statement",
            dataset_type="financial_statements",
            message=f"Fetched {len(df):,} Twelve Data financial rows." if not df.empty else "Twelve Data returned no usable financial rows.",
            request_url="https://api.twelvedata.com/{income_statement,balance_sheet,cash_flow}",
            raw_payload=raw_payload,
            dataframe=df,
            metadata={"ingestion_time": ingestion_time},
        )

    # ------------------------------------------------------------------
    # EIA optional official crude oil data
    # ------------------------------------------------------------------
    def fetch_eia_crude_spot(self, benchmark: str = "WTI", length: int = 365) -> FetchResult:
        """Fetch daily WTI or Brent spot prices from EIA v2 API if an EIA key is supplied."""
        benchmark_upper = benchmark.upper()
        product_map = {"WTI": "EPCWTI", "BRENT": "EPCBRENT"}
        product = product_map.get(benchmark_upper, "EPCWTI")
        ingestion_time = utc_now_iso()
        if not self.eia_api_key:
            return FetchResult(
                ok=False,
                source_api="eia",
                symbol=benchmark_upper,
                asset=f"CRUDE_{benchmark_upper}",
                timeframe="1d",
                dataset_type="commodity_price",
                message="EIA_API_KEY is not set. EIA official crude fetch skipped.",
                metadata={"ingestion_time": ingestion_time, "requires_api_key": True},
            )
        url = "https://api.eia.gov/v2/petroleum/pri/spt/data/"
        params = {
            "api_key": self.eia_api_key,
            "frequency": "daily",
            "data[0]": "value",
            "facets[product][]": product,
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "length": str(length),
        }
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload.get("response", {}).get("data", [])
            df = pd.DataFrame(data)
            if df.empty:
                raise ValueError(f"EIA returned no rows: {payload}")
            df = df.rename(columns={"period": "event_time", "value": "close"})
            df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
            df["close"] = pd.to_numeric(df["close"], errors="coerce")
            df = df.dropna(subset=["event_time", "close"]).sort_values("event_time")
            df["open"] = pd.NA
            df["high"] = pd.NA
            df["low"] = pd.NA
            df["volume"] = pd.NA
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "eia"
            df["symbol"] = benchmark_upper
            df["asset"] = f"CRUDE_{benchmark_upper}"
            df["timeframe"] = "1d"
            df["unit"] = "USD per barrel"
            return FetchResult(
                ok=True,
                source_api="eia",
                symbol=benchmark_upper,
                asset=f"CRUDE_{benchmark_upper}",
                timeframe="1d",
                dataset_type="commodity_price",
                message=f"Fetched {len(df):,} EIA {benchmark_upper} spot rows.",
                request_url=resp.url.replace(self.eia_api_key, "***"),
                raw_payload={"response_count": len(data)},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time, "product": product},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="eia",
                symbol=benchmark_upper,
                asset=f"CRUDE_{benchmark_upper}",
                timeframe="1d",
                dataset_type="commodity_price",
                message=f"EIA crude fetch failed: {exc}",
                request_url=url,
                metadata={"ingestion_time": ingestion_time, "error": str(exc), "product": product},
            )

    # ------------------------------------------------------------------
    # BNM / data.gov.my / FX
    # ------------------------------------------------------------------
    def fetch_bnm_exchange_rate(self, currency_code: str = "usd") -> FetchResult:
        """Fetch BNM exchange-rate endpoint if available.

        The endpoint can evolve. Failure is handled and shown in the app; yfinance FX
        is used as the fallback display path.
        """
        code = currency_code.lower().strip()
        ingestion_time = utc_now_iso()
        url = f"https://api.bnm.gov.my/public/exchange-rate/{code}"
        headers = {"Accept": "application/vnd.BNM.API.header.v1+json"}
        try:
            resp = self.session.get(url, headers=headers, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload.get("data", payload)
            if isinstance(data, dict):
                rows = data.get("rate") or data.get("rates") or [data]
            else:
                rows = data
            df = pd.DataFrame(rows if isinstance(rows, list) else [rows])
            if df.empty:
                raise ValueError(f"BNM returned no rows: {payload}")
            # Try to find an event date column. Keep all original fields too.
            date_candidates = [c for c in df.columns if "date" in str(c).lower() or "effective" in str(c).lower()]
            if date_candidates:
                df["event_time"] = pd.to_datetime(df[date_candidates[0]], utc=True, errors="coerce")
            else:
                df["event_time"] = pd.to_datetime(ingestion_time, utc=True)
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "bnm_openapi"
            df["symbol"] = f"{code.upper()}/MYR"
            df["asset"] = f"FX_{code.upper()}_MYR"
            df["timeframe"] = "snapshot"
            return FetchResult(
                ok=True,
                source_api="bnm_openapi",
                symbol=f"{code.upper()}/MYR",
                asset=f"FX_{code.upper()}_MYR",
                timeframe="snapshot",
                dataset_type="fx_rate",
                message=f"Fetched BNM exchange-rate data for {code.upper()}.",
                request_url=resp.url,
                raw_payload=payload,
                dataframe=df,
                metadata={"ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="bnm_openapi",
                symbol=f"{code.upper()}/MYR",
                asset=f"FX_{code.upper()}_MYR",
                timeframe="snapshot",
                dataset_type="fx_rate",
                message=f"BNM exchange-rate fetch failed for {code.upper()}: {exc}",
                request_url=url,
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )

    def fetch_data_gov_my_exchange_rates(self, dataset_id: str = "exchangerates_daily_0900", limit: int = 1000) -> FetchResult:
        """Fetch Malaysia data.gov.my exchange-rate dataset through the public catalogue API."""
        ingestion_time = utc_now_iso()
        url = "https://api.data.gov.my/data-catalogue"
        params = {"id": dataset_id, "limit": str(limit)}
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload if isinstance(payload, list) else payload.get("data", [])
            df = pd.DataFrame(data)
            if df.empty:
                raise ValueError(f"data.gov.my returned no rows: {payload}")
            date_candidates = [c for c in df.columns if str(c).lower() in {"date", "timestamp", "period"}]
            if date_candidates:
                df["event_time"] = pd.to_datetime(df[date_candidates[0]], utc=True, errors="coerce")
            else:
                df["event_time"] = pd.to_datetime(ingestion_time, utc=True)
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "data_gov_my"
            df["symbol"] = dataset_id
            df["asset"] = "MYR_EXCHANGE_RATES"
            df["timeframe"] = "daily"
            return FetchResult(
                ok=True,
                source_api="data_gov_my",
                symbol=dataset_id,
                asset="MYR_EXCHANGE_RATES",
                timeframe="daily",
                dataset_type="fx_rate",
                message=f"Fetched {len(df):,} rows from data.gov.my dataset {dataset_id}.",
                request_url=resp.url,
                raw_payload={"rows": int(len(df)), "columns": list(df.columns)},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="data_gov_my",
                symbol=dataset_id,
                asset="MYR_EXCHANGE_RATES",
                timeframe="daily",
                dataset_type="fx_rate",
                message=f"data.gov.my exchange-rate fetch failed: {exc}",
                request_url=url,
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )

    # ------------------------------------------------------------------
    # Palm oil fundamentals / MPOB
    # ------------------------------------------------------------------
    def fetch_mpob_overview_page(self) -> FetchResult:
        """Fetch MPOB BEPI public overview page and parse light metadata.

        This is not a formal JSON API. The app marks it as web page metadata, not
        clean numerical data, unless users add their own parser later.
        """
        ingestion_time = utc_now_iso()
        url = "https://bepi.mpob.gov.my/"
        try:
            resp = self.session.get(url, timeout=self.timeout_seconds)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            text = " ".join(soup.get_text(" ").split())
            rows = [
                {
                    "event_time": ingestion_time,
                    "ingestion_time": ingestion_time,
                    "known_at_time": ingestion_time,
                    "source_api": "mpob_bepi_web",
                    "symbol": "MPOB_BEPI",
                    "asset": "PALM_OIL_FUNDAMENTALS",
                    "timeframe": "monthly_or_daily_page",
                    "page_title": soup.title.get_text(strip=True) if soup.title else "MPOB BEPI",
                    "text_preview": text[:1200],
                    "data_delay_warning": "MPOB BEPI page is public web content; numerical table parsing should be validated before modelling.",
                }
            ]
            df = pd.DataFrame(rows)
            return FetchResult(
                ok=True,
                source_api="mpob_bepi_web",
                symbol="MPOB_BEPI",
                asset="PALM_OIL_FUNDAMENTALS",
                timeframe="monthly_or_daily_page",
                dataset_type="palm_oil_fundamentals_page",
                message="Fetched MPOB BEPI overview page metadata.",
                request_url=url,
                raw_payload={"html_length": len(resp.text), "text_preview": text[:2000]},
                dataframe=df,
                metadata={"ingestion_time": ingestion_time, "is_structured_api": False},
            )
        except Exception as exc:  # noqa: BLE001
            return FetchResult(
                ok=False,
                source_api="mpob_bepi_web",
                symbol="MPOB_BEPI",
                asset="PALM_OIL_FUNDAMENTALS",
                timeframe="monthly_or_daily_page",
                dataset_type="palm_oil_fundamentals_page",
                message=f"MPOB BEPI fetch failed: {exc}",
                request_url=url,
                metadata={"ingestion_time": ingestion_time, "error": str(exc)},
            )


    # ------------------------------------------------------------------
    # Twelve Data optional market data / profile endpoints
    # ------------------------------------------------------------------
    def fetch_twelve_data_time_series(self, symbol: str, interval: str = "1day", outputsize: int = 5000, exchange: str = "XKLS") -> FetchResult:
        """Fetch OHLCV time series from Twelve Data when TWELVE_DATA_API_KEY is set."""
        normalized = normalize_bursa_symbol(symbol)
        clean_symbol = normalized.replace(".KL", "").replace("^", "")
        ingestion_time = utc_now_iso()
        if not self.twelve_data_api_key:
            return FetchResult(False, "twelve_data", normalized, symbol_to_asset(normalized), interval, "price_history", "TWELVE_DATA_API_KEY is not set. Twelve Data time_series fetch skipped.", metadata={"ingestion_time": ingestion_time, "requires_api_key": True})
        url = "https://api.twelvedata.com/time_series"
        params = {"symbol": clean_symbol, "exchange": exchange, "interval": interval, "outputsize": str(outputsize), "apikey": self.twelve_data_api_key}
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            values = payload.get("values") or payload.get("data") or []
            df = pd.DataFrame(values)
            if df.empty:
                raise ValueError(f"Twelve Data returned no time_series rows: {payload}")
            dt_col = "datetime" if "datetime" in df.columns else df.columns[0]
            df = df.rename(columns={dt_col: "event_time"})
            for c in ["open", "high", "low", "close", "volume"]:
                if c in df.columns:
                    df[c] = pd.to_numeric(df[c], errors="coerce")
            df["event_time"] = pd.to_datetime(df["event_time"], utc=True, errors="coerce")
            df = df.dropna(subset=["event_time"]).sort_values("event_time")
            df["ingestion_time"] = ingestion_time
            df["known_at_time"] = ingestion_time
            df["source_api"] = "twelve_data"
            df["symbol"] = normalized
            df["asset"] = symbol_to_asset(normalized)
            df["timeframe"] = interval
            df["data_delay_warning"] = "Twelve Data availability/delay depends on API plan and exchange coverage."
            return FetchResult(True, "twelve_data", normalized, symbol_to_asset(normalized), interval, "price_history", f"Fetched {len(df):,} Twelve Data time_series rows for {normalized}.", request_url=resp.url.replace(self.twelve_data_api_key, "***"), raw_payload={"rows": int(len(df)), "meta": payload.get("meta", {}), "status": payload.get("status")}, dataframe=df, metadata={"ingestion_time": ingestion_time, "exchange": exchange})
        except Exception as exc:
            return FetchResult(False, "twelve_data", normalized, symbol_to_asset(normalized), interval, "price_history", f"Twelve Data time_series fetch failed for {normalized}: {exc}", request_url=url, metadata={"ingestion_time": ingestion_time, "error": str(exc), "exchange": exchange})

    def fetch_twelve_data_profile(self, symbol: str, exchange: str = "XKLS") -> FetchResult:
        """Fetch company profile from Twelve Data when TWELVE_DATA_API_KEY is set."""
        normalized = normalize_bursa_symbol(symbol)
        clean_symbol = normalized.replace(".KL", "").replace("^", "")
        ingestion_time = utc_now_iso()
        if not self.twelve_data_api_key:
            return FetchResult(False, "twelve_data", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", "TWELVE_DATA_API_KEY is not set. Twelve Data profile fetch skipped.", metadata={"ingestion_time": ingestion_time, "requires_api_key": True})
        url = "https://api.twelvedata.com/profile"
        params = {"symbol": clean_symbol, "exchange": exchange, "apikey": self.twelve_data_api_key}
        try:
            resp = self.session.get(url, params=params, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload.get("data") if isinstance(payload, dict) and "data" in payload else payload
            if isinstance(data, list): data = data[0] if data else {}
            if not isinstance(data, dict) or not data:
                raise ValueError(f"Twelve Data returned no profile data: {payload}")
            row = dict(data)
            row.update({"event_time": ingestion_time, "ingestion_time": ingestion_time, "known_at_time": ingestion_time, "source_api": "twelve_data", "symbol": normalized, "asset": symbol_to_asset(normalized), "timeframe": "snapshot", "data_delay_warning": "Twelve Data profile availability depends on API plan and coverage."})
            df = pd.DataFrame([row])
            return FetchResult(True, "twelve_data", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", f"Fetched Twelve Data profile for {normalized}.", request_url=resp.url.replace(self.twelve_data_api_key, "***"), raw_payload=payload, dataframe=df, metadata={"ingestion_time": ingestion_time, "exchange": exchange})
        except Exception as exc:
            return FetchResult(False, "twelve_data", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", f"Twelve Data profile fetch failed for {normalized}: {exc}", request_url=url, metadata={"ingestion_time": ingestion_time, "error": str(exc), "exchange": exchange})

    # ------------------------------------------------------------------
    # Financial Modeling Prep optional source
    # ------------------------------------------------------------------
    def fetch_fmp_financials(self, symbol: str, period: str = "annual", limit: int = 5) -> FetchResult:
        """Fetch FMP financial statements when FMP_API_KEY is set."""
        normalized = normalize_bursa_symbol(symbol)
        ingestion_time = utc_now_iso()
        if not self.fmp_api_key:
            return FetchResult(False, "fmp", normalized, symbol_to_asset(normalized), "financial_statement", "financial_statements", "FMP_API_KEY is not set. FMP financials skipped.", metadata={"ingestion_time": ingestion_time, "requires_api_key": True})
        fmp_symbol = normalized if normalized.endswith(".KL") else f"{normalized}.KL"
        endpoints = {"income_statement": f"https://financialmodelingprep.com/api/v3/income-statement/{fmp_symbol}", "balance_sheet": f"https://financialmodelingprep.com/api/v3/balance-sheet-statement/{fmp_symbol}", "cash_flow": f"https://financialmodelingprep.com/api/v3/cash-flow-statement/{fmp_symbol}"}
        rows, raw_payload = [], {}
        for statement, url in endpoints.items():
            try:
                resp = self.session.get(url, params={"period": period, "limit": str(limit), "apikey": self.fmp_api_key}, timeout=self.timeout_seconds)
                resp.raise_for_status()
                payload = resp.json(); raw_payload[statement] = payload
                payload_rows = payload.get("data") if isinstance(payload, dict) else payload if isinstance(payload, list) else []
                if isinstance(payload_rows, dict): payload_rows = [payload_rows]
                for item in payload_rows or []:
                    if isinstance(item, dict):
                        per = item.get("date") or item.get("calendarYear") or item.get("period")
                        for metric, value in item.items():
                            if not isinstance(value, (dict, list)):
                                rows.append({"statement": statement, "metric": metric, "period": per, "value": value})
            except Exception as exc:
                raw_payload[statement] = {"error": str(exc)}
        df = pd.DataFrame(rows)
        if not df.empty:
            df["event_time"] = ingestion_time; df["ingestion_time"] = ingestion_time; df["known_at_time"] = ingestion_time
            df["source_api"] = "fmp"; df["symbol"] = normalized; df["asset"] = symbol_to_asset(normalized); df["timeframe"] = "financial_statement"
            df["data_delay_warning"] = "FMP coverage and delay depend on API plan and exchange support."
        return FetchResult(not df.empty, "fmp", normalized, symbol_to_asset(normalized), "financial_statement", "financial_statements", f"Fetched {len(df):,} FMP financial rows." if not df.empty else "FMP returned no usable financial rows.", request_url="https://financialmodelingprep.com/api/v3/{income-statement,balance-sheet-statement,cash-flow-statement}/{symbol}.KL", raw_payload=raw_payload, dataframe=df, metadata={"ingestion_time": ingestion_time, "period": period, "limit": limit})

    def fetch_fmp_profile(self, symbol: str) -> FetchResult:
        """Fetch FMP company profile when FMP_API_KEY is set."""
        normalized = normalize_bursa_symbol(symbol)
        ingestion_time = utc_now_iso()
        if not self.fmp_api_key:
            return FetchResult(False, "fmp", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", "FMP_API_KEY is not set. FMP profile skipped.", metadata={"ingestion_time": ingestion_time, "requires_api_key": True})
        fmp_symbol = normalized if normalized.endswith(".KL") else f"{normalized}.KL"
        url = f"https://financialmodelingprep.com/api/v3/profile/{fmp_symbol}"
        try:
            resp = self.session.get(url, params={"apikey": self.fmp_api_key}, timeout=self.timeout_seconds)
            resp.raise_for_status()
            payload = resp.json()
            data = payload[0] if isinstance(payload, list) and payload else payload if isinstance(payload, dict) else {}
            if not data: raise ValueError(f"FMP returned no profile data: {payload}")
            row = dict(data); row.update({"event_time": ingestion_time, "ingestion_time": ingestion_time, "known_at_time": ingestion_time, "source_api": "fmp", "symbol": normalized, "asset": symbol_to_asset(normalized), "timeframe": "snapshot", "data_delay_warning": "FMP profile coverage depends on API plan and exchange support."})
            df = pd.DataFrame([row])
            return FetchResult(True, "fmp", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", f"Fetched FMP profile for {normalized}.", request_url=resp.url.replace(self.fmp_api_key, "***"), raw_payload=payload, dataframe=df, metadata={"ingestion_time": ingestion_time})
        except Exception as exc:
            return FetchResult(False, "fmp", normalized, symbol_to_asset(normalized), "snapshot", "company_profile_quote", f"FMP profile fetch failed for {normalized}: {exc}", request_url=url, metadata={"ingestion_time": ingestion_time, "error": str(exc)})

    # ------------------------------------------------------------------
    # FCPO official/reference web sources and licensed vendor placeholders
    # ------------------------------------------------------------------
    def fetch_public_web_page_metadata(self, url: str, source_api: str, symbol: str, asset: str, dataset_type: str, note: str) -> FetchResult:
        """Fetch public web page metadata without pretending it is structured live market data."""
        ingestion_time = utc_now_iso()
        try:
            resp = self.session.get(url, timeout=self.timeout_seconds)
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            text = " ".join(soup.get_text(" ").split())
            row = {"event_time": ingestion_time, "ingestion_time": ingestion_time, "known_at_time": ingestion_time, "source_api": source_api, "symbol": symbol, "asset": asset, "timeframe": "web_reference", "page_title": soup.title.get_text(strip=True) if soup.title else source_api, "url": url, "text_preview": text[:1500], "data_delay_warning": note}
            df = pd.DataFrame([row])
            return FetchResult(True, source_api, symbol, asset, "web_reference", dataset_type, f"Fetched reference web page metadata from {source_api}.", request_url=url, raw_payload={"html_length": len(resp.text), "text_preview": text[:2500]}, dataframe=df, metadata={"ingestion_time": ingestion_time, "is_structured_api": False})
        except Exception as exc:
            return FetchResult(False, source_api, symbol, asset, "web_reference", dataset_type, f"{source_api} web reference fetch failed: {exc}", request_url=url, metadata={"ingestion_time": ingestion_time, "error": str(exc), "is_structured_api": False})

    def fetch_bursa_fcpo_contract_specs_page(self) -> FetchResult:
        return self.fetch_public_web_page_metadata("https://www.bursamalaysia.com/trade/our_products_services/derivatives/commodity_derivatives/crude_palm_oil_futures", "bursa_fcpo_contract_specs", "FCPO", "FCPO_CONTRACT_SPECS", "fcpo_contract_specs_reference", "Official Bursa FCPO contract reference page; not a free live price JSON API.")

    def fetch_bursa_derivatives_prices_page(self) -> FetchResult:
        return self.fetch_public_web_page_metadata("https://www.bursamalaysia.com/market_information/derivatives_prices", "bursa_derivatives_prices_web", "FCPO", "FCPO_DERIVATIVES_PRICES_PAGE", "fcpo_prices_reference_page", "Bursa derivatives prices page metadata; parser must be validated before using as numerical live data.")

    def fetch_investing_fcpo_page(self) -> FetchResult:
        return self.fetch_public_web_page_metadata("https://www.investing.com/commodities/crude-palm-oil", "investing_fcpo_web", "FCPO", "FCPO_REFERENCE_PAGE", "fcpo_prices_reference_page", "Investing.com page is a web reference and may block scraping; not treated as official FCPO feed.")

    def licensed_vendor_placeholder(self, vendor_name: str = "fcpo_licensed_vendor") -> FetchResult:
        """Register a clear placeholder for future licensed FCPO vendor integration."""
        ingestion_time = utc_now_iso()
        row = {"event_time": ingestion_time, "ingestion_time": ingestion_time, "known_at_time": ingestion_time, "source_api": vendor_name, "symbol": "FCPO", "asset": "FCPO_LICENSED_FEED", "timeframe": "licensed_placeholder", "status": "not_configured", "data_delay_warning": "Add broker/Bursa licensed vendor credentials before using official FCPO live prices."}
        return FetchResult(False, vendor_name, "FCPO", "FCPO_LICENSED_FEED", "licensed_placeholder", "fcpo_licensed_vendor_placeholder", "Licensed FCPO vendor feed is not configured. Placeholder registered only.", raw_payload=row, dataframe=pd.DataFrame([row]), metadata={"ingestion_time": ingestion_time, "requires_vendor_credentials": True})
