"""Local storage layer for the Malaysia market terminal.

The storage layout follows:
raw API response -> bronze parsed parquet -> silver cleaned parquet -> gold dashboard parquet.

Raw JSON is append-only. Parquet files are partitioned by source/asset/symbol/timeframe/date.
DuckDB is used to query local Parquet files without loading everything into memory.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
import json
import re

import duckdb
import pandas as pd


UTC = timezone.utc


def utc_now() -> datetime:
    return datetime.now(UTC).replace(microsecond=0)


def utc_now_iso() -> str:
    return utc_now().isoformat()


def make_batch_id(prefix: str = "batch") -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_{stamp}"


def safe_name(value: Any) -> str:
    text = str(value).strip().replace(" ", "_")
    text = text.replace("/", "_").replace("\\", "_").replace(":", "_")
    return re.sub(r"[^A-Za-z0-9_\-.=^]+", "", text) or "unknown"


class MarketStorage:
    """Manage local raw/parquet/log storage and DuckDB query access."""

    def __init__(self, root_dir: str | Path = "data_store", duckdb_path: str | Path = "market_terminal.duckdb") -> None:
        self.root_dir = Path(root_dir)
        self.duckdb_path = Path(duckdb_path)
        self.ensure_directories()

    def ensure_directories(self) -> None:
        for layer in ["raw", "bronze", "silver", "gold", "latest", "logs"]:
            (self.root_dir / layer).mkdir(parents=True, exist_ok=True)

    def _partition_base(self, layer: str, source_api: str, asset: str, symbol: str, timeframe: str) -> Path:
        return (
            self.root_dir
            / safe_name(layer)
            / safe_name(source_api)
            / safe_name(asset)
            / safe_name(symbol)
            / safe_name(timeframe)
        )

    def save_raw_json(
        self,
        payload: Any,
        source_api: str,
        asset: str,
        symbol: str,
        timeframe: str,
        batch_id: Optional[str] = None,
    ) -> Path:
        """Append raw API payload as JSON. Raw data is never overwritten."""
        batch_id = batch_id or make_batch_id("raw")
        now = utc_now()
        path = (
            self._partition_base("raw", source_api, asset, symbol, timeframe)
            / f"year={now:%Y}"
            / f"month={now:%m}"
            / f"day={now:%d}"
        )
        path.mkdir(parents=True, exist_ok=True)
        file_path = path / f"{safe_name(batch_id)}.json"
        envelope = {
            "batch_id": batch_id,
            "saved_at_utc": utc_now_iso(),
            "source_api": source_api,
            "asset": asset,
            "symbol": symbol,
            "timeframe": timeframe,
            "payload": payload,
        }
        with file_path.open("w", encoding="utf-8") as f:
            json.dump(envelope, f, ensure_ascii=False, indent=2, default=str)
        return file_path

    def _add_storage_metadata(self, df: pd.DataFrame, batch_id: str, raw_file_path: Optional[Path]) -> pd.DataFrame:
        out = df.copy()
        out["ingestion_batch_id"] = batch_id
        out["raw_file_path"] = str(raw_file_path) if raw_file_path else ""
        return out

    def save_parquet(
        self,
        df: pd.DataFrame,
        layer: str,
        dataset_name: str,
        source_api: str,
        asset: str,
        symbol: str,
        timeframe: str,
        batch_id: Optional[str] = None,
        raw_file_path: Optional[Path] = None,
        also_save_latest: bool = True,
    ) -> Optional[Path]:
        """Save a dataframe to Parquet in the requested layer.

        For simplicity and traceability, this writes one append-only parquet file per batch.
        """
        if df is None or df.empty:
            return None
        batch_id = batch_id or make_batch_id(layer)
        out = self._add_storage_metadata(df, batch_id, raw_file_path)
        # Use the minimum event_time for partition date when available; otherwise use now.
        if "event_time" in out.columns:
            event_ts = pd.to_datetime(out["event_time"], errors="coerce", utc=True).dropna()
            date_for_path = event_ts.max().to_pydatetime() if not event_ts.empty else utc_now()
        else:
            date_for_path = utc_now()
        path = (
            self._partition_base(layer, source_api, asset, symbol, timeframe)
            / f"year={date_for_path:%Y}"
            / f"month={date_for_path:%m}"
            / f"day={date_for_path:%d}"
        )
        path.mkdir(parents=True, exist_ok=True)
        file_path = path / f"{safe_name(dataset_name)}_{safe_name(batch_id)}.parquet"
        out.to_parquet(file_path, index=False)

        if also_save_latest:
            latest_path = self.root_dir / "latest" / f"{safe_name(dataset_name)}.parquet"
            out.to_parquet(latest_path, index=False)
        return file_path

    def log_ingestion(
        self,
        batch_id: str,
        source_api: str,
        dataset_type: str,
        symbol: str,
        asset: str,
        timeframe: str,
        rows_downloaded: int,
        rows_saved: int,
        status: str,
        message: str,
        raw_file_path: Optional[Path] = None,
        parquet_file_path: Optional[Path] = None,
        request_url: Optional[str] = None,
    ) -> Path:
        """Append one row to ingestion_log.csv."""
        log_path = self.root_dir / "logs" / "ingestion_log.csv"
        row = {
            "run_time_utc": utc_now_iso(),
            "batch_id": batch_id,
            "source_api": source_api,
            "dataset_type": dataset_type,
            "symbol": symbol,
            "asset": asset,
            "timeframe": timeframe,
            "rows_downloaded": rows_downloaded,
            "rows_saved": rows_saved,
            "status": status,
            "message": message,
            "raw_file_path": str(raw_file_path) if raw_file_path else "",
            "parquet_file_path": str(parquet_file_path) if parquet_file_path else "",
            "request_url": request_url or "",
        }
        df = pd.DataFrame([row])
        if log_path.exists():
            df.to_csv(log_path, mode="a", index=False, header=False)
        else:
            df.to_csv(log_path, index=False)
        return log_path

    def save_fetch_result(self, result: Any, layer: str = "silver", dataset_name: Optional[str] = None) -> Dict[str, Any]:
        """Save a standard FetchResult to raw JSON, Parquet, and ingestion log."""
        batch_id = make_batch_id(result.dataset_type)
        dataset_name = dataset_name or f"{result.dataset_type}_{result.symbol}_{result.timeframe}"
        raw_file = self.save_raw_json(
            payload=result.raw_payload if result.raw_payload is not None else result.metadata,
            source_api=result.source_api,
            asset=result.asset,
            symbol=result.symbol,
            timeframe=result.timeframe,
            batch_id=batch_id,
        )
        parquet_file = None
        rows = 0
        if result.dataframe is not None and not result.dataframe.empty:
            rows = int(len(result.dataframe))
            parquet_file = self.save_parquet(
                df=result.dataframe,
                layer=layer,
                dataset_name=dataset_name,
                source_api=result.source_api,
                asset=result.asset,
                symbol=result.symbol,
                timeframe=result.timeframe,
                batch_id=batch_id,
                raw_file_path=raw_file,
            )
        self.log_ingestion(
            batch_id=batch_id,
            source_api=result.source_api,
            dataset_type=result.dataset_type,
            symbol=result.symbol,
            asset=result.asset,
            timeframe=result.timeframe,
            rows_downloaded=rows,
            rows_saved=rows if parquet_file else 0,
            status="success" if result.ok else "failed",
            message=result.message,
            raw_file_path=raw_file,
            parquet_file_path=parquet_file,
            request_url=result.request_url,
        )
        return {"batch_id": batch_id, "raw_file": raw_file, "parquet_file": parquet_file, "rows_saved": rows}

    def read_ingestion_log(self) -> pd.DataFrame:
        log_path = self.root_dir / "logs" / "ingestion_log.csv"
        if not log_path.exists():
            return pd.DataFrame()
        return pd.read_csv(log_path)

    def query_duckdb(self, sql: str) -> pd.DataFrame:
        """Run a SQL query in DuckDB.

        Useful example:
        SELECT * FROM read_parquet('data_store/silver/**/*.parquet') LIMIT 100;
        """
        con = duckdb.connect(str(self.duckdb_path))
        try:
            return con.execute(sql).df()
        finally:
            con.close()

    def register_latest_views(self) -> None:
        """Create helpful DuckDB views over local Parquet folders.

        Views are recreated on every call so new files are discoverable.
        """
        con = duckdb.connect(str(self.duckdb_path))
        try:
            for layer in ["bronze", "silver", "gold", "latest"]:
                pattern = str((self.root_dir / layer / "**" / "*.parquet")).replace("\\", "/")
                view_name = f"v_{layer}"
                con.execute(f"CREATE OR REPLACE VIEW {view_name} AS SELECT * FROM read_parquet('{pattern}', union_by_name=true);")
        except Exception:
            # Views may fail before any parquet exists. The app handles this gracefully.
            pass
        finally:
            con.close()
