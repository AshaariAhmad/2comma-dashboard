"""Catalog manager for source, dataset, and column documentation.

The catalog is intentionally simple: CSV + YAML files that can be edited in Excel,
VS Code, PyCharm, or GitHub.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
import csv
import yaml

import pandas as pd


COLUMN_HEADERS = [
    "column_id",
    "column_name",
    "dataset",
    "source_api",
    "asset",
    "frequency",
    "unit",
    "definition",
    "formula",
    "raw_or_feature",
    "known_at_time_rule",
    "lookahead_risk",
    "null_rule",
    "quality_check",
    "status",
]


class CatalogManager:
    """Read and update lightweight catalog files."""

    def __init__(self, catalog_dir: str | Path = "catalog") -> None:
        self.catalog_dir = Path(catalog_dir)
        self.catalog_dir.mkdir(parents=True, exist_ok=True)
        self.sources_path = self.catalog_dir / "sources.yaml"
        self.datasets_path = self.catalog_dir / "datasets.yaml"
        self.columns_path = self.catalog_dir / "columns.csv"
        self.ensure_files()

    def ensure_files(self) -> None:
        if not self.sources_path.exists():
            self.sources_path.write_text("sources: {}\n", encoding="utf-8")
        if not self.datasets_path.exists():
            self.datasets_path.write_text("datasets: {}\n", encoding="utf-8")
        if not self.columns_path.exists():
            with self.columns_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=COLUMN_HEADERS)
                writer.writeheader()

    def load_yaml(self, path: Path) -> Dict[str, Any]:
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def save_yaml(self, path: Path, data: Dict[str, Any]) -> None:
        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)

    def load_sources(self) -> Dict[str, Any]:
        return self.load_yaml(self.sources_path)

    def load_datasets(self) -> Dict[str, Any]:
        return self.load_yaml(self.datasets_path)

    def load_columns(self) -> pd.DataFrame:
        if not self.columns_path.exists():
            return pd.DataFrame(columns=COLUMN_HEADERS)
        return pd.read_csv(self.columns_path)

    def register_dataset(
        self,
        dataset_name: str,
        description: str,
        path_pattern: str,
        grain: str,
        primary_key: Optional[List[str]] = None,
        source_api: Optional[str] = None,
        status: str = "active",
    ) -> None:
        data = self.load_datasets()
        data.setdefault("datasets", {})[dataset_name] = {
            "description": description,
            "path_pattern": path_pattern,
            "grain": grain,
            "primary_key": primary_key or ["event_time", "symbol"],
            "source_api": source_api or "mixed",
            "status": status,
        }
        self.save_yaml(self.datasets_path, data)

    def register_columns_from_df(
        self,
        df: pd.DataFrame,
        dataset_name: str,
        source_api: str,
        asset: str,
        frequency: str,
        raw_or_feature: str = "raw_or_cleaned",
    ) -> None:
        """Append missing dataframe columns to catalog/columns.csv."""
        if df is None or df.empty:
            return
        existing = self.load_columns()
        existing_keys = set(zip(existing.get("dataset", []), existing.get("column_name", []))) if not existing.empty else set()
        rows = []
        next_id = len(existing) + 1
        for col in df.columns:
            key = (dataset_name, col)
            if key in existing_keys:
                continue
            rows.append(
                {
                    "column_id": f"COL_{next_id:06d}",
                    "column_name": col,
                    "dataset": dataset_name,
                    "source_api": source_api,
                    "asset": asset,
                    "frequency": frequency,
                    "unit": "unknown",
                    "definition": f"Auto-registered column from {source_api}. Please refine this definition.",
                    "formula": "source_field_or_pipeline_output",
                    "raw_or_feature": raw_or_feature,
                    "known_at_time_rule": "Use known_at_time <= prediction_time for modelling.",
                    "lookahead_risk": "unknown_check_before_model_use",
                    "null_rule": "preserve_nulls_until_cleaning_rule_defined",
                    "quality_check": "not_defined_yet",
                    "status": "active",
                }
            )
            next_id += 1
        if not rows:
            return
        new_df = pd.DataFrame(rows, columns=COLUMN_HEADERS)
        combined = pd.concat([existing, new_df], ignore_index=True) if not existing.empty else new_df
        combined.to_csv(self.columns_path, index=False)
