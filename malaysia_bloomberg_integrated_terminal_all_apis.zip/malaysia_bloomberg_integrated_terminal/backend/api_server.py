"""FastAPI backend for the Bloomberg-style Malaysia market terminal.

This backend serves the uploaded Bloomberg-style HTML frontend and injects live /
near-live market data through JSON endpoints. It reuses the Malaysia Market
Terminal v2 fetchers/storage/catalog modules.

Run from project root:
    uvicorn backend.api_server:app --host 0.0.0.0 --port 8000 --reload
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .data_fetchers import MarketDataFetcher, FetchResult, normalize_bursa_symbol
from .storage import MarketStorage
from .catalog_manager import CatalogManager


ROOT_DIR = Path(__file__).resolve().parents[1]
FRONTEND_DIR = ROOT_DIR / "frontend"
CATALOG_DIR = ROOT_DIR / "catalog"
DATA_STORE_DIR = ROOT_DIR / "data_store"
DUCKDB_PATH = ROOT_DIR / "malaysia_market_terminal.duckdb"

load_dotenv(ROOT_DIR / ".env")

API_TIMEOUT_SECONDS = int(os.getenv("API_TIMEOUT_SECONDS", "20"))
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "180"))

fetcher = MarketDataFetcher(timeout_seconds=API_TIMEOUT_SECONDS)
storage = MarketStorage(root_dir=DATA_STORE_DIR, duckdb_path=DUCKDB_PATH)
catalog = CatalogManager(CATALOG_DIR)

app = FastAPI(
    title="Malaysia Bloomberg-Style Market Terminal API",
    version="2.1.0",
    description="Live/near-live backend for Bursa Malaysia, KLCI, crude oil, FCPO proxy, FX, financial statements, and local Parquet/DuckDB storage.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static JS/CSS/HTML files. index.html is also served explicitly at /.
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")
app.mount("/frontend", StaticFiles(directory=str(FRONTEND_DIR)), name="frontend")

_CACHE: Dict[str, Dict[str, Any]] = {}


def cache_get(key: str, ttl: int = CACHE_TTL_SECONDS) -> Optional[Any]:
    record = _CACHE.get(key)
    if not record:
        return None
    if time.time() - record["time"] > ttl:
        _CACHE.pop(key, None)
        return None
    return record["value"]


def cache_set(key: str, value: Any) -> Any:
    _CACHE[key] = {"time": time.time(), "value": value}
    return value


def safe_float(value: Any) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        n = float(value)
        if pd.isna(n):
            return None
        return n
    except Exception:
        return None


def df_records(df: pd.DataFrame, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    if df is None or df.empty:
        return []
    out = df.copy()
    if limit:
        out = out.tail(limit)
    for col in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[col]):
            out[col] = out[col].astype(str)
    out = out.where(pd.notna(out), None)
    return out.to_dict(orient="records")


def save_result_all_layers(result: FetchResult) -> Dict[str, Any]:
    """Persist result to raw, bronze, silver, and gold layers.

    The same parsed dataframe is stored at each layer so the terminal has a full
    raw -> bronze -> silver -> gold path. In a production system, bronze/silver/
    gold can contain progressively cleaned/feature-enriched versions.
    """
    saved: Dict[str, Any] = {}
    for layer in ["bronze", "silver", "gold"]:
        try:
            saved[layer] = storage.save_fetch_result(result, layer=layer)
        except Exception as exc:  # Keep API usable if storage fails.
            saved[layer] = {"error": str(exc)}
    return saved


def latest_from_history(symbol: str, period: str = "5d", interval: str = "1d") -> FetchResult:
    return fetcher.fetch_yfinance_history(symbol=symbol, period=period, interval=interval)


def latest_payload_from_history_and_profile(symbol: str) -> Dict[str, Any]:
    normalized = normalize_bursa_symbol(symbol)
    profile = fetcher.fetch_yfinance_quote_info(normalized)
    hist = latest_from_history(normalized, period="5d", interval="1d")

    if hist.ok:
        save_result_all_layers(hist)
    if profile.ok:
        # Profile is saved to silver/gold for queryable snapshots.
        save_result_all_layers(profile)

    hdf = hist.dataframe if hist and hist.dataframe is not None else pd.DataFrame()
    pdf = profile.dataframe if profile and profile.dataframe is not None else pd.DataFrame()
    last: Dict[str, Any] = {}
    prev_close = None
    if not hdf.empty:
        hdf = hdf.sort_values("event_time")
        last = hdf.tail(1).iloc[0].to_dict()
        if len(hdf) >= 2:
            prev_close = safe_float(hdf.iloc[-2].get("close"))
    profile_row: Dict[str, Any] = pdf.tail(1).iloc[0].to_dict() if not pdf.empty else {}

    price = safe_float(profile_row.get("regularMarketPrice")) or safe_float(last.get("close"))
    close = safe_float(last.get("close"))
    if price is None:
        price = close
    if prev_close is None:
        prev_close = safe_float(profile_row.get("previousClose"))
    change_abs = None
    change_percent = safe_float(profile_row.get("regularMarketChangePercent"))
    if price is not None and prev_close:
        change_abs = price - prev_close
        change_percent = (change_abs / prev_close) * 100

    payload = {
        "ok": bool(hist.ok or profile.ok),
        "symbol": normalized,
        "asset": normalized.replace(".KL", "").replace("^", ""),
        "name": profile_row.get("shortName") or profile_row.get("longName") or normalized,
        "shortName": profile_row.get("shortName"),
        "longName": profile_row.get("longName"),
        "price": price,
        "close": close,
        "open": safe_float(last.get("open")),
        "high": safe_float(last.get("high")),
        "low": safe_float(last.get("low")),
        "previous_close": prev_close,
        "change_abs": change_abs,
        "change_percent": change_percent,
        "volume": safe_float(profile_row.get("regularMarketVolume")) or safe_float(last.get("volume")),
        "currency": profile_row.get("currency") or "MYR",
        "exchange": profile_row.get("exchange"),
        "sector": profile_row.get("sector"),
        "industry": profile_row.get("industry"),
        "country": profile_row.get("country"),
        "marketCap": safe_float(profile_row.get("marketCap")),
        "trailingPE": safe_float(profile_row.get("trailingPE")),
        "forwardPE": safe_float(profile_row.get("forwardPE")),
        "dividendYield": safe_float(profile_row.get("dividendYield")),
        "bookValue": safe_float(profile_row.get("bookValue")),
        "priceToBook": safe_float(profile_row.get("priceToBook")),
        "fiftyTwoWeekHigh": safe_float(profile_row.get("fiftyTwoWeekHigh")),
        "fiftyTwoWeekLow": safe_float(profile_row.get("fiftyTwoWeekLow")),
        "event_time": str(last.get("event_time")) if last else profile.metadata.get("ingestion_time"),
        "ingestion_time": profile.metadata.get("ingestion_time") or hist.metadata.get("ingestion_time"),
        "known_at_time": profile_row.get("known_at_time") or hist.metadata.get("ingestion_time"),
        "source_api": "yfinance_yahoo",
        "timeframe": "snapshot",
        "warning": "Yahoo/yfinance is an unofficial fallback source and can be delayed, partial, or unavailable.",
        "messages": [m for m in [profile.message, hist.message] if m],
    }
    return payload


@app.get("/")
def index() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/live_api_bridge.js")
def bridge() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "live_api_bridge.js")


@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {
        "ok": True,
        "service": "Malaysia Bloomberg-Style Market Terminal API",
        "frontend": str(FRONTEND_DIR / "index.html"),
        "data_store": str(DATA_STORE_DIR),
        "duckdb": str(DUCKDB_PATH),
        "cache_ttl_seconds": CACHE_TTL_SECONDS,
        "optional_keys": {
            "TWELVE_DATA_API_KEY": bool(os.getenv("TWELVE_DATA_API_KEY")),
            "EIA_API_KEY": bool(os.getenv("EIA_API_KEY")),
            "FMP_API_KEY": bool(os.getenv("FMP_API_KEY")),
        },
    }


@app.get("/api/universe")
def universe(refresh: bool = Query(False, description="If true and Twelve Data key is set, try to refresh XKLS universe.")) -> Dict[str, Any]:
    key = f"universe:{refresh}:{bool(os.getenv('TWELVE_DATA_API_KEY'))}"
    cached = cache_get(key, ttl=3600)
    if cached is not None:
        return cached

    rows: List[Dict[str, Any]] = []
    source = "catalog_seed_demo_watchlist"
    message = "Seed watchlist only; not a complete Bursa universe. Add TWELVE_DATA_API_KEY and refresh=true to fetch XKLS universe."

    seed_path = CATALOG_DIR / "seed_bursa_tickers.csv"
    if seed_path.exists():
        seed = pd.read_csv(seed_path)
        rows = seed.where(pd.notna(seed), None).to_dict(orient="records")

    if refresh and os.getenv("TWELVE_DATA_API_KEY"):
        result = fetcher.fetch_twelve_data_universe()
        if result.ok and result.dataframe is not None and not result.dataframe.empty:
            rows = df_records(result.dataframe)
            source = result.source_api
            message = result.message
            save_result_all_layers(result)
        else:
            message = f"Twelve Data universe refresh failed or returned empty: {result.message}"

    payload = {
        "ok": True,
        "source_api": source,
        "is_complete_universe": source == "twelve_data",
        "rows": rows,
        "count": len(rows),
        "message": message,
    }
    return cache_set(key, payload)


@app.get("/api/market/latest")
def market_latest(symbol: str = Query(..., description="Example: 1155.KL, 1155, ^KLSE, CL=F, BZ=F, PO=F")) -> Dict[str, Any]:
    normalized = normalize_bursa_symbol(symbol)
    key = f"latest:{normalized}"
    cached = cache_get(key)
    if cached is not None:
        return cached
    payload = latest_payload_from_history_and_profile(normalized)
    if not payload.get("ok"):
        raise HTTPException(status_code=404, detail=f"No latest data available for {normalized}")
    return cache_set(key, payload)


@app.get("/api/market/history")
def market_history(
    symbol: str = Query(...),
    period: str = Query("1mo", description="yfinance period such as 5d, 1mo, 1y, 5y"),
    interval: str = Query("1d", description="yfinance interval such as 5m, 15m, 1d, 1wk"),
    provider: str = Query("yfinance", description="yfinance or twelve_data"),
) -> Dict[str, Any]:
    normalized = normalize_bursa_symbol(symbol)
    key = f"history:{provider}:{normalized}:{period}:{interval}"
    cached = cache_get(key)
    if cached is not None:
        return cached

    if provider == "twelve_data":
        td_interval_map = {"1d": "1day", "1wk": "1week", "1mo": "1month", "5m": "5min", "15m": "15min", "1h": "1h"}
        result = fetcher.fetch_twelve_data_time_series(normalized, interval=td_interval_map.get(interval, interval), outputsize=5000)
    else:
        result = fetcher.fetch_yfinance_history(normalized, period=period, interval=interval)

    if not result.ok or result.dataframe is None or result.dataframe.empty:
        raise HTTPException(status_code=404, detail=result.message)
    saved = save_result_all_layers(result)
    rows = df_records(result.dataframe)
    payload = {
        "ok": True,
        "source_api": result.source_api,
        "symbol": result.symbol,
        "asset": result.asset,
        "timeframe": result.timeframe,
        "period": period,
        "interval": interval,
        "provider": provider,
        "rows": rows,
        "count": len(rows),
        "saved": saved,
        "message": result.message,
        "warning": "Data availability/delay depends on selected provider and exchange coverage.",
    }
    return cache_set(key, payload)


@app.get("/api/financials")
def financials(symbol: str = Query(...), provider: str = Query("auto")) -> Dict[str, Any]:
    normalized = normalize_bursa_symbol(symbol)
    key = f"financials:{provider}:{normalized}"
    cached = cache_get(key, ttl=900)
    if cached is not None:
        return cached

    rows: List[Dict[str, Any]] = []
    messages: List[str] = []
    sources: List[str] = []

    result = fetcher.fetch_yfinance_financials(normalized)
    messages.append(result.message)
    sources.append(result.source_api)
    if result.ok:
        save_result_all_layers(result)
        rows.extend(df_records(result.dataframe, limit=500))

    if provider in {"auto", "twelve_data"} and os.getenv("TWELVE_DATA_API_KEY"):
        tresult = fetcher.fetch_twelve_data_financials(normalized)
        messages.append(tresult.message)
        sources.append(tresult.source_api)
        if tresult.ok:
            save_result_all_layers(tresult)
            rows.extend(df_records(tresult.dataframe, limit=500))

    if provider in {"auto", "fmp"} and os.getenv("FMP_API_KEY"):
        fresult = fetcher.fetch_fmp_financials(normalized)
        messages.append(fresult.message)
        sources.append(fresult.source_api)
        if fresult.ok:
            save_result_all_layers(fresult)
            rows.extend(df_records(fresult.dataframe, limit=500))

    payload = {
        "ok": True,
        "symbol": normalized,
        "source_api": ",".join(sorted(set(sources))),
        "rows": rows,
        "count": len(rows),
        "messages": messages,
        "warning": "Financial statements may be partial or unavailable depending on provider coverage.",
    }
    return cache_set(key, payload)


def latest_for_symbol(symbol: str, label: str, asset_type: str, is_proxy: bool = False) -> Dict[str, Any]:
    payload = latest_payload_from_history_and_profile(symbol)
    payload["label"] = label
    payload["asset_type"] = asset_type
    payload["is_proxy"] = is_proxy
    if is_proxy:
        payload["warning"] = "Proxy/unofficial source. Do not treat as official FCPO settlement data."
    return payload


@app.get("/api/commodities/latest")
def commodities_latest(include_references: bool = Query(True)) -> Dict[str, Any]:
    key = f"commodities_latest:{include_references}:{bool(os.getenv('EIA_API_KEY'))}"
    cached = cache_get(key)
    if cached is not None:
        return cached
    rows: List[Dict[str, Any]] = []
    messages: List[str] = []
    for symbol, label, is_proxy in [
        ("CL=F", "WTI crude oil futures", False),
        ("BZ=F", "Brent crude oil futures", False),
        ("PO=F", "Palm oil / FCPO proxy", True),
    ]:
        try:
            item = latest_for_symbol(symbol, label, "commodity", is_proxy=is_proxy)
            rows.append(item)
            messages.extend(item.get("messages") or [])
        except Exception as exc:
            rows.append({"ok": False, "symbol": symbol, "label": label, "price": None, "change_percent": None, "warning": str(exc), "is_proxy": is_proxy})

    # Optional official EIA WTI/Brent spot prices. Saved and returned as extra official rows.
    if os.getenv("EIA_API_KEY"):
        for bench in ["WTI", "BRENT"]:
            eresult = fetcher.fetch_eia_crude_spot(bench, length=30)
            messages.append(eresult.message)
            if eresult.ok and not eresult.dataframe.empty:
                save_result_all_layers(eresult)
                latest = eresult.dataframe.sort_values("event_time").tail(1).iloc[0].to_dict()
                rows.append({
                    "ok": True, "symbol": bench, "label": f"EIA official {bench} spot", "asset_type": "commodity",
                    "price": safe_float(latest.get("close")), "change_percent": None, "source_api": "eia",
                    "event_time": str(latest.get("event_time")), "ingestion_time": latest.get("ingestion_time"),
                    "warning": "Official EIA spot price; not intraday futures quote.", "is_proxy": False,
                })

    references: List[Dict[str, Any]] = []
    if include_references:
        for func in [fetcher.fetch_bursa_fcpo_contract_specs_page, fetcher.fetch_bursa_derivatives_prices_page, fetcher.fetch_investing_fcpo_page, fetcher.fetch_mpob_overview_page]:
            r = func()
            messages.append(r.message)
            try:
                save_result_all_layers(r)
            except Exception:
                pass
            references.append({"ok": r.ok, "source_api": r.source_api, "symbol": r.symbol, "asset": r.asset, "message": r.message, "request_url": r.request_url, "metadata": r.metadata})
        vendor = fetcher.licensed_vendor_placeholder()
        references.append({"ok": vendor.ok, "source_api": vendor.source_api, "symbol": vendor.symbol, "asset": vendor.asset, "message": vendor.message, "metadata": vendor.metadata})

    payload = {
        "ok": True,
        "rows": rows,
        "references": references,
        "count": len(rows),
        "messages": messages,
        "warning": "FCPO is labelled as proxy/unofficial unless a licensed official feed is connected. Bursa/Investing/MPOB references are exposed separately as reference metadata.",
    }
    return cache_set(key, payload)


@app.get("/api/fx/latest")
def fx_latest() -> Dict[str, Any]:
    key = "fx_latest"
    cached = cache_get(key)
    if cached is not None:
        return cached
    pairs = [
        ("MYR=X", "USD/MYR"),
        ("SGDMYR=X", "SGD/MYR"),
        ("EURMYR=X", "EUR/MYR"),
        ("GBPMYR=X", "GBP/MYR"),
    ]
    rows: List[Dict[str, Any]] = []
    for symbol, pair in pairs:
        try:
            item = latest_payload_from_history_and_profile(symbol)
            item["pair"] = pair
            item["asset_type"] = "fx"
            rows.append(item)
        except Exception as exc:
            rows.append({"ok": False, "symbol": symbol, "pair": pair, "price": None, "warning": str(exc), "source_api": "yfinance_yahoo"})

    official_sources: List[Dict[str, Any]] = []
    # Optional BNM official-ish public API for multiple currencies.
    for code in ["usd", "sgd", "eur", "gbp"]:
        try:
            bnm = fetcher.fetch_bnm_exchange_rate(code)
            official_sources.append({"source_api": bnm.source_api, "symbol": bnm.symbol, "ok": bnm.ok, "message": bnm.message})
            if bnm.ok:
                save_result_all_layers(bnm)
        except Exception as exc:
            official_sources.append({"source_api": "bnm_openapi", "symbol": code.upper(), "ok": False, "message": str(exc)})

    try:
        dgov = fetcher.fetch_data_gov_my_exchange_rates("exchangerates_daily_0900", limit=1000)
        official_sources.append({"source_api": dgov.source_api, "symbol": dgov.symbol, "ok": dgov.ok, "message": dgov.message})
        if dgov.ok:
            save_result_all_layers(dgov)
    except Exception as exc:
        official_sources.append({"source_api": "data_gov_my", "symbol": "exchangerates_daily_0900", "ok": False, "message": str(exc)})

    payload = {
        "ok": True,
        "rows": rows,
        "official_sources": official_sources,
        "count": len(rows),
        "warning": "Yahoo/yfinance FX fallback can be delayed. BNM and data.gov.my are fetched/stored as official reference sources when available.",
    }
    return cache_set(key, payload)


@app.get("/api/ingestion/logs")
def ingestion_logs(limit: int = Query(100, ge=1, le=1000)) -> Dict[str, Any]:
    df = storage.read_ingestion_log()
    rows = df_records(df, limit=limit)
    return {"ok": True, "rows": rows, "count": len(rows)}


@app.get("/api/catalog/columns")
def catalog_columns() -> Dict[str, Any]:
    path = CATALOG_DIR / "columns.csv"
    if not path.exists():
        return {"ok": False, "rows": [], "count": 0, "message": "catalog/columns.csv not found"}
    df = pd.read_csv(path)
    rows = df_records(df)
    return {"ok": True, "rows": rows, "count": len(rows)}


@app.get("/api/catalog/sources")
def catalog_sources() -> Dict[str, Any]:
    return {"ok": True, "sources": catalog.load_sources()}


@app.get("/api/query")
def query_duckdb(sql: str = Query(..., description="DuckDB SQL. Example: SELECT * FROM v_silver LIMIT 5")) -> Dict[str, Any]:
    forbidden = ["insert", "update", "delete", "drop", "alter", "create", "copy", "attach", "detach"]
    if any(word in sql.lower() for word in forbidden):
        raise HTTPException(status_code=400, detail="Only read-only SELECT queries are allowed from the web API.")
    try:
        storage.register_latest_views()
        df = storage.query_duckdb(sql)
        rows = df_records(df, limit=1000)
        return {"ok": True, "rows": rows, "count": len(rows)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/market/profile")
def market_profile(symbol: str = Query(...), provider: str = Query("auto")) -> Dict[str, Any]:
    normalized = normalize_bursa_symbol(symbol)
    key = f"profile:{provider}:{normalized}"
    cached = cache_get(key, ttl=900)
    if cached is not None:
        return cached
    rows: List[Dict[str, Any]] = []
    messages: List[str] = []
    sources: List[str] = []
    y = fetcher.fetch_yfinance_quote_info(normalized)
    messages.append(y.message); sources.append(y.source_api)
    if y.ok:
        save_result_all_layers(y); rows.extend(df_records(y.dataframe, limit=5))
    if provider in {"auto", "twelve_data"} and os.getenv("TWELVE_DATA_API_KEY"):
        t = fetcher.fetch_twelve_data_profile(normalized)
        messages.append(t.message); sources.append(t.source_api)
        if t.ok:
            save_result_all_layers(t); rows.extend(df_records(t.dataframe, limit=5))
    if provider in {"auto", "fmp"} and os.getenv("FMP_API_KEY"):
        f = fetcher.fetch_fmp_profile(normalized)
        messages.append(f.message); sources.append(f.source_api)
        if f.ok:
            save_result_all_layers(f); rows.extend(df_records(f.dataframe, limit=5))
    return cache_set(key, {"ok": True, "symbol": normalized, "source_api": ",".join(sorted(set(sources))), "rows": rows, "count": len(rows), "messages": messages, "warning": "Profile coverage depends on selected provider."})


@app.get("/api/commodities/fcpo/references")
def fcpo_references() -> Dict[str, Any]:
    key = "fcpo_references"
    cached = cache_get(key, ttl=1800)
    if cached is not None:
        return cached
    results = [fetcher.fetch_bursa_fcpo_contract_specs_page(), fetcher.fetch_bursa_derivatives_prices_page(), fetcher.fetch_investing_fcpo_page(), fetcher.licensed_vendor_placeholder()]
    rows = []
    for r in results:
        try:
            save_result_all_layers(r)
        except Exception:
            pass
        rows.extend(df_records(r.dataframe, limit=5))
    return cache_set(key, {"ok": True, "rows": rows, "count": len(rows), "warning": "Reference pages/placeholders only; not official free live FCPO JSON."})


@app.get("/api/commodities/palm-oil/fundamentals")
def palm_oil_fundamentals() -> Dict[str, Any]:
    key = "palm_oil_fundamentals"
    cached = cache_get(key, ttl=1800)
    if cached is not None:
        return cached
    r = fetcher.fetch_mpob_overview_page()
    try:
        save_result_all_layers(r)
    except Exception:
        pass
    return cache_set(key, {"ok": r.ok, "source_api": r.source_api, "rows": df_records(r.dataframe, limit=20), "count": len(r.dataframe), "message": r.message, "warning": "MPOB BEPI is used as official public web reference metadata until a validated numerical parser is added."})


@app.get("/api/sources/status")
def sources_status() -> Dict[str, Any]:
    rows = [
        {"source_api": "yfinance_yahoo", "configured": True, "used_for": "Bursa .KL prices, KLCI, futures proxy, FX fallback, financials fallback", "route": "/api/market/latest, /api/market/history", "status": "fallback_unofficial"},
        {"source_api": "twelve_data_time_series", "configured": bool(os.getenv("TWELVE_DATA_API_KEY")), "used_for": "Bursa XKLS time_series 1day/5min and universe/profile/financials", "route": "/api/market/history?provider=twelve_data", "status": "optional_api_key"},
        {"source_api": "twelve_data_profile", "configured": bool(os.getenv("TWELVE_DATA_API_KEY")), "used_for": "Company profile", "route": "/api/market/profile?provider=twelve_data", "status": "optional_api_key"},
        {"source_api": "twelve_data_financials", "configured": bool(os.getenv("TWELVE_DATA_API_KEY")), "used_for": "Income statement, balance sheet, cash flow", "route": "/api/financials?provider=twelve_data", "status": "optional_api_key"},
        {"source_api": "fmp", "configured": bool(os.getenv("FMP_API_KEY")), "used_for": "Alternative profile and financial statements", "route": "/api/market/profile?provider=fmp, /api/financials?provider=fmp", "status": "optional_api_key"},
        {"source_api": "eia", "configured": bool(os.getenv("EIA_API_KEY")), "used_for": "WTI and Brent official spot prices", "route": "/api/commodities/latest", "status": "optional_api_key_official"},
        {"source_api": "bnm_openapi", "configured": True, "used_for": "USD/SGD/EUR/GBP to MYR official reference attempts", "route": "/api/fx/latest", "status": "public_official_when_endpoint_available"},
        {"source_api": "data_gov_my", "configured": True, "used_for": "Daily 0900 exchange-rate dataset", "route": "/api/fx/latest", "status": "public_official"},
        {"source_api": "mpob_bepi_web", "configured": True, "used_for": "Palm oil fundamentals page metadata", "route": "/api/commodities/palm-oil/fundamentals", "status": "official_public_web_reference"},
        {"source_api": "bursa_fcpo_contract_specs", "configured": True, "used_for": "FCPO contract specs reference", "route": "/api/commodities/fcpo/references", "status": "official_reference"},
        {"source_api": "bursa_derivatives_prices_web", "configured": True, "used_for": "Bursa derivatives prices page reference", "route": "/api/commodities/fcpo/references", "status": "official_web_reference"},
        {"source_api": "investing_fcpo_web", "configured": True, "used_for": "FCPO web reference fallback", "route": "/api/commodities/fcpo/references", "status": "unofficial_web_reference"},
        {"source_api": "fcpo_licensed_vendor", "configured": False, "used_for": "Future broker/Bursa licensed FCPO live feed", "route": "/api/commodities/fcpo/references", "status": "placeholder_not_configured"},
    ]
    return {"ok": True, "rows": rows, "count": len(rows)}


@app.exception_handler(Exception)
async def generic_exception_handler(_, exc: Exception):
    return JSONResponse(status_code=500, content={"ok": False, "error": str(exc)})
