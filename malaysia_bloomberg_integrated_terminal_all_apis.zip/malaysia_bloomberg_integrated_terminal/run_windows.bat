@echo off
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m uvicorn backend.api_server:app --host 0.0.0.0 --port 8000 --reload
pause
